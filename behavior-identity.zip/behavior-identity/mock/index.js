import user from './user'
import system from './system/user'
export default {
  user,
  system
}

