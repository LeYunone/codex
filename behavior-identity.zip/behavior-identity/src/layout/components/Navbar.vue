<template>
  <div class="navbar">
    <div class="nav-logo">
      <img src="../../assets/image/nav-logo.png" alt="">
      <span>{{ $t("login.title") }}</span>
    </div>

    <hamburger
      :is-active="sidebar.opened"
      class="hamburger-container"
      @toggleClick="toggleSideBar"
    />

    <!-- <breadcrumb class="breadcrumb-container" /> -->
    <div class="drop-menu">
      <Dropdown placement="bottom-end">
        <div>
          <a href="javascript:void(0)" class="user-name">
            系统设置
            <Icon type="ios-arrow-down"></Icon>
          </a>
        </div>
        <DropdownMenu slot="list">
          <DropdownItem @click.native="update">
            同步
          </DropdownItem>
          <!-- <DropdownItem @click.native="pushWarn">
            报警推送
          </DropdownItem> -->
          <DropdownItem @click.native="toLayout">
            {{ $t("common.layout") }}
          </DropdownItem>
        </DropdownMenu>
      </Dropdown>
      <!-- <Button size="small" type="dashed" @click="update">同步</Button> -->
      <Dropdown placement="bottom-end">
        <div>
          <a href="javascript:void(0)" class="user-name">
            <img src="../../assets/image/pic.png" alt="">
          </a>
        </div>
        <!-- <DropdownMenu slot="list">
          <DropdownItem @click.native="toLayout">{{
            $t("common.layout")
          }}</DropdownItem>
        </DropdownMenu> -->
      </Dropdown>
    </div>
    <!-- 退出登录-->
    <delModal ref="loyOutModal" @beforeDele="exitSystem">
      <div slot="info">
        <h2 class="modal-title margin-bottom-20 primary-color">
          {{ $t("login.confirmLayout") }}
        </h2>
        <h3 class="modal-detail">{{ $t("login.layoutTip") }}</h3>
      </div>
    </delModal>
    <updateModal ref="updateModal" />
    <pushWarn ref="pushWarn" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import hamburger from '../../components/Hamburger/index'
import breadcrumb from '@/components/Breadcrumb/index'
import router from '@/router/index'
import delModal from '@/components/Modal/delModal'
import updateModal from '@/components/Modal/updateModal'
import pushWarn from '@/components/Modal/pushWarn'
export default {
  components: {
    hamburger,
    breadcrumb,
    delModal,
    updateModal,
    pushWarn
  },
  data() {
    return {
      isPropertyModal: false,
      logo: ''
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'avatar'])
  },
  watch: {},
  mounted () {
  },
  methods: {
    toggleSideBar() {
      this.$store.dispatch('app/toggleSideBar')
    },
    back() {
      router.push('/homePage')
    },
    toLayout() {
      this.$refs.loyOutModal.isPropertyModal = true
    },
    exitSystem() {
      this.$store
        .dispatch('personCenter/loginOut')
        .then((response) => {
          console.log('退出', response)
          localStorage.clear()
          router.push('/')
          setTimeout(() => {
            window.location.reload()
          }, 200)
        })
        .catch(() => {})
    },
    update() {
      this.$refs.updateModal.dialogVisible = true
    },
    pushWarn () {
      this.$refs.pushWarn.dialogVisible = true
    }
  }
}
</script>

<style lang="scss" scoped>
.style {
  position: absolute !important;
  z-index: 1000000 !important;
}
.navbar {
  height: 60px;
  overflow: hidden;
  position: relative;
  background: #ffffff;
  box-shadow: 0px 2px 10px 0px rgba(0, 0, 0, 0.09);

  .nav-logo {
    display: flex;
    flex-direction: row;
    align-items: center;
    padding-left: 30px;
    height: 100%;
    font-size: 20px;
    color: #333333;
    img{
      width: 25px;
      height: auto;
      margin-right: 10px;
    }
  }
  .msgbox {
    position: fixed;
    left: 270px;
    top: 0;
    height: 60px;
    line-height: 60px;
    span {
      display: inline-block;
      margin-right: 20px;
      font-size: 16px;
      color: #666666;
    }
  }
  .hamburger-container {
    position: fixed;
    left: 11%;
    top: 0;
    line-height: 56px;
    cursor: pointer;
    transition: background 0.3s;
    -webkit-tap-highlight-color: transparent;
    &:hover {
      background: rgba(0, 0, 0, 0.025);
    }
  }

  .breadcrumb-container {
    float: left;
    position: relative;
  }
  .logout {
    position: fixed;
    right: 25px;
    top: 20px;
    color: #ffffff;
    cursor: pointer;
  }

  .drop-menu {
    position: fixed;
    top: 0;
    right: 30px;
    color: #6b2c2c;
    display: flex;
    align-items: center;
    .user-name {
      font-size: 14px;
      line-height: 60px;
      margin-left: 15px;
      color: #333333;
      display: flex;
      align-items: center;
      height: 60px;
      img{
        margin-right: 5px;
      }
    }
    .certi-logo {
      width: 60px;
      height: auto;
    }
  }
}
</style>
