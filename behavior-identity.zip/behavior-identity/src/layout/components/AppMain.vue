<template>
  <section class="app-main">
    <transition name="fade-transform"
                mode="out-in">
      <router-view :key="key"
                   :hide-btn-span="hideBtnSpan" />
    </transition>
  </section>
</template>

<script>
export default {
  name: 'AppMain',
  computed: {
    key () {
      return this.$route.path
    },
    hideBtnSpan () {
      // 侧边栏展开/闭合
      return this.$store.state.app.sidebar.opened
    }
  }
}
</script>

<style scoped>
.app-main {
  /*50 = navbar  */
  min-height: 100vh;
  width: 100%;
  position: relative;
  overflow: hidden;
}
.fixed-header + .app-main {
  padding-top: 50px;
}
</style>

<style lang="scss">
@import "../../assets/scss/common";
@import "../../assets/scss/layout";

// fix css style bug in open el-dialog
.el-popup-parent--hidden {
  .fixed-header {
    padding-right: 15px;
  }
}
</style>
