
<template>
  <div class="headerfilter">
    <div class="ivu-input-wrapper ivu-input-wrapper-large ivu-input-type-text ivu-input-group ivu-input-group-large ivu-input-group-with-prepend">
      <div class="ivu-input-group-prepend">
        <span>
          <slot name="header"></slot>
        </span>
      </div>
      <slot name="body"></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'headerfilter',
  components: {
  },
  data () {
    return {
    }
  },
  computed: {
  },
  watch: {
  },
  created () {
  },
  mounted () {
  },
  beforeRouterEnter (to, from, next) {
    next(vm => {
    })
  },
  beforeRouterLeave (to, from, next) {
    next()
  },
  methods: {
  }
}
</script>
