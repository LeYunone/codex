<style lang="scss" scoped>
// .el-menu {
//   background: linear-gradient(0deg, #41a4e6 0%, #65e0cb 61%);
//   height: 100%;
//   color: #fff;
// }

</style>
<template>
  <div :class="{ 'has-logo': showLogo }" v-if="isShowSide">
    <logo v-if="showLogo" :collapse="isCollapse" />
    <el-scrollbar wrap-class="scrollbar-wrapper">
      <!-- <el-menu
        :default-active="activeMenu"
        :collapse="isCollapse"
        :background-color="variables.menuBg"
        :text-color="variables.menuText"
        :unique-opened="false"
        :active-text-color="variables.menuActiveText"
        :collapse-transition="false"
        mode="vertical"
      > -->
      <el-menu
        :default-active="activeMenu"
        :collapse="isCollapse"
        :text-color="variables.menuText"
        :unique-opened="true"
        :active-text-color="variables.menuActiveText"
        :collapse-transition="false"
        mode="vertical"
      >
        <sidebar-item
          v-for="route in routes"
          :key="route.path"
          :item="route"
          :base-path="route.path"
        />
      </el-menu>
    </el-scrollbar>
    <Button @click="logout">退出登录</Button>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import Logo from "./Logo";
import SidebarItem from "./SidebarItem";
import variables from "@/styles/variables.scss";
import { constantRoutes } from "@/router/index";
import { getToken, getRoleId } from "@/utils/auth"; // get token from cookie

export default {
  components: { SidebarItem, Logo },
  data() {
    return {
      routes: [],
      isShowSide: false
    };
  },
  computed: {
    ...mapGetters(["sidebar"]),
    // routes() {
    //   let tragetMenuList = JSON.parse(localStorage.getItem("tragetMenuList"));
    //   return tragetMenuList;
    // },
    activeMenu() {
      const route = this.$route;
      const { meta, path } = route;
      // if set path, the sidebar will highlight the path you set
      if (meta.activeMenu) {
        return meta.activeMenu;
      }
      return path;
    },
    showLogo() {
      return this.$store.state.settings.sidebarLogo;
    },
    variables() {
      return variables;
    },
    isCollapse() {
      return !this.sidebar.opened;
    }
  },
  mounted() {
    // debugger;
    // if (getRoleId() === 1) {
    //   this.routes = companyRoutes
    // } else if (getRoleId() === 2) {
    //   this.routes = propertyRoutes
    // }
    this.isShowSide = true;

    this.routes = constantRoutes;
    // this.routes = this.setPermMenu()
  },
  beforeRouteLeave() {
    this.isShowSide = false;
  },
  methods: {
    logout() {
      window.location.href = window.location.host + "/#/";
      localStorage.clear();
      // window.location.reload()
    },
    setPermMenu() {
      debugger;
      let permList = JSON.parse(localStorage.getItem("permList"));
      let tragetMenuList = constantRoutes;
      let currentList = [];
      let firstMenu = {};
      var noAllowList = [];
      tragetMenuList = tragetMenuList.filter(item => item.menuId);
      tragetMenuList.forEach((item, index) => {
        let currentItem = item;
        if (permList.includes(item.menuId)) {
          item.isAllow = true;
          item.children.forEach((sitem, sindex) => {
            let noPermMenuId = sitem.menuId;
            if (!permList.includes(sitem.menuId)) {
              noAllowList = noAllowList.concat(item.children[sindex]);
              sitem.isAllow = false;
            } else {
              sitem.isAllow = true;
            }
          });
        } else {
          noAllowList = noAllowList.concat(tragetMenuList[index]);
          item.isAllow = false;
        }
      });
      tragetMenuList = tragetMenuList.filter(item => {
        return item.isAllow == true;
      });
      tragetMenuList.forEach(item => {
        item.children = item.children.filter(sitem => {
          return sitem.isAllow == true;
        });
      });
      localStorage.setItem("noAllowList", JSON.stringify("noAllowList"));
      console.log("noAllowMenu");
      console.log(noAllowList);
      console.log("constantRoutes");
      console.log(constantRoutes);
      //tragetMenuList = JSON.parse(localStorage.getItem('targetMenuList'))
      return tragetMenuList;
    }
  }
};
</script>
