import router from './router'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import { getUserId } from '@/utils/auth' // get token from cookie
import { Message } from 'element-ui'


NProgress.configure({ showSpinner: false }) // NProgress Configuration

const whiteList = ['/'] // no redirect

router.beforeEach((to, from, next) => {
  NProgress.start()
  let hasUserId = getUserId()
  // 是否已登录
  if (hasUserId) {
  //  if (to.path === '/' || to.path === '') {
    if (to.path === '/') {
      next()
      localStorage.clear()
      NProgress.done()
    }
    else {
      next()
    }
  } else {
    /* 无token*/
    //白名单直接放行
    if (whiteList.indexOf(to.path) !== -1) {
      next()
    } else {
      // next({ path: '/' })
       NProgress.done()
    }
  }
})

router.afterEach(() => {
  // finish progress bar
  NProgress.done()
})
