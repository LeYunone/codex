import Vue from 'vue'
import Vuex from 'vuex'
import getters from './getters'
import app from './modules/app'
import common from './modules/common'
import settings from './modules/settings'
import commit from './modules/commit/commit'
import personManager from './modules/database/personManager'
import deptManager from './modules/database/deptManager'
import projectList from './modules/projectList/projectList'
import eCharts from './modules/eCharts/eCharts'
import bugDetails from './modules/bugModules/bugDetails'
import codeQuality from './modules/codeQuality/codeQuality'
import projectManager from './modules/database/projectManager'
import warming from './modules/warming/warming'

Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    common,
    app,
    settings,
    commit,
    personManager,
    deptManager,
    projectList,
    eCharts,
    bugDetails,
    codeQuality,
    projectManager,
    warming
  },
  getters,
  state: {
  }
})

export default store
