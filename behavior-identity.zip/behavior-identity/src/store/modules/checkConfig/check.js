import { getCaList, getCaDetail, passCa, rejectCa, disableCa } from '@/api/checkConfig/check'
import qs from 'qs'
const getDefaultState = () => {
    return {
    }
}

const state = getDefaultState()

const actions = {
    getCaList({ commit }, targetData) {
        const { pageIndex, pageSize, sortMode, sortField, status, info } = targetData
        return new Promise((resolve, reject) => {
            getCaList({ pageIndex: pageIndex, pageSize: pageSize, sortMode: sortMode, sortField: sortField, status: status, info: info })
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
    },
    getCaDetail({ commit }, targetData) {
        const { userId } = targetData
        return new Promise((resolve, reject) => {
            getCaDetail({ userId: userId })
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
    },
    passCa({ commit }, targetData) {
        const { userId, reason } = targetData
        return new Promise((resolve, reject) => {
            passCa(qs.stringify({ userId: userId, reason: reason }))
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
    },
    rejectCa({ commit }, targetData) {
        const { userId, reason } = targetData
        return new Promise((resolve, reject) => {
            rejectCa(qs.stringify({ userId: userId, reason: reason }))
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
    },
     
    disableCa({ commit }, targetData) {
        const { userId, reason } = targetData
        return new Promise((resolve, reject) => {
            disableCa(qs.stringify({ userId: userId, reason: reason }))
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
    },
}

export default {
    namespaced: true,
    state,
    actions
}