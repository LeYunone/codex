import { statistics, getAlarm, alarmInfo } from '@/api/codeQuality/codeQuality'
const getDefaultState = () => {
  return {
    // 表格列
    personColumns: [
      {
        key: 'name',
        title: '人员',
        align: 'center'
      }
    ],
    deptColumns: [
      {
        key: 'name',
        title: '部门',
        align: 'center'
      }
    ],
    projectColumns: [
      {
        key: 'name',
        title: '项目',
        align: 'center'
      }
    ],
    hasSortColumns: [
      {
        slot: 'bugNumber',
        title: 'BUG总数',
        align: 'center',
        sortable: 'custom',
      },
      {
        key: 'codeTotal',
        title: 'Reopen率(%)',
        slot: 'reopenRate',
        align: 'center',
        sortable: 'custom',
      },
    ],
    noSortColumns: [
      {
        slot: 'bugNumber',
        title: 'BUG总数',
        align: 'center'
      },
      {
        key: 'codeTotal',
        title: 'Reopen率(%)',
        slot: 'reopenRate',
        align: 'center'
      }
    ],
    columns: [
      // {
      //   slot: 'bugNumber',
      //   title: 'BUG总数',
      //   align: 'center',
      //   sortable: 'custom',
      // },
      // {
      //   key: 'codeTotal',
      //   title: 'Reopen率(%)',
      //   slot: 'reopenRate',
      //   align: 'center',
      //   sortable: 'custom',
      // },
      {
        key: 'codeTotal',
        title: '代码行数',
        align: 'center',
        className: 'cmmi-class',
        // className: 'all-class',
        children: [
           {
            title: '删除量',
            slot: 'deletions',
            align: 'center',
            width: 140,
            className: 'number-class'
            // className: 'deletions-class'
          },
          {
            title: '新增量',
            slot: 'additions',
            align: 'center',
            width: 140,
            className: 'level-class'
            // className: 'additions-class'
          }
        ]
      },
      {
        key: 'codeTotal',
        title: '千行代码缺陷率',
        align: 'center',
        className: 'cmmi-class',
        // sortable: true,
        children: [
          {
            title: 'CMMI(‰)',
            slot: 'CMMINumber',
            align: 'center',
            width: 140,
            className: 'number-class'
          },
          {
            title: 'CMMI等级',
            slot: 'level',
            align: 'center',
            width: 140,
            className: 'level-class'
          }
        ]
      }

    ]
  }
}

const state = getDefaultState()

const actions = {
  statistics({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            statistics(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  alarmInfo({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            alarmInfo(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
    getAlarm({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            getAlarm(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  }
}

export default {
    namespaced: true,
    state,
    actions
}

