const getDefaultState = () => {
  return {
    passwordReg: /^(?=.*\d)(?=.*[a-zA-Z])[a-zA-Z0-9]{8,25}$/,
    nameReg: /^[^\#\$\￥\%\^\&\*\……\~\`\|\【\】\》\《\'\!\！\{\}\‘\“\”\’\/\、\?\？\——\=\+\@]*$/,
    codeReg: /^[0-9]{6}$/,
    emailReg: /^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\.([A-Za-z]{2,4})$/,
    accountReg: /^(?=.*[A-Za-z])[0-9A-Za-z\-]{5,20}$/,
    avIdReg: /^[0-9]*$/
  };
};

const state = getDefaultState();

export default {
  namespaced: true,
  state
};
