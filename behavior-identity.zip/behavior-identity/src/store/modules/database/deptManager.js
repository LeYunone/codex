import { getDeptList,updateDept } from '@/api/dataBase/deptManager'
import qs from 'qs'
const getDefaultState = () => {
    return {
    }
}

const state = getDefaultState()

const actions = {
    getDeptList({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            getDeptList()
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  updateDept ({ commit }, targetData) {
    const { groupId, groupName } = targetData
        return new Promise((resolve, reject) => {
            updateDept({ groupId, groupName })
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
    },
}

export default {
    namespaced: true,
    state,
    actions
}