import { getPersonList, editPerson, getList, getRealUserList, updatePerson, deletePerson } from '@/api/dataBase/personManager'
import qs from 'qs'
const getDefaultState = () => {
  return {
      columns: [
        {
          title: '姓名',
          align: 'center',
          key: 'realUserName'
        },
        {
          title: '邮箱',
          align: 'center',
          key: 'realEmail'
        },
        {
          title: 'gitlab账号',
          align: 'center',
          slot: 'gitLabUser'
        },
        {
          title: '部门',
          align: 'center',
          slot: 'groupList'
        },
        {
          title: '操作',
          slot: 'action',
          align: 'center',
          width: 270
        }
      ]
    }
}

const state = getDefaultState()

const actions = {
    getPersonList({ commit }, targetData) {
      const { pageIndex, pageSize } = targetData
        return new Promise((resolve, reject) => {
            getPersonList({ pageIndex, pageSize })
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  editPerson({ commit }, targetData) {
      // const { index, size } = targetData
        return new Promise((resolve, reject) => {
            editPerson(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  getList({ commit }, targetData) {
      const { pageIndex, pageSize, realUserName } = targetData
        return new Promise((resolve, reject) => {
            getList({ pageIndex, pageSize, realUserName })
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  getRealUserList({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            getRealUserList()
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  updatePerson({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            updatePerson(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
   deletePerson({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            deletePerson(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  getRealPersonList({ commit }, targetData) {
      const { pageIndex, pageSize, realUserName, groupId } = targetData
        return new Promise((resolve, reject) => {
            getList({ pageIndex, pageSize, realUserName, groupId })
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  }
}

export default {
    namespaced: true,
    state,
    actions
}
