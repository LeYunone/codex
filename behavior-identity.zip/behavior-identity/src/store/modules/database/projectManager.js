import qs from 'qs'
import { relationRealProject, relationList } from '@/api/dataBase/projectManager'
const getDefaultState = () => {
    return {
      columns: [
        {
          title: '真实项目名',
          key: 'realProjectName',
          align: 'center',
          width: 350,
        },
        {
          title: 'Git项目名',
          key: 'projectNames',
          slot: 'projectNames',
          align: 'center'
        },
        {
          title: '事业部',
          key: 'department',
          align: 'center'
        },
        {
          title: '项目成员',
          slot: 'realUserNames',
          align: 'center'
        },
        {
          title: '操作',
          slot: 'actions',
          align: 'center'
        }
      ]
    }
}

const state = getDefaultState()

const actions = {
    relationRealProject({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            relationRealProject(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
    },
    relationList({ commit }, targetData) {
      return new Promise((resolve, reject) => {
            relationList(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
    }
}

export default {
    namespaced: true,
    state,
    actions
}
