import { detailList, getBugSystemName, bugTop, bugAnalysis, bugVersionAnalysis, bugHistogram } from '@/api/bugModules/bugDetails'
const getDefaultState = () => {
  return {
    // 表格列
    tableColumns: [
      {
        key: 'projectName',
        title: '项目名称',
        align: 'center'

      },
      {
        key: 'department',
        title: '事业部',
        align: 'center'
      },

      {
        key: 'bugTitle',
        title: '标题',
        align: 'center',
        width: 200
      },
      {
        key: 'bugId',
        title: 'ID',
        align: 'center'
      },
      {
        key: 'level',
        title: '严重等级',
        align: 'center'
      },
      {
        key: 'status',
        title: '状态',
        align: 'center'
      },
      {
        key: 'creator',
        title: '创建人',
        align: 'center'
      },
      {
        key: 'createTime',
        title: '创建时间',
        align: 'center'
      },
      {
        key: 'resolveName',
        title: '负责人',
        align: 'center'
      },
      {
        key: 'endTime',
        title: '关闭时间',
        align: 'center'
      },
      {
        key: 'bugType2',
        title: '类型',
        align: 'center'
      },
      {
        key: 'bugReopen',
        title: 'BugReopen',
        align: 'center'
      },
      {
        key: 'belongTo',
        title: '责任归属',
        align: 'center'
      },
      {
        key: 'bugVersion',
        title: '影响版本',
        align: 'center'
      },
      {
        key: 'probability',
        title: '发生概率',
        align: 'center'
      },
      {
        key: 'fixVersion',
        title: '修复版本',
        align: 'center'
      },
      {
        key: 'module',
        title: '功能模块',
        align: 'center'
      },
      {
        key: 'bugReopenMonth',
        // slot: 'bugReopenMonth',
        title: 'BugReopenMonth',
        align: 'center',
        width: '150'
      }
    ],
    bugReopenStatus: [
      {
        name: 'Reopen',
        value: 1
      },
      {
        name: '非Reopen',
        value: 0
      }
    ],
    statusList: [
      {
        name: '验证通过',
        value: '验证通过'
      },
      {
        name: '非缺陷',
        value: '非缺陷'
      },
      {
        name: '修复中',
        value: '修复中'
      },
      {
        name: '重复缺陷',
        value: '重复缺陷'
      },
      {
        name: '已修复，验证中',
        value: '已修复，验证中'
      },
      {
        name: '非缺陷确认中',
        value: '非缺陷确认中'
      },
      {
        name: '待确认',
        value: '待确认'
      },
      {
        name: '已挂起',
        value: '已挂起'
      },
      {
        name: '挂起确认中',
        value: '挂起确认中'
      },
      {
        name: '重复确认中',
        value: '重复确认中'
      }

    ],
    botUrlList: [
      {
        name: '全部',
        value: '全部'
      }
    ],
    bugTypeList: [
      {
        name: '其他',
        value: '其他'
      },
      {
        name: '功能缺失',
        value: '功能缺失'
      },
      {
        name: '功能缺陷',
        value: '功能缺陷'
      },
      {
        name: '客户反馈',
        value: '客户反馈'
      },
      {
        name: '方案缺陷',
        value: '方案缺陷'
      },
      {
        name: '设计缺陷',
        value: '设计缺陷'
      },
      {
        name: '需求与建议',
        value: '需求与建议'
      },
      {
        name: '需求缺陷',
        value: '需求缺陷'
      }
    ],
    typeList: [
      {
        label: '柱状图',
        value: 1
      },
      {
        label: '饼图',
        value: 2
      }
    ],
    toolbars: {
      bold: true, // 粗体
      italic: true, // 斜体
      header: true, // 标题
      underline: true, // 下划线
      strikethrough: true, // 中划线
      mark: true, // 标记
      superscript: true, // 上角标
      subscript: true, // 下角标
      quote: true, // 引用
      ol: true, // 有序列表
      ul: true, // 无序列表
      link: true, // 链接
      imagelink: false, // 图片链接
      code: true, // code
      table: true, // 表格
      fullscreen: true, // 全屏编辑
      readmodel: true, // 沉浸式阅读
      htmlcode: false, // 展示html源码
      help: true, // 帮助
      /* 1.3.5 */
      undo: true, // 上一步
      redo: true, // 下一步
      trash: true, // 清空
      save: false, // 保存（触发events中的save事件）
      /* 1.4.2 */
      navigation: true, // 导航目录
      /* 2.1.8 */
      alignleft: true, // 左对齐
      aligncenter: true, // 居中
      alignright: true, // 右对齐
      /* 2.2.1 */
      subfield: true, // 单双栏模式
      preview: true // 预览
    }
  }
}

const state = getDefaultState()

const actions = {
  detailList({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            detailList(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  getBugSystemName({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            getBugSystemName(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  bugTop({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            bugTop(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  bugAnalysis({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            bugAnalysis(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  bugVersionAnalysis({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            bugVersionAnalysis(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  bugHistogram({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            bugHistogram(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  }
}

export default {
    namespaced: true,
    state,
    actions
}

