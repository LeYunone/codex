import { getList } from '@/api/projectList/projectList'
import qs from 'qs'
const getDefaultState = () => {
    return {
    }
}

const state = getDefaultState()

const actions = {
  getList ({ commit }, targetData) {
      const { pageIndex, pageSize, projectId, userId, orderType, startDate, endDate } = targetData
      return new Promise((resolve, reject) => {
          getList({ pageIndex, pageSize, projectId, userId, orderType, startDate, endDate })
            .then(response => {
              resolve(response)
            })
            .catch(error => {
              reject(error)
            })
        })
  }
}

export default {
    namespaced: true,
    state,
    actions
}
