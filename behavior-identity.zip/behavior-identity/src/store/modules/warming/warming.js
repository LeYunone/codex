import { detailList, getBugSystemName } from '@/api/bugModules/bugDetails'
import { getAlarm,saveBot,chanceStatus,deleteWarn } from '@/api/warn/warn'

const getDefaultState = () => {
  return {

    targetList: [
      {
        title: 'bug总数',
        value: 1,
      },
      {
        title: 'reopen率',
        value: 2,
      },
      {
        title: '缺陷率',
        value: 3,
      },
      {
        title: '提交频率',
        value: 4,
      },
      {
        title: '代码行数',
        value: 5,
      }
    ],
    mathList: [
      {
        title: '=',
        value: 1
      },
      {
        title: '>',
        value: 2
      },
      {
        title: '<',
        value: 3
      }
    ],
    botUrlList: [
      {
        name: '全部',
        value: '全部'
      }
    ],
    alarmAllList: [
      {
        title: '项目',
        value: 1
      },
      {
        title: '部门',
        value: 2
      },
      {
        title: '成员',
        value: 3
      }
    ],
    toolbars: {
      bold: true, // 粗体
      italic: true, // 斜体
      header: true, // 标题
      underline: true, // 下划线
      strikethrough: true, // 中划线
      mark: true, // 标记
      superscript: true, // 上角标
      subscript: true, // 下角标
      quote: true, // 引用
      ol: true, // 有序列表
      ul: true, // 无序列表
      link: true, // 链接
      imagelink: false, // 图片链接
      code: true, // code
      table: true, // 表格
      fullscreen: true, // 全屏编辑
      readmodel: true, // 沉浸式阅读
      htmlcode: false, // 展示html源码
      help: true, // 帮助
      /* 1.3.5 */
      undo: true, // 上一步
      redo: true, // 下一步
      trash: true, // 清空
      save: false, // 保存（触发events中的save事件）
      /* 1.4.2 */
      navigation: true, // 导航目录
      /* 2.1.8 */
      alignleft: true, // 左对齐
      aligncenter: true, // 居中
      alignright: true, // 右对齐
      /* 2.2.1 */
      subfield: true, // 单双栏模式
      preview: true // 预览
    },
    column: [
      {
        title: 'ID',
        key: 'id',
        align: 'center',
        width: '350'
      },
      {
        title: '监测对象', // 显示全部或者局部（部门or项目or成员）
        key: 'alarmObject',
        slot: 'alarmObject',
        align: 'center'
      },
      {
        title: '执行周期',
        key: 'cron',
        align: 'center'
      },
      {
        title: '推送类型',
        slot: 'alarmType',
        align: 'center'
      },
      {
        title: '推送地址',
        key: 'botUrl',
        align: 'center'
      },
      {
        title: '状态',
        key: 'status',
        slot: 'status',
        align: 'center'
      },
      {
        title: '操作',
        slot: 'actions',
        align: 'center',
        width: 220
      }
    ]
  }
}

const state = getDefaultState()

const actions = {
  detailList({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            detailList(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  getBugSystemName({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            getBugSystemName(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  getAlarm({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            getAlarm(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  saveBot({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            saveBot(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  chanceStatus({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            chanceStatus(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  deleteWarn({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            deleteWarn(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
}

export default {
    namespaced: true,
    state,
    actions
}

