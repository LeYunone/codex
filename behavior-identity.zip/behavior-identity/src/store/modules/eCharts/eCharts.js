import { userProjectTimeCode,userbasecode,projectTimeCode,groupbasecode,projectbasecode,userinfo,getCodeTotal,exportUserCode } from '@/api/eCharts/eCharts'
import qs from 'qs'
const getDefaultState = () => {
    return {
    }
}

const state = getDefaultState()

const actions = {
  userProjectTimeCode({ commit }, targetData) {
      const { startDate, endDate, projectId, realUserId, timeType,limit } = targetData
        return new Promise((resolve, reject) => {
            userProjectTimeCode({ startDate, endDate, projectId, realUserId, timeType, limit})
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  userbasecode({ commit }, targetData) {
      const { startDate, endDate, realUserId, projectId, groupId,limit } = targetData
        return new Promise((resolve, reject) => {
            userbasecode({ startDate, endDate, realUserId, projectId, groupId, limit })
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  projectTimeCode({ commit }, targetData) {
      const { startDate, endDate, projectId, realUserId, timeType,limit } = targetData
        return new Promise((resolve, reject) => {
            projectTimeCode({ startDate, endDate, projectId, realUserId, timeType,limit })
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  groupbasecode({ commit }, targetData) {
      const { startDate, endDate} = targetData
        return new Promise((resolve, reject) => {
            groupbasecode({ startDate, endDate })
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  projectbasecode({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            projectbasecode(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  userinfo({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            userinfo(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  getCodeTotal({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            getCodeTotal(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  exportUserCode({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            exportUserCode(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
}

export default {
    namespaced: true,
    state,
    actions
}
