import qs from 'qs'
const getDefaultState = () => {
    return {
    }
}

const state = getDefaultState()

const actions = {
    loginOut({ commit }, targetData) {
      return new Promise((resolve, reject) => {
          resolve()
            // loginOut({})
            //     .then(response => {
            //         resolve(response)
            //     })
            //     .catch(error => {
            //         reject(error)
            //     })
        })
    },
}

export default {
    namespaced: true,
    state,
    actions
}
