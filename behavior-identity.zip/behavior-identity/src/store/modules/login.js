import { resetRouter } from '@/router'
import { setUserId } from '@/utils/auth'
import qs from 'qs'

const getDefaultState = () => {
  return {
    token: ''
  }
}

const state = getDefaultState()
const mutation = {
  setToken: (state, token) => {
    state.token = token
  }
}

const actions = {
  login({ commit }, targetData) {
    return new Promise((resolve, reject) => {
      setUserId(true)
      resolve()
   })
  }
}

export default {
  namespaced: true,
  state,
  mutation,
  actions
}

