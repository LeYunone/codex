import { getList, getProjectNameList, getPersonList, getStoragesList, storageList, syncStorage } from '@/api/commit/commit'
import qs from 'qs'
const getDefaultState = () => {
  return {
    columns1: [
        {
          title: '项目名称',
          align: 'center',
          key: 'projectName'
        },
        {
          title: 'commitId',
          align: 'center',
          key: 'commitId'
        },
        {
          title: '提交人',
          align: 'center',
          key: 'userName'
        },
        {
          title: '提交信息',
          align: 'left',
          key: 'message',
          width: '300'
        },
        {
          title: '时间',
          align: 'center',
          key: 'commitDateStr'
        },
          {
          title: '总量',
          align: 'center',
          className: 'all-class',
          children: [
            {
              title: '新增量',
              slot: 'additions',
              align: 'center',
              width: 120,
              // sortable: true,
              className: 'additions-class'
            },
            {
              title: '删除量',
              slot: 'deletions',
              align: 'center',
              width: 120,
              // sortable: true,
              className: 'deletions-class'
            }
          ]
        }
      ],
    }
}

const state = getDefaultState()

const actions = {
  getList({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            getList(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  getProjectNameList({ commit }, targetData) {
    const { realUserId, storageId, type } = targetData
        return new Promise((resolve, reject) => {
            getProjectNameList({ realUserId, storageId, type })
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  getPersonList({ commit }, targetData) {
    const { projectId, storageId, type } = targetData
        return new Promise((resolve, reject) => {
            getPersonList({ projectId, storageId, type })
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
  getStoragesList({ commit }, targetData) {
    const { projectId, realUserId } = targetData
        return new Promise((resolve, reject) => {
            getStoragesList({ projectId, realUserId })
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
    storageList({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            storageList(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  },
        syncStorage({ commit }, targetData) {
        return new Promise((resolve, reject) => {
            syncStorage(targetData)
                .then(response => {
                    resolve(response)
                })
                .catch(error => {
                    reject(error)
                })
        })
  }
}

export default {
    namespaced: true,
    state,
    actions
}
