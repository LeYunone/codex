import {
  addVideo,
  videoList,
  projectList,
  getVideoDetail,
  delVideo,
  getProConfig,
  setConfig,
  setDisabled,
  setEnabled,
  editVideo
} from "@/api/videoConfig/video";
import qs from "qs";
const getDefaultState = () => {
  return {};
};

const state = getDefaultState();

const actions = {
  addVideo({ commit }, targetData) {
    const {
      appId,
      availableAreaId,
      name,
      secretKey,
      server,
      type,
      portList
    } = targetData;
    return new Promise((resolve, reject) => {
      addVideo({
        appId: appId,
        availableAreaId: availableAreaId,
        name: name,
        secretKey: secretKey,
        server: server,
        type: type,
        portList: portList
      })
        .then(response => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    });
  },

  videoList({ commit }, targetData) {
    const { pageIndex, pageSize, sortMode, sortField, type } = targetData;
    return new Promise((resolve, reject) => {
      videoList({
        pageIndex: pageIndex,
        pageSize: pageSize,
        sortMode: sortMode,
        sortField: sortField,
        type: type
      })
        .then(response => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    });
  },
  projectList({ commit }, targetData) {
    const {
      pageIndex,
      pageSize,
      sortMode,
      sortField,
      communityId,
      communityName
    } = targetData;
    return new Promise((resolve, reject) => {
      projectList({
        pageIndex: pageIndex,
        pageSize: pageSize,
        sortMode: sortMode,
        sortField: sortField,
        communityId: communityId,
        communityName: communityName
      })
        .then(response => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    });
  },

  getVideoDetail({ commit }, targetData) {
    const { id } = targetData;
    return new Promise((resolve, reject) => {
      getVideoDetail(
        qs.stringify({
          id: id
        })
      )
        .then(response => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    });
  },

  delVideo({ commit }, targetData) {
    const { id } = targetData;
    return new Promise((resolve, reject) => {
      delVideo(
        qs.stringify({
          id: id
        })
      )
        .then(response => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    });
  },

  getProConfig({ commit }, targetData) {
    const { communityId } = targetData;
    return new Promise((resolve, reject) => {
      getProConfig(
        qs.stringify({
          communityId: communityId
        })
      )
        .then(response => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    });
  },

  setConfig({ commit }, targetData) {
    const { communityId, availableAreaId } = targetData;
    return new Promise((resolve, reject) => {
      setConfig({
        communityId: communityId,
        availableAreaId: availableAreaId
      })
        .then(response => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    });
  },

  setDisabled({ commit }, targetData) {
    const { id } = targetData;
    return new Promise((resolve, reject) => {
      setDisabled(
        qs.stringify({
          id: id
        })
      )
        .then(response => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    });
  },
  setEnabled({ commit }, targetData) {
    const { id } = targetData;
    return new Promise((resolve, reject) => {
      setEnabled(
        qs.stringify({
          id: id
        })
      )
        .then(response => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    });
  },

  editVideo({ commit }, targetData) {
    const {
      appId,
      availableAreaId,
      name,
      secretKey,
      server,
      type,
      id,
      portList
    } = targetData;
    return new Promise((resolve, reject) => {
      editVideo({
        appId: appId,
        availableAreaId: availableAreaId,
        name: name,
        secretKey: secretKey,
        server: server,
        type: type,
        id: id,
        portList: portList
      })
        .then(response => {
          resolve(response);
        })
        .catch(error => {
          reject(error);
        });
    });
  }
};

export default {
  namespaced: true,
  state,
  actions
};
