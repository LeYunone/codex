import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

// 默认路由表
export const constantRoutes = [
  {
    path: '/',
    component: () => import('@/views/login/Login')
  },
  {
    path: '/baseData',
    component: Layout,
    redirect: '/baseData/personManger',
    meta: {
      title: '基础数据',
      icon: 'nested'
    },
    children: [
      {
        path: 'gitPersonManger',
        name: 'gitPersonManger',
        component: () => import('@/views/baseData/gitPersonManger'),
        meta: { title: 'Git账号列表', icon: 'git' }
      },
      {
        path: 'videoConfig',
        name: 'videoConfig',
        component: () => import('@/views/videoConfig/index'),
        meta: { title: 'Git Project', icon: 'sourceCode' }
      },
      {
        path: 'personManger',
        name: 'personManger',
        component: () => import('@/views/baseData/personManger'),
        meta: { title: '人员管理', icon: 'person' }
      },
      {
        path: 'deptManager',
        name: 'deptManager',
        component: () => import('@/views/baseData/deptManager'),
        meta: { title: '部门管理', icon: 'dept' }
      },
      {
        path: 'projectManager',
        name: 'projectManager',
        component: () => import('@/views/baseData/projectManager'),
        meta: { title: '项目管理', icon: 'list' }
      },

    ]
  },
  {
    path: '/commit',
    component: Layout,
    redirect: '/commit/history',
    children: [
      {
        path: 'history',
        name: 'history',
        component: () => import('@/views/commit/history'),
        meta: { title: '代码提交明细', icon: 'records' }
      }
    ]
  },
  {
    path: '/bugModule',
    component: Layout,
    redirect: '/bugModule/bugDetails',
    children: [
      {
        path: 'bugDetails',
        name: 'bugDetails',
        component: () => import('@/views/bugModule/index'),
        meta: { title: 'BUG明细', icon: 'bug' }
      },
    ]
  },
  {
    path: '/chart',
    component: Layout,
    redirect: '/chart/allchart',
    meta: {
      title: '代码提交数据分析',
      icon: 'echarts'
    },
    children: [
      {
        path: 'allchart',
        name: 'allchart',
        component: () => import('@/views/echartsShow/allChart'),
        meta: { title: '代码提交总量', icon: 'echart-line' }
      },
      {
        path: 'deptChart',
        name: 'alldeptChartchart',
        component: () => import('@/views/echartsShow/deptChart'),
        meta: { title: '部门代码量', icon: 'pie' }
      },
      {
        path: 'chartTime',
        name: 'chartTime',
        component: () => import('@/views/echartsShow/chartTime'),
        meta: { title: '项目代码总量', icon: 'zhuzhaung' }
      },
      {
        path: 'personnelAnalysis',
        name: 'personnelAnalysis',
        component: () => import('@/views/echartsShow/personnelAnalysis'),
        meta: { title: '人员分析', icon: 'personAnalysis' }
      }
    ]
  },
  {
    path: '/codeQuality',
    component: Layout,
    redirect: '/codeQuality/personQuality',
    meta: {
      title: '代码质量',
      icon: 'nested'
    },
    children: [
      {
        path: 'personQuality',
        name: 'personQuality',
        component: () => import('@/views/codeQuality/personQuality'),
        meta: { title: '人员代码质量', icon: 'personBug' }
      },
      {
        path: 'deptQuality',
        name: 'deptQuality',
        component: () => import('@/views/codeQuality/deptQuality'),
        meta: { title: '部门代码质量', icon: 'deptBug' }
      },
      {
        path: 'projectQuality',
        name: 'projectQuality',
        component: () => import('@/views/codeQuality/projectQuality'),
        meta: { title: '项目代码质量', icon: 'projectBug' }
      }
    ]
  },
  {
    path: '/video',
    component: Layout,
    redirect: '/video/videoConfig',
    children: [
      {
        path: 'codeDetial',
        name: 'codeDetial',
        hidden: true,
        component: () => import('@/views/videoConfig/codeDetail')
      }
    ]
  },
  {
    path: '/warning',
    component: Layout,
    redirect: '/warning/warnList',
    children: [
      {
        path: 'warnList',
        name: 'warnList',
        component: () => import('@/views/warning/warnList'),
        meta: { title: '监测预警', icon: 'warning' }
      }
      // {
      //   path: 'warningDetail',
      //   name: 'warningDetail',
      //   component: () => import('@/views/warning/index'),
      //   meta: { title: '监测预警', icon: 'warning' }
      // }
    ]
  },
  // 404放置在最后面
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () =>
  new Router({
    // mode: 'history', // require service support
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRoutes
  })

const router = createRouter()

export function resetRouter() {
  debugger
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
