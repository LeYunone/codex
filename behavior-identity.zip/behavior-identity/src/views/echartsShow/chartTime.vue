<style lang="scss" scoped>
.main-body{
  padding: 20px 0;
  background: #fff;
}
#myChart{
  width: 100%;
  height: 650px;
  background: #fff;
  border-radius: 0 0 15px 15px;
  margin-top: 20px;
}
.eCharts-filter{
  width: 100%;
  display: flex;
  justify-content: flex-end;
  margin-bottom: 25px;
  .filter-item{
  width: 45%;
  margin-right:15px;
}
}
::v-deep .ivu-date-picker{
  width: 100%;
}
</style>
<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>项目代码总量</h3>
    </div>
    <div class="main-body">
      <div class="eCharts-filter">
        <Row class="filter-item" type="flex" justify="space-around">
          <i-col :span="6">
            <Input v-model="limit" placeholder="请输入提交数量阈值" size="large" type="number" clearable @on-blur="changeLimit" @on-clear="changeLimit"></Input>
          </i-col>
          <i-col :span="6">
            <Input v-model="maxNum" placeholder="请输入限制项目数量" size="large" type="number" clearable @on-blur="changeMaxNum" @on-clear="changeMaxNum"></Input>
          </i-col>
          <i-col :span="10" class="text-left">
            <div class="date-box">
              <DatePicker type="daterange" :options="options2" placement="bottom-end" placeholder="请选择日期" size="large" :value="selectTimeValue" @on-change="changeTime"></DatePicker>
            </div>
          </i-col>
        </Row>
      </div>
      <div>
        <div v-if="hasData" id="myChart" ref="lineChart" class="line-box" />
        <div v-else class="main-none">
          <noListData :no-data-txt="noDataTxt"></noListData>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { formatDateTime } from '@/utils/commFunction'
import myMixins from '@/utils/myMixins'
export default {
  name: 'DeptChart',
  mixins: [myMixins],
  data() {
    return {
      chart: null,
      options: {},
      deptList: [],
      groupId: '',
      series: [],
      startDate: '',
      endDate: '',
      hasData: false,
      noDataTxt: '暂无数据',
      dataObj: {
        xData: [],
        categoriesList: []
      },
      limit: '1000',
      selectTimeValue: [],
      maxNum: 15
    }
  },
  watch: {
    dataObj: {
      deep: true,
      immediate: true,
      handler: function (val) {
      this.$nextTick(() => {
        this.initOptions(val.categoriesList, val.xData)
        this.updateChart(this.options)
      })
      }
    }
  },
  created () {
    const end = new Date()
    const start = new Date()
    start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
    this.startDate = formatDateTime(start, 'yyyy-MM-dd')
    this.endDate = formatDateTime(end, 'yyyy-MM-dd')
    this.selectTimeValue[0] = this.startDate
    this.selectTimeValue[1] = this.endDate
  },
  mounted() {
    this.getData()
  },
  methods: {
    initOptions(optionsCategories = [], seriesData = []) {
      this.options = {
        chart: {
          type: 'bar'
        },
        title: {
          text: ''
        },
        xAxis: {
          categories: optionsCategories
        },
        yAxis: {
          min: 0,
          title: {
            text: '代码量/行'
          },
          stackLabels: { // 堆叠数据标签
            enabled: true,
            style: {
              fontWeight: 'bold',
              color: (this.$hCharts.theme && this.$hCharts.theme.textColor) || 'gray'
            }
          }
        },
        legend: {
		      align: 'right',
		      x: -30,
		      verticalAlign: 'bottom',
		      y: 25,
		      floating: true,
		      backgroundColor: (this.$hCharts.theme && this.$hCharts.theme.background2) || 'white',
		      borderColor: '#CCC',
		      borderWidth: 1,
          shadow: false,
          reversed: true
        },
        exporting: {
          enabled: true
        },
        tooltip: {
          formatter: function () {
            return '<b>' + this.x + '</b><br/>' +
              this.series.name + ': ' + this.y + '<br/>' +
              '总量: ' + this.total
		      }
        },
        plotOptions: {
            series: {
            stacking: 'normal'
        },
		      column: {
			      stacking: 'normal',
			      dataLabels: {
				      enabled: true,
				      color: (this.$hCharts.theme && this.$hCharts.theme.dataLabelsColor) || 'white',
				      style: {
					      // 如果不需要数据标签阴影，可以将 textOutline 设置为 'none'
					      textOutline: '1px 1px black'
				      }
			      }
		      }
	      },
        series: seriesData,
        colors: ['#5A9CDD', '#c1d8ec']
      }
    },
     getData() {
      this.hasData = false
      let params = {
        startDate: this.startDate,
        endDate: this.endDate,
        projectId: '',
        userId: '',
        groupId: this.groupId,
        limit: this.limit,
        maxNum: this.maxNum
      }
      this.$store
        .dispatch('eCharts/projectbasecode', params)
        .then(response => {
          console.log('初始response', response)
          this.series = response.data.series
          if (response.data.series[0].data.length === 0) {
            this.hasData = false
          } else {
            this.hasData = true
            this.$set(this.dataObj, 'xData', response.data.series)
            this.$set(this.dataObj, 'categoriesList', response.data.xchart)
          }
        })
        .catch(() => {})
    },
    updateChart(options) {
      this.$el = document.getElementById('myChart')
      this.chart = new this.$hCharts.Chart(this.$el, options)
    },
    changeDept(value) {
      this.getData()
    },
    changeTime(data) {
      this.selectTime = data
      this.startDate = data[0]
      this.endDate = data[1]
      this.getData()
    },
    changeLimit () {
      console.log('limit', this.limit)
      this.getData()
    },
    changeMaxNum () {
      this.getData()
    }
  }
}
</script>

