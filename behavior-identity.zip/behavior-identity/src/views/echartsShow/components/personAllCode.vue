<template>
  <div>
      <div class="inner-container">
            <div class="inner-header">
              <Row type="flex" justify="space-between">
                <Col span="8">
                  <Card shadow>
                    <div class="item">
                      <div class="left"><img src="../../assets/image/sum.png" alt=""></div>
                      <div class="right">
                        <p class="number">{{codeTotal}}</p>
                        <p class="title">代码总数</p>
                        <p class="sub-title">Total number of codes</p>
                      </div>
                    </div>
                  </Card>
                </Col>
                <Col span="8">
                  <Card shadow>
                    <div class="item">
                      <div class="left"><img src="../../assets/image/add.png" alt=""></div>
                      <div class="right">
                        <p class="number">{{codeAdditions}}</p>
                        <p class="title">新增代码</p>
                        <p class="sub-title">Total number of codes</p>
                      </div>
                    </div>
                  </Card>
                </Col>
                <Col span="8">
                  <Card shadow>
                    <div class="item">
                      <div class="left"><img src="../../assets/image/dsc.png" alt=""></div>
                      <div class="right">
                        <p class="number">{{codeDeletions}}</p>
                        <p class="title">删除代码</p>
                        <p class="sub-title">Total number of codes</p>
                      </div>
                    </div>
                  </Card>
                </Col>
              </Row>
            </div>
            <div class="inner-eCharts">
              <div class="eCharts-filter">
                <Row class="filter-item" type="flex" justify="space-around">
                  <i-col :span="10" class="text-left">
                    <Select v-model="userId" size="large" placeholder="请选择项目成员" filterable clearable @on-change="changeDept">
                      <Option v-for="item in personList" :value="item.userId" :key="item.userId+item.userName">{{ item.userName }}</Option>
                    </Select>
                  </i-col>
                  <i-col :span="10" class="text-left">
                    <DatePicker type="month" placeholder="请选择月份" size="large" @on-change="changeTime"></DatePicker>
                  </i-col>
                </Row>
              </div>
              <div id="myChart" class="line-box" ref="lineChart">
              </div>
            </div>
          </div>
  </div>
</template>

<script>
export default {
  name: 'PersonAllCode',

  data() {
    return {
      
    };
  },

  mounted() {
    
  },

  methods: {
    
  },
};
</script>

<style lang="scss" scoped>
.inner-container{
  margin-top: 20px;
  .inner-header{
    .item{
      display: flex;
      justify-content: center;
      align-items: center;
      width: 70%;
      border-radius: 15px;
      .left{
        margin-right: 15%;
        img{
          width: 75px;
          height: 75px;
        }
      }
      .right{
        .number{
          font-size: 30px;
          font-family: Helvetica;
          font-weight: 700;
          color: #289aec;
          line-height: 35px;
          margin-bottom:10px;
        }
        .title{
          font-size: 1.125rem;
          font-weight: 400;
          color: #455a64;
          line-height: 1.125rem;
          margin-bottom: 0.625rem;
        }
        .sub-title{
          font-size: .875rem;
          font-family: Helvetica;
          font-weight: 400;
          color: #aeb5bb;
        }
      }
      // background: #fff;
    }
  }
  .inner-eCharts{
    margin-top: 20px;
    background: #fff;
    padding-top: 25px;
    .eCharts-filter{
      width: 100%;
      display: flex;
      justify-content: center;
    }
    #myChart{
      width: 100%;
      height: 520px;
      background: #fff;
      border-radius: 0 0 15px 15px;
    }
  }
}
</style>