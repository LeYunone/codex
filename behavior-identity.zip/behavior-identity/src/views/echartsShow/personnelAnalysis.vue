<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>项目列表</h3>
    </div>
    <div class="main-body">
      <div class="main-title margin-bottom-20">
        <Row :gutter="20">
          <i-col :span="4">
            <Input v-model="limit" placeholder="请输入提交数量阈值" size="large" type="number" clearable></Input>
          </i-col>
          <i-col :span="4" class="text-left">
            <Select v-model="groupId" size="large" placeholder="请选择部门" filterable clearable>
              <Option v-for="item in deptList" :key="item.groupId+item.groupName" :value="item.groupId">{{ item.groupName }}</Option>
            </Select>
          </i-col>
          <i-col :span="4" class="text-left">
            <Select v-model="realUserId" size="large" placeholder="请选择人员" filterable clearable>
              <Option v-for="item in personList" :key="item.realUserId+item.realUserName" :value="item.realUserId">{{ item.realUserName }}</Option>
            </Select>
          </i-col>
          <i-col :span="4" class="text-left">
            <Select v-model="projectId" size="large" placeholder="请选择项目名称" filterable clearable>
              <Option v-for="item in projectList" :key="item.projectId+item.projectName" :value="item.projectId">{{ item.projectName }}</Option>
            </Select>
          </i-col>
          <i-col :span="5">
            <div class="date-box">
              <DatePicker type="daterange" :options="options2" placement="bottom-end" placeholder="请选择日期" style="width: 200px" size="large" @on-change="changeTime" :value="selectTimeValue"></DatePicker>
            </div>
          </i-col>
          <i-col :span="1">
            <Button v-debounce size="large" type="primary" @click="searchList">
              <span class="fa fa-search"></span>
            </Button>
          </i-col>
          <i-col :span="1">
            <Button v-debounce size="large" type="primary" @click="exportExcel">
              导出
            </Button>
          </i-col>
        </Row>
      </div>
      <!-- 卡片 -->
      <Row type="flex" class="card-main" :gutter="15">
        <Col span="6">
          <Card shadow>
            <div class="item first-box">
              <div class="left"><img src="../../assets/image/sum.png" alt=""></div>
              <div class="right">
                <p class="number">{{ codeInfo.total }}</p>
                <p class="title">代码总数</p>
                <p class="sub-title">Number of all codes</p>
              </div>
            </div>
          </Card>
        </Col>
        <Col span="6">
          <Card shadow>
            <div class="item second-box">
              <div class="left"><img src="../../assets/image/add.png" alt=""></div>
              <div class="right">
                <p class="number">{{ codeInfo.additions }}</p>
                <p class="title">新增代码</p>
                <p class="sub-title">Number of new codes</p>
              </div>
            </div>
          </Card>
        </Col>
        <Col span="6">
          <Card shadow>
            <div class="item third-box">
              <div class="left"><img src="../../assets/image/dsc.png" alt=""></div>
              <div class="right">
                <p class="number">{{ codeInfo.deletions }}</p>
                <p class="title">删除代码</p>
                <p class="sub-title">Number of deleted codes</p>
              </div>
            </div>
          </Card>
        </Col>
        <Col span="6">
          <Card shadow>
            <div class="item fourth-box">
              <div class="left"><img src="../../assets/image/project.png" alt=""></div>
              <div class="right">
                <p class="number">{{ codeInfo.projectNumber }}</p>
                <p class="title">项目总数</p>
                <p class="sub-title">Total number of projects</p>
              </div>
            </div>
          </Card>
        </Col>
      </Row>
      <div v-if="hasList">
        <div class="page-table margin-bottom-20">
          <Table :columns="columns10" :data="dataList">
            <template slot="actions" slot-scope="row">
              <span v-if="!row.row.users" class="no-tip">暂无</span>
              <!-- <div v-else-if="row.row.users.length<=5"> -->
              <div v-else>
                <Tag v-for="(item,index) in row.row.users" :key="index" color="cyan">
                  {{ item.realUserName?item.realUserName:item.userName }}
                </Tag>
              </div>
              <!-- <Button type="info" ghost icon="md-people" @click="detail(row)" v-else>项目成员</Button> -->
            </template>
          </Table>
        </div>
        <div class="page-footer text-center">
          <Page
            :total="itemTotal"
            :page-size-opts="[10, 20, 40]"
            :current="pageIndex"
            :page-size="pageSize"
            show-elevator
            show-total
            show-sizer
            @on-page-size-change="getPageSize"
            @on-change="getPageList"
          />
        </div>
      </div>
      <div v-else class="main-none">
        <noListData></noListData>
      </div>
    </div>
    <div>
    </div>
  </div>
</template>
<script>
import myMixins from '@/utils/myMixins'
import { formatDateTime } from '@/utils/commFunction'
  export default {
    mixins: [myMixins],
    data () {
      return {
        columns10: [
          {
            title: '姓名',
            key: 'realUserName',
            align: 'center'
          },
          {
            title: '部门',
            key: 'groupName',
            align: 'center'
          },
          {
            title: '删除总行数',
            key: 'deletions',
            align: 'center',
            sortable: true
          },
          {
            title: '新增总行数',
            key: 'additions',
            align: 'center',
            sortable: true
          },
          {
            title: '代码总行数',
            key: 'total',
            align: 'center',
            sortable: true
          },
          {
            title: '项目总数',
            key: 'projectNumber',
            align: 'center'
          }
        ],
        personList: [],
        dataList: [],
        hasList: false,
        pageSize: 10,
        pageIndex: 1,
        itemTotal: 0,
        realUserId: '',
        projectId: '',
        deptList: [],
        groupId: '',
        limit: '1000',
        startDate: '',
        endDate: '',
        projectList: [],
        codeInfo: {
          total: '',
          additions: '',
          deletions: '',
          projectNumber: ''
        },
        selectTimeValue: []
      }
    },
    mounted() {
      this.getList()
      this.getPersonList()
      this.getGroupList()
      this.getProjectNameList()
      this.getCodeTotal()
  },
    created () {
    const end = new Date()
    const start = new Date()
    start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
    this.startDate = formatDateTime(start, 'yyyy-MM-dd')
    this.endDate = formatDateTime(end, 'yyyy-MM-dd')
    this.selectTimeValue[0] = this.startDate
    this.selectTimeValue[1] = this.endDate
    },
    methods: {
      // 分页
      getPageList(index) {
        console.log(index)
        this.pageIndex = index
        this.getList()
        this.getCodeTotal()
      },
      getPageSize(size) {
        this.pageIndex = 1
        this.pageSize = size
        this.getList()
        this.getCodeTotal()
      },
      getPersonList() {
        let params = {
          type: 0
        }
        this.$store
        .dispatch('commit/getPersonList', params)
        .then(response => {
          this.personList = response.data
        })
        .catch(() => {})
      },
      getCodeTotal () {
        let Info = {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        startDate: this.startDate,
        endDate: this.endDate,
        realUserId: this.realUserId,
        groupId: this.groupId,
        limit: this.limit,
        projectId: this.projectId
      }
        this.$store
        .dispatch('eCharts/getCodeTotal', Info)
        .then(response => {
          this.codeInfo = response.data
        })
        .catch(() => {})
      },
      getGroupList () {
      this.$store
        .dispatch('deptManager/getDeptList')
        .then(response => {
          this.deptList = response.data
        })
        .catch(() => {})
      },
      searchList () {
        this.index = 1
        this.getList()
        this.getCodeTotal()
      },
    getList() {
      let Info = {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        startDate: this.startDate,
        endDate: this.endDate,
        realUserId: this.realUserId,
        groupId: this.groupId,
        limit: this.limit,
        projectId: this.projectId
      }
      this.$store
        .dispatch('eCharts/userinfo', Info)
        .then(response => {
          const res = response.data
          if (res.records && res.records.length == 0) {
            this.hasList = false
          } else {
            this.hasList = true
            this.dataList = res.records
            this.itemTotal = res.total
          }
        })
        .catch(() => {})
      },
      detail(row) {
        console.log(row.row.users)
        this.$refs.projectPerson.dialogVisible = true
        this.$refs.projectPerson.row = row.row.users
      },
      changeTime (data) {
        this.startDate = data[0]
        this.endDate = data[1]
      },
      getProjectNameList() {
      let params = {
        userId: this.userId,
        storageId: this.storageId,
        type: 1
      }
      this.$store
        .dispatch('commit/getProjectNameList', params)
        .then(response => {
          this.projectList = response.data
        })
        .catch(() => {})
      },
      exportExcel () {
        let Info = {
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,
          startDate: this.startDate,
          endDate: this.endDate,
          realUserId: this.realUserId,
          groupId: this.groupId,
          limit: this.limit,
          projectId: this.projectId
        }
        this.$store
        .dispatch('eCharts/exportUserCode', Info)
          .then(response => {
          const blob = new Blob([response.data], { type: 'application/vnd.ms-excel' })
          const fileName = response.headers['content-disposition'].split(';')[1].split('filename=')[1]
          const downloadElement = document.createElement('a')
          const href = window.URL.createObjectURL(blob) // 创建下载的链接
          downloadElement.href = href
          downloadElement.download = decodeURIComponent(fileName) // 下载后文件名
          document.body.appendChild(downloadElement)
          downloadElement.click() // 点击下载
          document.body.removeChild(downloadElement) // 下载完成移除元素
          window.URL.revokeObjectURL(href) // 释放掉blob对象
        })
        .catch(() => {})
      },
    }
  }
</script>
<style lang="scss" scoped>
  ::v-deep .ivu-date-picker{
    width: 100%;
  }
  .no-tip{
    color: #9999;
  }
  ::v-deep .ivu-table-cell{
    padding: 10px 0;
  }
  ::v-deep.ivu-date-picker{
      width: 100%!important;
  }
  .card-main{
    margin: 20px 0;
    .item{
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      border-radius: 15px;
      padding: 20px 10px;
      .left{
        margin-right: 15%;
        img{
          width: 75px;
          height: 75px;
          border-radius: 50%;
        }
      }
      .right{
        .number{
          font-size: 30px;
          font-family: Helvetica;
          // font-weight: 700;
          color: #289aec;
          line-height: 35px;
          margin-bottom:10px;
        }
        .title{
          font-size: 1.125rem;
          font-weight: 400;
          color: #455a64;
          line-height: 1.125rem;
          margin-bottom: 0.625rem;
        }
        .sub-title{
          font-size: .875rem;
          font-family: Helvetica;
          font-weight: 400;
          color: #aeb5bb;
        }
      }
    }
    .first-box{
      background-image: radial-gradient( circle 1224px at 10.6% 8.8%,  rgba(255,255,255,1) 0%, #99cafb75 100.2%)
    }
    .second-box{
      background-image: radial-gradient( circle 1224px at 10.6% 8.8%,  rgba(255,255,255,1) 0%,  #3eecac73);
    }
    .third-box{
      background-image: radial-gradient( circle 1224px at 10.6% 8.8%,  rgba(255,255,255,1) 0%,  #f56c6c6b);
    }
    .fourth-box{
      background-image: radial-gradient( circle 1224px at 10.6% 8.8%,  rgba(255,255,255,1) 0%,  #e6a23c75)
    }
  }
  ::v-deep .ivu-card-body{
    padding: 0!important;
    // border-radius: 15px!important;
  }
  ::v-deep .ivu-card{
    border-radius: 15px!important;
  }
</style>
