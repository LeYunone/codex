<style lang="scss" scoped>
.page{
  padding-top: 15px;
}
::v-deep .ivu-tag{
  word-break: keep-all;
  overflow: inherit;
}
::v-deep .ivu-btn-dashed {
    color: #2db7f5;
    border-color: #2db7f5;
}
::v-deep .ivu-tabs-bar{
  border-bottom: none;
}
::v-deep .ivu-card-body{
  height: 150px;
  display: flex;
  align-items: center;
}
.inner-container{
  margin-top: 20px;
  .inner-header{
    .item{
      display: flex;
      justify-content: center;
      align-items: center;
      width: 70%;
      border-radius: 15px;
      .left{
        margin-right: 15%;
        img{
          width: 75px;
          height: 75px;
        }
      }
      .right{
        .number{
          font-size: 30px;
          font-family: Helvetica;
          font-weight: 700;
          color: #289aec;
          line-height: 35px;
          margin-bottom:10px;
        }
        .title{
          font-size: 1.125rem;
          font-weight: 400;
          color: #455a64;
          line-height: 1.125rem;
          margin-bottom: 0.625rem;
        }
        .sub-title{
          font-size: .875rem;
          font-family: Helvetica;
          font-weight: 400;
          color: #aeb5bb;
        }
      }
      // background: #fff;
    }
  }
  .inner-eCharts{
    // margin-top: 20px;
    background: #fff;
    padding: 25px 0;
    margin: 20px 0;
    border-radius:10px;
    .eCharts-filter{
      width: 100%;
      display: flex;
      justify-content: flex-end;
    }
    #myChart{
      width: 100%;
      height: 520px;
      background: #fff;
      border-radius: 0 0 15px 15px;
      margin-top: 20px;
    }
  }
}
.filter-item{
  width: 65%;
  margin-right:15px!important;
}
::v-deep .ivu-date-picker{
  width:100%;
}
</style>
<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
    </div>
    <div class="main-body">
      <div class="inner-container">
        <div class="inner-eCharts">
          <div class="eCharts-filter">
            <Row class="filter-item" type="flex" justify="end" align="middle" :gutter="15">
              <i-col :span="3">
                <RadioGroup v-model="type">
                  <Radio label="0">个人</Radio>
                  <Radio label="1">项目</Radio>
                </RadioGroup>
              </i-col>
              <i-col :span="5" class="text-left" v-if="type==='0'">
                <Select v-model="realUserId" size="large" placeholder="请选择项目成员" filterable @on-change="changeDept">
                  <Option v-for="item in personList" :value="item.realUserId" :key="item.realUserId+item.realUserName">{{ item.realUserName }}</Option>
                </Select>
              </i-col>
              <i-col :span="5" class="text-left" v-else>
                <Select v-model="projectId" size="large" placeholder="请选择项目名称" filterable @on-change="changeDeptName">
                  <Option v-for="item in projectList" :value="item.projectId" :key="item.projectId+item.projectName" >{{ item.projectName }}</Option>
                </Select>
              </i-col>
              <i-col :span="5" class="text-left">
                <DatePicker type="month" placeholder="请选择月份" size="large" ref="datePicker" @on-change="changeTime"></DatePicker>
              </i-col>
            </Row>
          </div>
        </div>
        <div class="inner-header">
          <Row type="flex" justify="space-between" :gutter="15">
            <Col span="8">
              <Card shadow>
                <div class="item">
                  <div class="left"><img src="../../assets/image/sum.png" alt=""></div>
                  <div class="right">
                    <p class="number">{{codeTotal}}</p>
                    <p class="title">代码总数</p>
                    <p class="sub-title">Number of all codes</p>
                  </div>
                </div>
              </Card>
            </Col>
            <Col span="8">
              <Card shadow>
                <div class="item">
                  <div class="left"><img src="../../assets/image/add.png" alt=""></div>
                  <div class="right">
                    <p class="number">{{codeAdditions}}</p>
                    <p class="title">新增代码</p>
                    <p class="sub-title">Number of new codes</p>
                  </div>
                </div>
              </Card>
            </Col>
            <Col span="8">
              <Card shadow>
                <div class="item">
                  <div class="left"><img src="../../assets/image/dsc.png" alt=""></div>
                  <div class="right">
                    <p class="number">{{codeDeletions}}</p>
                    <p class="title">删除代码</p>
                    <p class="sub-title">Number of deleted codes</p>
                  </div>
                </div>
              </Card>
            </Col>
          </Row>
        </div>
        <div class="inner-eCharts">
          <div id="myChart" class="line-box" ref="lineChart" v-if="hasData"/>
          <div class="main-none" v-else>
            <noListData :noDataTxt="noDataTxt"></noListData>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  name: "message",
  data() {
    return {
      chart: null,
      options: {},
      personList: [],
      projectList: [],
      startDate: '',
      endDate: '',
      codeAdditions: 0,
      codeDeletions: 0,
      codeTotal: 0,
      type: '0',
      projectId: '',
      realUserId: '',
      hasData: false,
      noDataTxt: '暂无数据',
      dataObj: {
        series: [],
        categories: [],
        color: '',
        name: ''
      }
    }
  },
  computed: {},
  created() {
  },
  mounted() {
    this.getPersonList()
    // this.getProjectNameList()
    this.getDataPerson(this.realUserId)
  },
  watch: {
    'type'(newValue, oldVal) {
      this.type = newValue
      this.$refs.datePicker.handleClear()
      if (this.type === '0') {
        this.$nextTick(() => {
          setTimeout(() => {
            this.getDataPerson(this.realUserId)
          }, 100)
        })
      } else {
        this.$nextTick(() => {
          setTimeout(() => {
            this.getProjectNameList()
          }, 100)
        })
      }
      this.$forceUpdate()
    },
    'startDate'(newValue, oldVal) {
    if (this.type === '0') {
        this.$nextTick(() => {
          setTimeout(() => {
            this.getDataPerson(this.realUserId)
          }, 100)
        })
      } else {
        this.$nextTick(() => {
          setTimeout(() => {
            this.getDataDept(this.projectId)
          }, 100)
        })
      }
      this.$forceUpdate()
    },
    dataObj: {
      deep: true,
      immediate: true,
      handler: function (val) {
      this.$nextTick(() => {
        this.initOptions(val.categories, val.series, val.color, val.name)
        this.updateChart(this.options)
      })
      }
    }
  },
  methods: {
    initOptions (categories = [], series = [], color = 'rgb(252,188,82)', name = '') {
      this.options = {
        chart: {
          type: 'area'
        },
        title: {
          text: ''
        },
        subtitle: {
          text: ''
        },
        xAxis: {
          categories: categories
        },
        yAxis: {
          title: {
            text: '代码量'
          },
        },
        tooltip: {
          split: true,
          valueSuffix: ''
        },
        plotOptions: {
          area: {
            stacking: 'normal',
            lineColor: color,
            lineWidth: 1,
            marker: {
              lineWidth: 1,
              lineColor: color
            }
          }
        },
        series: [{
          data: series,
          name: name
        }],
        // series: series,
        colors: [color]
      }
    },
    updateChart(options) {
      this.$el = document.getElementById('myChart')
      this.chart = new this.$hCharts.Chart(this.$el, options)
    },
    // 下拉列表（项目）
    getProjectNameList() {
      let params = {
        type: 1
      }
      this.$store
        .dispatch("commit/getProjectNameList", params)
        .then(response => {
          this.projectList = response.data
          this.projectId = this.projectList[0].projectId || ''
          this.getDataDept(this.projectList[0].projectId)
        })
        .catch(() => {});
    },
    // 下拉列表(个人)
    getPersonList() {
      let params = {
        type: 0
      }
      this.$store
        .dispatch("commit/getPersonList", params)
        .then(response => {
          this.personList = response.data
          this.realUserId = this.personList[0].realUserId || ''
          this.getDataPerson(this.personList[0].realUserId)
        })
        .catch(() => {});
    },
    // 获取个人图表数据
    getDataPerson(realUserId = '') {
      let params = {
        startDate: this.startDate,
        endDate: this.endDate,
        timeType: '0',
        realUserId: realUserId === '' ? this.personList[0].realUserId : realUserId
      }
      this.$store
        .dispatch("eCharts/userProjectTimeCode", params)
        .then(response => {
          const res = response.data
          this.codeAdditions = response.data.codeAdditions || 0
          this.codeDeletions = response.data.codeDeletions || 0
          this.codeTotal = response.data.codeTotal || 0
          console.log('1')
          if (response.data.series.length === 0 || response.data.series[0].data.length === 0) {
            this.hasData = false
          } else {
            this.hasData = true
            // this.options.series = response.data.series
            // this.options.xAxis.categories = response.data.xchart
            // this.$el = document.getElementById('myChart')
            // this.chart = new this.$hCharts.Chart(this.$el, this.options)
            this.$set(this.dataObj, 'series', response.data.series[0].data)
            this.$set(this.dataObj, 'categories', response.data.xchart)
            this.$set(this.dataObj, 'color', 'rgb(252,188,82)')
            this.$set(this.dataObj, 'name', response.data.series[0].name)
            console.log('看看个人更新数据----',this.dataObj)
          }
        })
        .catch(() => {})
    },
    // 获取项目图表数据
    getDataDept(projectId = '') {
      let params = {
        startDate: this.startDate,
        endDate: this.endDate,
        timeType: '0',
        projectId: projectId === '' ? this.projectList[0].projectId : projectId,
      }
      this.$store
        .dispatch("eCharts/projectTimeCode", params)
        .then(response => {
          const res = response.data
          this.codeAdditions = response.data.codeAdditions || 0
          this.codeDeletions = response.data.codeDeletions || 0
          this.codeTotal = response.data.codeTotal || 0
          console.log('切换', response.data.xchart)
          let data = response.data.data
          if (!data || data.length === 0 || data.every(item => item === 0)) {
            this.hasData = false
          } else {
            this.hasData = true
            // this.options1.series[0].data = response.data.data
            // this.options1.xAxis.categories = response.data.xchart
            // console.log('this.options1.xAxis.categories', this.options1.xAxis.categories)
            // this.$el = document.getElementById('myChart')
            // this.chart = new this.$hCharts.Chart(this.$el, this.options1)
            this.$set(this.dataObj, 'series', response.data.data)
            this.$set(this.dataObj, 'categories', response.data.xchart)
            this.$set(this.dataObj, 'color', '#B5E8FD')
            this.$set(this.dataObj, 'name', response.data.projectName)
          }
        })
        .catch(() => {})
    },
    changeDept(value) {
      this.$nextTick(() => {
        setTimeout(() => {
          this.getDataPerson(value)
        }, 100)
      })
    },
    changeDeptName(value) {
      this.$nextTick(() => {
        setTimeout(() => {
          this.getDataDept(value)
        }, 100)
      })
    },
    changeTime(data) {
      this.startDate = data
      this.endDate = data
      if (this.type === '0') {
        this.getDataPerson()
      } else {
        this.getDataDept()
      }
    }
  }
};
</script>
