<style lang="scss" scoped>
.main-body{
  padding: 20px 0;
  background: #fff;
}
#myChart{
  width: 100%;
  height: 650px;
  background: #fff;
  border-radius: 0 0 15px 15px;
  margin-top: 20px;
}
.eCharts-filter{
  width: 100%;
  display: flex;
  justify-content: flex-end;
  margin-bottom: 25px;
  .filter-item{
  width: 40%;
}
}
::v-deep .ivu-date-picker{
  width: 100%;
}
</style>
<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>部门代码量</h3>
    </div>
    <div class="main-body">
      <div class="eCharts-filter">
        <Row class="filter-item" type="flex" justify="space-around" gutter="10">
          <i-col :span="7" class="text-left">
            <Select v-model="groupId" size="large" placeholder="请选择部门" filterable clearable @on-change="changeDept">
              <Option v-for="item in deptList" :value="item.groupId" :key="item.groupId+item.groupName">{{ item.groupName }}</Option>
            </Select>
          </i-col>
          <i-col :span="7">
            <Input v-model="limit" placeholder="请输入提交数量阈值" size="large" type="number" clearable @on-blur="changeLimit" @on-clear="handleClear"></Input>
          </i-col>
          <i-col :span="10" class="text-left">
            <div class="date-box">
              <DatePicker type="daterange" :options="options2" placement="bottom-end" placeholder="请选择日期" size="large" @on-change="changeTime"  :value="selectTimeValue"></DatePicker>
            </div>
          </i-col>
        </Row>
      </div>
      <div>
        <div id="myChart" class="line-box" ref="lineChart" v-if="hasData"/>
        <div class="main-none" v-else>
          <noListData :noDataTxt="noDataTxt"></noListData>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { formatDateTime } from '@/utils/commFunction'
import myMixins from '@/utils/myMixins';
export default {
  name: 'DeptChart',
  mixins: [myMixins],
  data() {
    return {
      chart: null,
      options: {},
      deptList: [],
      groupId: '',
      series: [],
      startDate: '',
      endDate: '',
      hasData: false,
      noDataTxt: '暂无数据',
      dataObj: {
        series: [],
        categories: []
      },
      limit: '1000',
      selectTimeValue: []
    }
  },
  watch: {
    dataObj: {
      deep: true,
      immediate: true,
      handler: function (val) {
      this.$nextTick(() => {
        this.initOptions(val.categories, val.series)
        this.updateChart(this.options)
      })
      }
    }
  },
  created () {
    const end = new Date()
    const start = new Date()
    start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
    this.startDate = formatDateTime(start, 'yyyy-MM-dd')
    this.endDate = formatDateTime(end, 'yyyy-MM-dd')
    this.selectTimeValue[0] = this.startDate
    this.selectTimeValue[1] = this.endDate
  },
  mounted() {
    this.getList()
  },
  methods: {
    initOptions(categories = [], series = []) {
      this.options = {
        chart: {
          type: 'column'
        },
        title: {
          text: ''
        },
        xAxis: {
          categories: categories,
          // data: []
        },
        yAxis: {
          min: 0,
          title: {
            text: '代码量/行'
          },
          stackLabels: { // 堆叠数据标签
            enabled: true,
            style: {
              fontWeight: 'bold',
              color: (this.$hCharts.theme && this.$hCharts.theme.textColor) || 'gray'
            }
          }
        },
        legend: {
		      align: 'right',
		      x: -30,
		      verticalAlign: 'bottom',
		      y: 25,
		      floating: true,
		      backgroundColor: (this.$hCharts.theme && this.$hCharts.theme.background2) || 'white',
		      borderColor: '#CCC',
		      borderWidth: 1,
		      shadow: false
	      },
	      tooltip: {
		      formatter: function () {
			      return '<b>' + this.x + '</b><br/>' +
				      this.series.name + ': ' + this.y + '<br/>' +
				      '总量: ' + this.point.stackTotal;
		      }
	      },
        exporting: {
          enabled: true
        },
	      plotOptions: {
		      column: {
			      stacking: 'normal',
			      dataLabels: {
				      enabled: true,
				      color: (this.$hCharts.theme && this.$hCharts.theme.dataLabelsColor) || 'white',
				      style: {
					      // 如果不需要数据标签阴影，可以将 textOutline 设置为 'none'
					      textOutline: '1px 1px black'
				      }
			      }
		      }
	      },
	      series: series,
        colors: ['#B5F3D5', '#eff1fe']
      }
    },
    updateChart(options) {
      this.$el = document.getElementById('myChart')
      this.chart = new this.$hCharts.Chart(this.$el, options)
    },
    initChart() {
      this.$el = document.getElementById('myChart')
      this.chart = new this.$hCharts.Chart(this.$el, this.options)
    },
    getList() {
      this.$store
        .dispatch("deptManager/getDeptList")
        .then(response => {
          this.deptList = response.data
          this.groupId = this.deptList[0].groupId || ''
          this.getData(this.deptList[0].groupId)
        })
        .catch(() => {})
    },
    getData(groupId = '') {
      this.hasData = false
      let params = {
        startDate: this.startDate,
        endDate: this.endDate,
        projectId: '',
        userId: '',
        groupId: groupId === '' ? this.deptList[0].groupId : groupId,
        limit: this.limit
      }
      this.$store
        .dispatch("eCharts/userbasecode", params)
        .then(response => {
          console.log(response.data.series[0].data.length)
          if (response.data.series[0].data.length === 0) {
            this.hasData = false
          } else {
            this.hasData = true
            this.$set(this.dataObj, 'series', response.data.series)
            this.$set(this.dataObj, 'categories', response.data.xchart)
          }
        })
        .catch(() => {})
    },
    changeLimit () {
      this.getData()
    },
    handleClear () {
      this.getData()
    },
    changeDept (value) {
      this.getData(value)
    },
    changeTime(data) {
      this.selectTime = data
      this.startDate = data[0]
      this.endDate = data[1]
      this.getData(this.groupId)
    }
  }
}
</script>

