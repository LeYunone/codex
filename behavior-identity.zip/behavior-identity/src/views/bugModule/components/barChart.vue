<template>
  <div>
    <Modal v-model="dialogVisible"
           width="45"
           class-name="vertical-center-modal"
           class="page-modal"
           footer-hide
           :mask-closable="true"
           :title="title"
           :closable="true"
           @on-close="cancelClose"
    >
      <div class="container">
        <Row class="row-box" type="flex" justify="end" :gutter="20">
          <i-col v-show="hasType==1" :span="6">
            <Input v-model="size" placeholder="请输入限制项目数量" size="large" @on-blur="changeMaxNum"></Input>
          </i-col>
          <i-col v-show="(hasVersionQuery==1&&hasType==3)||showInput" :span="6">
            <Input v-model="versionPrefix" placeholder="请输入版本号前缀" size="large" @on-blur="changeVersion"></Input>
          </i-col>
          <i-col v-show="(hasVersionQuery==1&&hasType==3)||showInput" :span="6">
            <Input v-model="versionSuffix" placeholder="请输入版本号后缀" size="large" @on-blur="changeVersion"></Input>
          </i-col>
          <i-col v-show="hasSelect" :span="6" class="text-left">
            <Select v-model="query.selectType" size="large" placeholder="请选择显示类型" filterable @on-change="changeType">
              <Option v-for="item in typeList" :key="item.value" :value="item.value">{{ item.label }}</Option>
            </Select>
          </i-col>
        </Row>
        <!-- 柱状图 -->
        <!-- <div v-show="hasData&&(query.selectType==1||hasType==5)" id="barChart" ref="lineChart" class="line-box" :class="query.statisticsType==11?'hasOverflow':''" /> -->
        <div v-show="hasData&&(query.selectType==1||hasType==5)" id="barChart" ref="lineChart" class="line-box" />
        <!-- 饼图 -->
        <div v-show="hasPieData&&query.selectType==2" id="projectPieChart" ref="lineChart" class="line-box" />
        <div v-show="hasLineData&&(query.selectType==3||hasType==3)" id="projectLineChart" ref="lineChart" class="line-box" />
        <!-- 折线图 -->
        <div v-show="!hasData&&!hasPieData&&!hasLineData" class="main-none">
          <noListData :no-data-txt="noDataTxt"></noListData>
        </div>
      </div>
    </Modal>
  </div>
</template>

<script>
export default {
  name: 'barChart',
  props: {
  },
  data () {
    return {
      dialogVisible: false,
      title: '事业部BUG分析',
      noDataTxt: !this.hasLineData ? '暂无数据，请先选择项目或者日期' : '暂无数据',
      // noDataTxt: '暂无数据',
      hasData: false,
      hasPieData: false,
      hasLineData: false,
      options: {},
      pieOptions: {},
      lineOptions: {},
      size: 5,
      dataObj: {
        data: [],
        categories: [],
        height: 450
      },
      lineDataObj: {
        data: [],
        categories: []
      },
      pieDateObj: {
        data: []
      },
      chart: null,
      query: {
        selectType: 1
      },
      hasSelect: true,
      hasType: 1, // 1:柱状图+饼图选择；2:饼图+折线图选择；3:折线图，不可选择；4:饼图，不可选择,5:柱状图，不可选择
      typeList: [{
        label: '柱状图',
        value: 1
      }, {
        label: '饼图',
        value: 2
        }],
      hasVersionQuery: 0,
      versionPrefix: '',
      versionSuffix: '',
      showInput: false
    }
  },
  computed: {
  },
  watch: {
    dialogVisible(newVal) {
      if (newVal) {
        console.log('hasVersionQuery', this.hasVersionQuery)
        this.size = 5
        if (this.query.selectType == 1 || this.hasType == 5) {
          this.getChartData()
        } else if (this.query.selectType == 2) {
          this.getPieChartData()
        } else if (this.query.selectType == 3 || this.hasType == 3) {
          this.getLineChartData()
        }
      } else {
        this.cancelClose()
      }
    },
    hasType: {
      immediate: true,
      handler: function (val) {
        if (val == 1) {
          this.typeList = [{ label: '柱状图', value: 1 }, { label: '饼图', value: 2 }]
        } else if (val == 2) {
          this.typeList = [{ label: '饼图', value: 2 }, { label: '折线图', value: 3 }]
        }
      }
    },
    dataObj: {
      deep: true,
      immediate: true,
      handler: function (val) {
        this.$nextTick(() => {
          this.initOptions(val.categories, val.data, val.height)
          this.updateChart(this.options)
        })
      }
    },
    pieDateObj: {
      deep: true,
      immediate: true,
      handler: function (val) {
        this.$nextTick(() => {
          this.initPieOptions(val.data)
          this.updatePieChart(this.pieOptions)
        })
      }
    },
    lineDataObj: {
      deep: true,
      immediate: true,
      handler: function (val) {
        this.$nextTick(() => {
          this.initLineOptions(val.categories, val.data)
          this.updateLineChart(this.lineOptions)
        })
      }
    }
  },
  methods: {
    initOptions (categories = [], data = [], height = 450) {
      this.options = {
        chart: {
          type: 'bar',
          height: height
        },
        title: {
          text: ''
        },
        xAxis: {
          categories: categories
        },
        yAxis: {
          min: 0,
          title: {
            text: ''
          }
        },
        legend: {
          reversed: true
        },
        plotOptions: {
          bar: {
            dataLabels: {
              enabled: true,
              allowOverlap: true // 允许数据标签重叠
            }
          }
        },
        series: [{
          name: '',
          data: data
        }],
        colors: ['#90e0ef']
      }
    },
    initPieOptions (data = []) {
      this.pieOptions = {
        chart: {
          plotBackgroundColor: null,
          plotBorderWidth: null,
          plotShadow: false,
          type: 'pie'
        },
        title: {
          text: ''
        },
        tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
          pie: {
						allowPointSelect: true,
						cursor: 'pointer',
						dataLabels: {
								enabled: true,
								format: '<b>{point.name}</b>: {point.percentage:.1f} %',
					      style: {
										color: (this.$hCharts.theme && this.$hCharts.theme.contrastTextColor) || 'black'
								}
						}
          }
        },
        series: [{
          name: '',
          colorByPoint: true,
          data: data
        }]
      }
    },
    initLineOptions (categories = [], data = []) {
      this.lineOptions = {
        chart: {
          type: 'line'
        },
        title: {
          text: ''
        },
        subtitle: {
          text: ''
        },
        xAxis: {
          categories: categories
        },
        yAxis: {
          title: {
            text: 'BUG数量'
          }
        },
        plotOptions: {
          line: {
            dataLabels: {
              // 开启数据标签
              enabled: true
            }
          }
        },
        series: data
      }
    },
    updateChart(options) {
      this.$el = document.getElementById('barChart')
      this.chart = new this.$hCharts.Chart(this.$el, options)
    },
    updatePieChart(options) {
      this.$el = document.getElementById('projectPieChart')
      this.chart = new this.$hCharts.Chart(this.$el, options)
    },
    updateLineChart(options) {
      this.$el = document.getElementById('projectLineChart')
      this.chart = new this.$hCharts.Chart(this.$el, options)
    },
    cancelClose () {
      this.hasData = false
      this.hasPieData = false
      this.hasLineData = false
      this.dialogVisible = false
      this.hasSelect = true
      this.query.selectType = 1
      this.hasType = 1
      this.size = 5
      this.hasVersionQuery = 0
      this.versionPrefix = ''
      this.versionSuffix = ''
      this.showInput = false
      this.$set(this.dataObj, 'height', 450)
    },
    changeMaxNum () {
      if (this.size < 1) {
        this.size = 5
        this.$Message.error('请输入大于0的数字')
      }
      if (this.query.selectType == 1) {
        this.getChartData()
      } else if (this.query.selectType == 2) {
        this.getPieChartData()
      }
    },
    changeVersion () {
      this.query.versionPrefix = this.versionPrefix
      this.query.versionSuffix = this.versionSuffix
      this.getLineChartData()
    },
    // 柱状图
    // getChartData () {
    //   this.hasData = false
    //   const params = {
    //     size: this.size,
    //     type: 1
    //   }
    //   this.query = Object.assign({}, this.query, params)
    //   this.$store
    //     .dispatch('bugDetails/bugTop', this.query)
    //     .then(response => {
    //       const { data, xchart } = response.data
    //       if (data.length === 0) {
    //         this.hasData = false
    //       } else {
    //         this.hasData = true
    //         this.$set(this.dataObj, 'categories', xchart)
    //         this.$set(this.dataObj, 'data', data)
    //       }
    //     })
    //     .catch(() => {})
    // },
    getChartData () {
      this.hasData = false
      console.log('statisticsType', this.query.statisticsType)
      if (this.query.statisticsType == 0) {
        this.getTopChartData()
      } else if (this.query.statisticsType == 11) {
        this.getFunctionChartData()
      }
    },
    // top5柱状图
    getTopChartData () {
      this.hasData = false
      const params = {
        size: this.size,
        type: 1
      }
      this.query = Object.assign({}, this.query, params)
      this.$store
        .dispatch('bugDetails/bugTop', this.query)
        .then(response => {
          const { data, xchart } = response.data
          if (data.length === 0) {
            this.hasData = false
          } else {
            this.hasData = true
            if (data.length < 20) {
              this.$set(this.dataObj, 'height', 450)
            } else {
              this.$set(this.dataObj, 'height', data.length * 20)
            }
            this.$set(this.dataObj, 'categories', xchart)
            this.$set(this.dataObj, 'data', data)
          }
        })
        .catch(() => {})
    },
    // 功能模块柱状图
    getFunctionChartData () {
      this.hasData = false
      this.$store
        .dispatch('bugDetails/bugHistogram', this.query)
        .then(response => {
          const { data, xchart } = response.data
          if (data.length === 0) {
            this.hasData = false
          } else {
            this.hasData = true
            if (data.length < 20) {
              this.$set(this.dataObj, 'height', 450)
            } else {
              this.$set(this.dataObj, 'height', data.length * 20)
            }
            this.$set(this.dataObj, 'categories', xchart)
            this.$set(this.dataObj, 'data', data)
          }
        })
        .catch(() => {})
    },
    // 饼图
    getPieChartData () {
      this.hasPieData = false
      const params = {}
      if (this.hasType == 1) {
        params.size = this.size
      }
      this.query = Object.assign({}, this.query, params)
      this.$store
        .dispatch('bugDetails/bugAnalysis', this.query)
        .then(response => {
          const { series } = response.data
          if (series.length === 0) {
            this.hasPieData = false
          } else {
            this.hasPieData = true
            this.$set(this.pieDateObj, 'data', series)
          }
        })
        .catch(() => {})
    },
    // 折线图
    getLineChartData () {
      this.hasLineData = false
      this.$store
        .dispatch('bugDetails/bugVersionAnalysis', this.query)
        .then(response => {
          const { charts } = response.data
          if (charts.length > 1 || charts.length == 0) {
            this.hasLineData = false
          } else {
            this.hasLineData = true
            const totalData = []
            let seriesData = {}
            for (let i = 0; i < charts[0].series.length; i++) {
              seriesData[i] = charts[0].series[i].data
            }
            // console.log('seriesData', charts[0].series, seriesData)
            for (let i = 0; i < seriesData[0].length; i++) {
              // 将每个版本的数据相加
              let total = 0
              for (let j = 0; j < charts[0].series.length; j++) {
                total += seriesData[j][i]
              }
              totalData.push(total)
            }
            charts[0].series.push({
              name: 'total',
              data: totalData
            })
            // console.log('totalData', totalData)
            this.$set(this.lineDataObj, 'data', charts[0].series)
            this.$set(this.lineDataObj, 'categories', charts[0].xchart)
          }
        })
        .catch(() => {})
    },
    changeType (e) {
      if (e == 1) {
        this.hasPieData = false
        this.hasLineData = false
        this.getChartData()
      } else if (e == 2) {
        this.hasData = false
        this.hasLineData = false
        this.getPieChartData()
      } else if (e == 3) {
        this.hasData = false
        this.hasPieData = false
        // 显示前缀和后缀过滤输入框
        if (this.query.type == 2) {
          this.showInput = true
        }
        this.getLineChartData()
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 30px 0 15px;
  button {
    width: 60px;
    height: 30px;
    margin: 0 20px;
  }
}
.form{
  width: 100%;
  margin-bottom: 15px;
}
.ivu-form-item{
  display: flex;
  align-items: center;
}
::v-deep .ivu-form-item-content{
  flex: 1;
  margin-left: 0!important;
}
::v-deep .ivu-form-item-label{
  width: 80px!important;
}
.row-box{
  width: 100%;
  margin-bottom: 20px;
}
#barChart,#projectPieChart,#projectLineChart{
  width: 100%;
  height: 450px;
  background: #fff;
  border-radius: 0 0 15px 15px;
  margin-top: 20px;
  overflow-y: scroll!important;
}
.hasOverflow{
  overflow-y: scroll!important;
}
.noListData{
  height: 400px;
  display: flex;
  align-items: center;
  justify-content: center;
}

::v-deep .ivu-table-overflowY{
   overflow-x: scroll!important;
}
::v-deep #barChart::-webkit-scrollbar {
  width: 4px;
  height: 10px;
}
::v-deep #barChart::-webkit-scrollbar-track {
  background: rgb(239, 239, 239);
  border-radius: 2px;
}
// 小滑块
::v-deep #barChart::-webkit-scrollbar-thumb {
  background: #40a0ff49;
  border-radius: 6px;
}
::v-deep #barChart::-webkit-scrollbar-thumb:hover {
  background: #95c2f0;
}
</style>
