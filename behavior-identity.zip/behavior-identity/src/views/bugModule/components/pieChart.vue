<template>
  <div>
    <Modal key="pieChart"
           v-model="dialogVisible"
           width="45%"
           class-name="vertical-center-modal"
           class="page-modal"
           footer-hide
           :mask-closable="true"
           :title="title"
           :closable="true"
    >
      <div class="container">
        <div v-show="hasData" id="pieChart" ref="lineChart" class="line-box" />
        <div v-show="!hasData" class="main-none">
          <noListData :no-data-txt="noDataTxt"></noListData>
        </div>
      </div>

    </Modal>
  </div>
</template>

<script>
export default {
  name: 'pieChart',
  props: {

  },
  data () {
    return {
      dialogVisible: false,
      title: '事业部BUG分析',
      noDataTxt: '暂无数据',
      hasData: true,
      options: {},
      dataObj: {
        data: []
      },
      query: {}
    }
  },
  watch: {
    dialogVisible(newVal) {
      if (newVal) {
        this.getPieData()
      } else {
        this.cancelClose()
      }
    },
    dataObj: {
      deep: true,
      immediate: true,
      handler: function (val) {
      this.$nextTick(() => {
        this.initOptions(val.data)
        this.updateChart(this.options)
      })
      }
    }
  },
  mounted() {
    this.initOptions()
    this.updateChart(this.options)
  },
  methods: {
    initOptions(data = []) {
      this.options = {
        chart: {
          plotBackgroundColor: null,
          plotBorderWidth: null,
          plotShadow: false,
          type: 'pie'
        },
        title: {
          text: ''
        },
        tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
          pie: {
						allowPointSelect: true,
						cursor: 'pointer',
						dataLabels: {
								enabled: true,
								format: '<b>{point.name}</b>: {point.percentage:.1f} %',
					      style: {
										color: (this.$hCharts.theme && this.$hCharts.theme.contrastTextColor) || 'black'
								}
						}
          }
        },
        series: [{
          name: '',
          colorByPoint: true,
          data: data
        }]
      }
    },
    updateChart(options) {
      this.$el = document.getElementById('pieChart')
      this.chart = new this.$hCharts.Chart(this.$el, options)
    },
    cancelClose() {
      this.dialogVisible = false
    },
    getPieData () {
      this.hasData = false
      this.$store
        .dispatch('bugDetails/bugAnalysis', this.query)
        .then(response => {
          console.log(response.data)
          const { series } = response.data
          console.log('series', series)
          if (series.length === 0) {
            console.log('无数据')
            this.hasData = false
          } else {
            this.hasData = true
            this.$set(this.dataObj, 'data', series)
          }
        })
        .catch(() => {})
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 30px 0 15px;
  button {
    width: 60px;
    height: 30px;
    margin: 0 20px;
  }
}
.form{
  width: 100%;
  margin-bottom: 15px;
}
.ivu-form-item{
  display: flex;
  align-items: center;
}
::v-deep .ivu-form-item-content{
  flex: 1;
  margin-left: 0!important;
}
::v-deep .ivu-form-item-label{
  width: 80px!important;
}
.noListData{
    height: 400px;
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>
