<style lang="scss" scoped>
// ::v-deep .ivu-table{
//   overflow:visible;
// }
// ::v-deep .ivu-table-header {
//     overflow: hidden;
//     position: sticky;
//     top: 72px;
//     z-index: 4;
// }
.page-header{
  display: flex;
  h3{
    margin-left: 10px;
  }
  .icon{
    cursor: pointer;
  }
}
::v-deep.ivu-date-picker{
  width: 100%!important;
}
::v-deep th .ivu-table-cell{
  white-space: nowrap;
}

::v-deep .ivu-table-overflowX{
   overflow-x: scroll!important;
}
::v-deep .ivu-table-overflowX::-webkit-scrollbar {
  width: 4px;
  height: 10px;
}
::v-deep .ivu-table-overflowX::-webkit-scrollbar-track {
  background: rgb(239, 239, 239);
  border-radius: 2px;
}
// 小滑块
::v-deep .ivu-table-overflowX::-webkit-scrollbar-thumb {
  background: #40a0ff49;
  border-radius: 6px;
}
::v-deep .ivu-table-overflowX::-webkit-scrollbar-thumb:hover {
  background: #95c2f0;
}

.show-box{
  height: 100px;
  background: #fff;
  margin-bottom: 20px;
  border-radius: 10px;
  .text-center-box{
    display: flex;
    align-items: center;
    height: 115px;
  }
  .text-center{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 60px;
    border-right: 1px solid #e6e6e6;
    width: 100%;
    .t{
      display: flex;
      align-items: center;
      img{
        width: 20px;
        height: 20px;
      }
      .title{
        font-size: 16px;
        color: #666;
        margin-left: 10px;
      }
    }
    .number{
      font-size: 32px;
      color: #333;
      margin-left: 20px;
    }
    .bug-count{
      color: rgb(213,88,88);
    }
    .close-count{
      color: rgb(241,182,25);
    }
    .reopen-count{
      color: rgb(51,157,255);
    }
    .noBug-count{
      color: rgb(88,213,132);
    }
  }

}
.ivu-row .text-center-box:last-child .text-center{
  border-right: none;
}
</style>
<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>BUG明细</h3>
    </div>
    <div class="main-body">
      <div class="main-title margin-bottom-20">
        <Row :gutter="20">
          <i-col :span="4" class="text-left">
            <Input v-model="query.bugId" placeholder="请输入BUG ID" size="large" clearable />
          </i-col>
          <i-col :span="4" class="text-left">
            <Input v-model="query.bugTitle" placeholder="请输入BUG标题" size="large" clearable />
          </i-col>
          <i-col :span="4" class="text-left">
            <Select v-model="query.bugProjectName" size="large" placeholder="请选择项目" filterable clearable>
              <Option v-for="item in projectName" :key="item.value" :value="item.value">{{ item.label }}</Option>
            </Select>
          </i-col>
          <i-col :span="4" class="text-left">
            <Select v-model="query.department" size="large" placeholder="请选择事业部" filterable clearable>
              <Option v-for="item in department" :key="item.value" :value="item.value">{{ item.label }}</Option>
            </Select>
          </i-col>
          <i-col :span="4" class="text-left">
            <Select v-model="query.groupId" size="large" placeholder="请选择部门" filterable clearable>
              <Option v-for="item in deptList" :key="item.groupId+item.groupName" :value="item.groupId">{{ item.groupName }}</Option>
            </Select>
          </i-col>
          <i-col :span="4" class="text-left">
            <Select v-model="query.realUserName" size="large" placeholder="请选择人员" filterable clearable>
              <Option v-for="item in personList" :key="item.realUserId+item.realUserName" :value="item.realUserName">{{ item.realUserName }}</Option>
            </Select>
          </i-col>
          <i-col :span="4" class="text-left margin-top-20">
            <Select v-model="query.status" size="large" placeholder="请选择BUG状态" filterable clearable>
              <Option v-for="item in statusList" :key="item.value" :value="item.value">{{ item.name }}</Option>
            </Select>
          </i-col>
          <i-col :span="4" class="text-left margin-top-20">
            <Select v-model="query.bugReopen" size="large" placeholder="请选择Reopen类型" filterable clearable>
              <Option v-for="item in bugReopenStatus" :key="item.value" :value="item.value">{{ item.name }}</Option>
            </Select>
          </i-col>
          <i-col :span="4" class="text-left margin-top-20">
            <Select v-model="query.bugType2" size="large" placeholder="请选择BUG类型" filterable clearable>
              <Option v-for="item in bugTypeList" :key="item.value" :value="item.value">{{ item.name }}</Option>
            </Select>
          </i-col>
          <i-col :span="4">
            <div class="date-box margin-top-20">
              <DatePicker type="daterange" :options="options2" placement="bottom-end" placeholder="请选择日期" style="width: 200px" size="large" :value="selectTimeValue" @on-change="changeTime"></DatePicker>
            </div>
          </i-col>
          <i-col :span="1" class="margin-top-20">
            <Button v-debounce size="large" type="primary" @click="searchList">
              <span class="fa fa-search"></span>
            </Button>
          </i-col>
        </Row>
      </div>
      <div class="show-box">
        <Row :gutter="20" type="flex" align="middle">
          <i-col :span="6" class="text-center-box">
            <div class="text-center">
              <div class="t">
                <img src="../../assets/image/bugNumbers.png" alt="">
                <div class="title ">Bug总数</div>
              </div>
              <div class="b number bug-count">{{ showInfo.bugCount }}</div>
            </div>
          </i-col>
          <i-col :span="6" class="text-center-box">
            <div class="text-center">
              <div class="t">
                <img src="../../assets/image/fixBugs.png" alt="">
                <div class="title">关闭Bug数</div>
              </div>
              <div class="b number close-count">{{ showInfo.closeCount }}</div>
            </div>
          </i-col>
          <i-col :span="6" class="text-center-box">
            <div class="text-center">
              <div class="t">
                <img src="../../assets/image/reopenBugs.png" alt="">
                <div class="title">Reopen数</div>
              </div>
              <div class="b number reopen-count">{{ showInfo.reopenCount }}</div>
            </div>
          </i-col>
          <i-col :span="6" class="text-center-box">
            <div class="text-center">
              <div class="t">
                <img src="../../assets/image/noBugs.png" alt="">
                <div class="title">非Bug数</div>
              </div>
              <div class="b number noBug-count">{{ showInfo.noBugCount }}</div>
            </div>
          </i-col>
        </Row>
      </div>
      <div v-if="hasList">
        <div class="page-table margin-bottom-20">
          <Table :loading="tableLoading" :columns="tableColumns" tooltip-theme="light" stripe :data="dataList" fixed-header @on-row-click="handleHeader">
          </Table>
        </div>
        <div class="page-footer text-center">
          <Page
            :total="itemTotal"
            :current="pageIndex"
            :page-size="pageSize"
            show-elevator
            show-total
            show-sizer
            @on-page-size-change="getPageSize"
            @on-change="getPageList"
          />
        </div>
      </div>
      <div v-else class="main-none">
        <noListData></noListData>
      </div>
    </div>
    <div class="content_win">
      <pieChart ref="pieChart" />
      <barChart ref="barChart" />
    </div>
  </div>
</template>

<script>
import myMixins from '@/utils/myMixins'
import { formatDateTime } from '@/utils/commFunction'
import { mapState } from 'vuex'
import pieChart from './components/pieChart.vue'
import barChart from './components/barChart.vue'
export default {
  name: 'message',
  components: {
    pieChart,
    barChart
  },
  mixins: [myMixins],
  data() {
    return {
      selectActive: 1,
      hasList: false,
      pageSize: 10,
      pageIndex: 1,
      itemTotal: 0,
      validForm: {
      },
      query: {
        realUserName: '',
        status: '',
        startDate: '',
        endDate: '',
        bugReopen: '',
        groupId: '',
        bugType2: ''
      },
      dataList: [],
      personList: [],
      selectTime: [],
      tableLoading: false,
      selectTimeValue: [],
      department: [],
      projectName: [],
      deptList: [],
      showInfo: {
        reopenCount: 0,
        noBugCount: 0,
        closeCount: 0,
        bugCount: 0
      },
      tableColumns: [
      {
        key: 'projectName',
        title: '项目名称',
        align: 'center',
        width: 200,
          renderHeader: (h, params) => {
          return this.renderHeader(h, params, '项目名称', 'ios-pie-outline')
        }
      },
      {
        key: 'department',
        title: '事业部',
        align: 'center',
        width: 100,
        renderHeader: (h, params) => {
          return this.renderHeader(h, params, '事业部', 'ios-pulse')
        }
      },
      {
        key: 'bugTitle',
        title: '标题',
        align: 'center',
        width: 200
      },
      {
        key: 'bugId',
        title: 'ID',
        width: 100,
        align: 'center'
      },
      {
        key: 'level',
        title: '严重等级',
        align: 'center',
        width: 100,
        renderHeader: (h, params) => {
          return this.renderHeader(h, params, '严重等级', 'ios-ionic-outline')
        }
      },
      {
        key: 'status',
        title: '状态',
        align: 'center',
        width: 100,
        renderHeader: (h, params) => {
          return this.renderHeader(h, params, '状态', 'ios-paper-outline')
        }
      },
      {
        key: 'creator',
        title: '创建人',
        width: 80,
        align: 'center'
      },

      {
        key: 'resolveName',
        title: '负责人',
        align: 'center',
        width: 80,
        renderHeader: (h, params) => {
          return this.renderHeader(h, params, '负责人', 'ios-person-outline')
        }
      },

      {
        key: 'bugType2',
        title: '类型',
        align: 'center',
        width: 100,
        renderHeader: (h, params) => {
          return this.renderHeader(h, params, '类型', 'ios-analytics')
        }
      },
      {
        key: 'belongTo',
        title: '责任归属',
        width: 100,
        align: 'center',
        renderHeader: (h, params) => {
          return this.renderHeader(h, params, '责任归属', 'ios-pie')
        }
      },
      {
        key: 'bugVersion',
        title: '影响版本',
        width: 150,
        align: 'center',
        renderHeader: (h, params) => {
          return this.renderHeader(h, params, '影响版本', 'ios-pricetags-outline')
        }
      },
      {
        key: 'module',
        title: '功能模块',
        width: 100,
        align: 'center',
        renderHeader: (h, params) => {
          return this.renderHeader(h, params, '功能模块', 'ios-color-filter-outline')
        }
      },
      {
        key: 'probability',
        title: '发生概率',
        width: 100,
        align: 'center'
      },
      {
        key: 'fixVersion',
        title: '修复版本',
        width: 100,
        align: 'center'
      },

      {
        key: 'bugReopen',
        title: 'BugReopen',
        width: 100,
        align: 'center'
      },
      {
        key: 'bugReopenMonth',
        title: 'BugReopenMonth',
        align: 'center',
        width: 150
      },
      {
        key: 'createTime',
        title: '创建时间',
        width: 180,
        align: 'center'
      },
      {
        key: 'endTime',
        title: '关闭时间',
        width: 180,
        align: 'center'
      }
    ]
    }
  },
  computed: {
    ...mapState('bugDetails', ['statusList', 'bugReopenStatus', 'bugTypeList'])
  },
  watch: {
  },
  created () {
    const end = new Date()
    const start = new Date()
    start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
    this.query.startDate = formatDateTime(start, 'yyyy-MM-dd')
    this.query.endDate = formatDateTime(end, 'yyyy-MM-dd')
    this.selectTimeValue[0] = this.query.startDate
    this.selectTimeValue[1] = this.query.endDate
  },
  mounted () {
    if (this.$route.params.projectId !== undefined) {
      this.$set(this.validForm, 'projectId', this.$route.params.projectId)
    }
    if (this.$route.query.groupId !== undefined) {
      this.$set(this.query, 'groupId', this.$route.query.groupId)
    }
    if (this.$route.query.bugProjectName !== undefined) {
      this.$set(this.query, 'bugProjectName', this.$route.query.bugProjectName)
     }
    if (this.$route.query.type !== undefined && this.$route.query.type === 1) {
      this.$set(this.query, 'bugReopen', 1)
     }
    if (this.$route.query.realUserName !== undefined) {
      this.$set(this.query, 'realUserName', this.$route.query.realUserName)
    }
    if (this.$route.query.startDate !== undefined) {
      this.$set(this.query, 'startDate', this.$route.query.startDate)
      this.$set(this.selectTimeValue, 0, this.query.startDate)
    }
    if (this.$route.query.endDate !== undefined) {
      this.$set(this.query, 'endDate', this.$route.query.endDate)
      this.$set(this.selectTimeValue, 1, this.query.endDate)
    }
    this.getPersonList()
    this.getBugSystemName()
    this.getDeptList()
    this.getList()
  },
  methods: {
    // 分页
    getPageList(index) {
      this.pageIndex = index
      this.getList()
    },
    getPageSize(size) {
      this.pageIndex = 1
      this.pageSize = size
      this.getList()
    },
    searchList() {
      this.pageIndex = 1
      this.getList()
    },
    updatePerson() {
      this.$refs.editPerson.dialogVisible = true
    },
    getList() {
      this.tableLoading = true
      let Info = {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize
      }
      Info = Object.assign(this.query, Info)
      this.$store
        .dispatch('bugDetails/detailList', Info)
        .then(response => {
          this.tableLoading = false
          const res = response.data
          const { reopenCount, noBugCount, closeCount, bugCount } = res
          this.showInfo = {
            reopenCount,
            noBugCount,
            closeCount,
            bugCount
          }
          if (res.records && res.records.length === 0) {
            this.hasList = false
          } else {
            this.hasList = true
            this.dataList = res.bugDetails.records

            this.itemTotal = res.bugDetails.total
          }
        })
        .catch(() => {
          this.tableLoading = false
        })
    },
    getPersonList() {
      let params = {
        type: 0
      }
      this.$store
        .dispatch('commit/getPersonList', params)
        .then(response => {
          this.personList = response.data
        })
        .catch(() => {})
    },
    changeTime(data) {
      console.log(data)
      this.selectTime = data
      this.query.startDate = data[0]
      this.query.endDate = data[1]
    },
    getBugSystemName () {
      this.$store
        .dispatch('bugDetails/getBugSystemName')
        .then(response => {
          const { data } = response
          data.department.forEach(item => {
             this.department.push({
               value: item,
               label: item
             })
          })
          data.projectName.forEach(item => {
             this.projectName.push({
               value: item,
               label: item
             })
          })
        })
        .catch(() => {
        })
    },
    getDeptList() {
      this.$store
        .dispatch('deptManager/getDeptList')
        .then(response => {
          this.deptList = response.data
        })
        .catch(() => {})
    },
    handleHeader (row) {
    },
    handleChart(params) {
      const { column, index } = params
      console.log(index)
      let query = JSON.parse(JSON.stringify(this.query))
      // 分类
      let barArr = [0, 9, 11, 10]
      let pieArr = [1, 4, 5, 7, 8]
      if (barArr.includes(index)) {
        this.$refs.barChart.dialogVisible = true
        this.$refs.barChart.query.selectType = 1
        this.$refs.barChart.query = query
        this.$refs.barChart.title = column.title + '分析'
      }
      if (pieArr.includes(index)) {
        this.$refs.pieChart.dialogVisible = true
        this.$refs.pieChart.title = column.title + '分析'
        this.$refs.pieChart.query = query
      }
      query.statisticsType = index
      if (index == 0) {
        this.$refs.barChart.hasType = 1 // 首次渲染柱状图
        this.$refs.barChart.query.selectType = 1
      }
      if (index == 9) {
        this.$refs.barChart.query.selectType = 2
        this.$refs.barChart.hasType = 2 // 首次渲染饼图
        this.$refs.barChart.query.type = 2 // 责任归属
        this.$refs.barChart.hasVersionQuery = 1 // 影响版本
      }
      if (index == 10) {
        this.$refs.barChart.hasType = 3 // 首次渲染折线图
        this.$refs.barChart.hasSelect = false
        this.$refs.barChart.query.type = 1 // 影响版本
        this.$refs.barChart.hasVersionQuery = 1 // 影响版本
      }
      if (index == 11) {
        this.$refs.barChart.hasType = 5 // 只有柱状图
        this.$refs.barChart.hasSelect = false // 且不可选择
      }
    },
    renderHeader (h, params, title, icon) {
      return h('div', [
        h('span', {
          style: {
            color: '#339dff',
            'margin-right': '5px',
            cursor: 'pointer'
          }
        }, title),
        h('Icon', {
          props: {
            type: icon,
            size: '18',
            color: '#339dff'
          },
          style: {
            cursor: 'pointer'
          },
          on: {
            'click': (event) => {
              this.handleChart(params)
            }
          }
        })
      ])
    }
  }
}
</script>
