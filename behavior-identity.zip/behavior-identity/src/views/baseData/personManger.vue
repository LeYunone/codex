<style lang="scss" scoped>
::v-deep .ivu-tag{
  word-break: keep-all;
  overflow: inherit;
}
.actionLink{
  flex-wrap: wrap;
}
</style>
<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>人员管理</h3>
    </div>
    <div class="main-body">
      <div class="main-title margin-bottom-20">
        <Row :gutter="20" justify="space-between">
          <i-col :span="16" class="text-left">
            <Row :gutter="20">
              <i-col :span="6">
                <Input v-model="queryForm.realUserName" placeholder="请输入姓名" size="large" clearable></Input>
              </i-col>
              <i-col :span="6">
                <Select v-model="queryForm.groupId" size="large" placeholder="请选择部门" filterable clearable>
                  <Option v-for="item in deptList" :key="item.groupId+item.groupName" :value="item.groupId">
                    {{ item.groupName }}
                  </Option>
                </Select>
              </i-col>
              <i-col :span="3">
                <Button v-debounce size="large" type="primary" @click="searchComm">
                  <span class="fa fa-search"></span>
                </Button>
              </i-col>
            </Row>
          </i-col>
          <i-col :span="2" class="text-left add-btn">
            <Button v-debounce size="large" type="primary" class="add-btn" @click="updatePerson(0)">
              新增
            </Button>
          </i-col>
        </Row>
      </div>
      <div v-if="hasList">
        <div class="page-table margin-bottom-20">
          <Table :columns="columns" stripe :data="dataList">
            <template slot="gitLabUser" slot-scope="{ row }">
              <div v-for="(item,index1) in row.gitLabUser" :key="item.userId">
                <span>{{ item.userName }}{{ index1+1===row.gitLabUser.length?'': '、' }}</span><br>
              </div>
            </template>
            <template slot="groupList" slot-scope="{ row }">
              <div class="actionLink">
                <Tag v-for="(item,index) in row.groupList" :key="index" color="cyan">
                  {{ item.groupName }}
                </Tag>
              </div>
            </template>
            <template slot="action" slot-scope="{ row }">
              <div>
                <Button
                  class="delete-btn"
                  type="dashed"
                  icon="ios-trash-outline"
                  @click="deletePerson(row.realUserId)"
                >删除</Button>
                <Button
                  class="action-btn"
                  type="dashed"
                  icon="ios-create"
                  @click="updatePerson(1,row)"
                >修改</Button>
              </div>
            </template>
          </Table>
        </div>
        <div class="page-footer text-center">
          <Page
            :total="itemTotal"
            :page-size-opts="[10, 20, 40]"
            :current="pageIndex"
            :page-size="pageSize"
            show-elevator
            show-total
            show-sizer
            @on-page-size-change="getPageSize"
            @on-change="getPageList"
          />
        </div>
      </div>
      <div v-else class="main-none">
        <noListData></noListData>
      </div>
    </div>
    <div class="content_win">
      <confirmModal ref="confirmModal" @entrueClose="cancelClose">
        <div slot="info">
          <p class="p-text">确定删除该人员？</p>
        </div>
      </confirmModal>
      <editRealPerson ref="editPerson" @getList="getList"></editRealPerson>
    </div>
  </div>
</template>

<script>
import editRealPerson from './components/editRealPerson.vue'
import { mapState } from 'vuex';
export default {
  name: 'message',
  components: {
    editRealPerson
  },
  data() {
    return {
      selectActive: 1,
      hasList: false,
      pageSize: 10,
      pageIndex: 1,
      itemTotal: 0,
      validForm: {},
      query: {},
      dataList: [],
      deleteId: '',
      deptList: [],
      queryForm: {
        groupId: '',
        realUserName: ''
      }
    }
  },
  computed: {
    ...mapState('personManager', [
      'columns'
    ]),
  },
  watch: {},
  created() {},
  mounted() {
     this.getDeptList()
     this.getList()
  },
  methods: {
    getDeptList() {
      this.$store
        .dispatch('deptManager/getDeptList')
        .then(response => {
          this.deptList = response.data
        })
        .catch(() => {})
    },
    // 分页
    getPageList(index) {
      this.pageIndex = index
      this.getList()
    },
    getPageSize(size) {
      this.pageIndex = 1
      this.pageSize = size
      this.getList()
    },
    searchComm() {
      this.validForm = {}
      for (let i in this.query) {
        if (this.query[i]) {
          this.validForm[i] = this.query[i]
        }
      }
      this.pageIndex = 1
      this.getList()
    },
    updatePerson(index, row) {
      if (index === 0) {
        this.$refs.editPerson.dialogVisible = true
        this.$refs.editPerson.title = '新增'
        this.$refs.editPerson.row = {}
        return
      } else {
          this.$refs.editPerson.dialogVisible = true
          this.$refs.editPerson.title = '修改'
          let groupArr = []
          let gitLabArr = []
          row.groupList ? row.groupList.map(item => {
            groupArr.push(item.groupId)
          }) : []
          row.gitLabUser ? row.gitLabUser.map(item => {
            gitLabArr.push(item.userId)
          }) : []
          let obj = {
            realUserName: row.realUserName,
            realEmail: row.realEmail,
            realUserId: row.realUserId,
            groups: groupArr,
            userIds: gitLabArr
          }
          this.$refs.editPerson.row = Object.assign({}, obj)
      }
    },
    cancelClose() {
      this.$store
        .dispatch('personManager/deletePerson', { realUserId: this.deleteId })
        .then(response => {
          this.$Message.success('删除成功')
          this.getList()
        })
        .catch(() => {})
    },
    deletePerson(id) {
      this.$refs.confirmModal.dialogVisible = true
      this.$refs.confirmModal.isClose = true
      this.deleteId = id
    },
    getList() {
      let Info = {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize
      }
      // 拼接对象 使用Object.assign
      Info = Object.assign(Info, this.queryForm)
      this.$store
        .dispatch('personManager/getRealPersonList', Info)
        .then(response => {
          const res = response.data
          if (res.records && res.records.length === 0) {
            this.hasList = false
          } else {
            this.hasList = true
            this.dataList = res.records
            this.itemTotal = res.total
          }
        })
        .catch(() => {})
    }

  }
}
</script>
