<style lang="scss" scoped>
::v-deep .ivu-btn-dashed {
  color: #2db7f5;
  border-color: #2db7f5;
}

</style>
<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>部门管理</h3>
    </div>

    <div class="main-body">
      <div class="main-title margin-bottom-20">
        <Row justify="end">
          <i-col :span="2" class="text-left">
            <Button v-debounce size="large" type="primary" class="add-btn" @click="update(0)">
              新增
            </Button>
          </i-col>
        </Row>
      </div>
      <div v-if="hasList">
        <div class="page-table margin-bottom-20">
          <Table :columns="columns1" stripe :data="dataList">
            <template slot="action" slot-scope="{ row }">
              <div class="actionLink">
                <Button
                  class="action-btn"
                  type="dashed"
                  icon="ios-create"
                  @click="update(1,row)"
                >修改</Button>
              </div>
            </template>
          </Table>
        </div>
      </div>
      <div v-else class="main-none">
        <noListData></noListData>
      </div>
    </div>
    <div class="content_win">
      <addDept ref="addDept" @getList="getList"></addDept>
    </div>
  </div>
</template>

<script>
import addDept from './components/addDept.vue'
export default {
  name: 'message',
  components: {
    addDept
  },
  data() {
    return {
      selectActive: 1,
      columns1: [
        {
          title: '部门ID',
          align: 'center',
          key: 'groupId'
        },
        {
          title: '部门名称',
          align: 'center',
          key: 'groupName'
        },
        {
          title: this.$t('common.action'),
          slot: 'action',
          align: 'center',
          width: 200
        }
      ],
      hasList: false,
      query: {},
      dataList: [],
      isEdit: 1// 0新增，1编辑
    }
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {
    this.getList()
  },
  methods: {
    getList() {
      this.$store
        .dispatch('deptManager/getDeptList')
        .then(response => {
          if (response.data && response.data.length === 0) {
            this.hasList = false
          } else {
            this.hasList = true
            this.dataList = response.data
          }
        })
        .catch(() => {})
    },
    update(isEdit, row) {
      this.isEdit = isEdit
      this.$refs.addDept.dialogVisible = true
      this.$refs.addDept.isEdit = isEdit
      if (isEdit === 1) {
        this.$refs.addDept.row = row
      }
    }
  }
}
</script>
