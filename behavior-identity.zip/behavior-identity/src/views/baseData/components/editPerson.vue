<style lang="scss" scoped>
// .page .vertical-center-modal{
//   overflow: none!important;
// }
.modalContainer {
  width: 95%;
}
</style>
<template>
  <div class="editRoleModal page">
    <Modal
      v-model="dialogVisible"
      class="page-modal"
      width="35%"
      title="修改"
      :scrollable="false"
      :footer-hide="true"
      class-name="vertical-center-modal"
      :styles="{ top: '-30px' }"
    >
      <!--编辑 loading -->
      <Spin fix v-if="loadingShow">
        <Icon type="ios-loading" size="18" class="demo-spin-icon-load"></Icon>
        <div>Loading</div>
      </Spin>
      <div class="modalContainer margin-bottom-100">
        <Form
          ref="addForm"
          :label-width="130"
          :model="addForm"
          label-colon
          :rules="ruleValidate"
          class="form-box"
        >
          <!-- 姓名  -->
          <FormItem label="git账号">
            <Input
              v-model="addForm.userName"
              size="large"
              :maxlength="10"
              placeholder="请输入git账号"
              clearable
              disabled
            ></Input>
          </FormItem>
          <!-- 邮箱  -->
          <FormItem label="邮箱">
            <Input
              v-model="addForm.userEmail"
              size="large"
              placeholder="请输入邮箱"
              clearable
              disabled
            ></Input>
          </FormItem>
          <!-- 姓名  -->
          <FormItem label="真实姓名">
            <Input
              v-model="addForm.userRealName"
              size="large"
              :maxlength="10"
              placeholder="请输入真实姓名"
              clearable
            ></Input>
          </FormItem>
          <!-- 卡类型 -->
          <FormItem label="部门">
            <Select v-model="addForm.groups" filterable multiple>
              <Option v-for="item in deptTypes" :value="item.groupId" :key="item.groupId">{{ item.groupName }}</Option>
            </Select>
          </FormItem>
        </Form>
      </div>
      <div class="detailBackBtn margin-bottom-40">
        <Button size="large" @click="closeModal()">{{
          $t("common.cancel")
        }}</Button>
        <Button type="primary" size="large" @click="handleSubmit()">{{
          $t("common.ensure")
        }}</Button>
      </div>
    </Modal>
  </div>
</template>
<script>
export default {
  name: "addModal",
  data() {
    const validateNumber = (rule, value, callback) => {
      const reg=/^\+?[1-9]\d*$/
      if(!reg.test(value)){
        callback(new Error(this.$t("addOtherTip.tip8")));
      }
      if(value <0 || value> 4294967294 ){
         callback(new Error(this.$t("addOtherTip.tip8")));
      }
      callback();
    };
    const validateRemark = (rule, value, callback) => {
      const reg= /^[^\#\$\￥\%\^\&\*\……\~\`\|\【\】\》\《\'\!\！\{\}\‘\“\”\’\/\、\?\？\——\=\+\@]*$/
      if(!reg.test(value)){
        callback(new Error(this.$t("addOtherTip.tip7")));
      }
      callback();
    };
    return {
      loadingShow: false,
      cardtype: 0,
      dialogVisible: false, // 模块
      resultType: true, // 提交确认
      addForm: { userName: "", userRealName: "", dept: '' ,userEmail:'',},
      ruleValidate: {
        cardnumber: [
          {
            required: true,
            message: this.$t("card.tip1"),
            trigger: "blur"
          },
          { validator: validateNumber, trigger: "blur" }
        ],
        cardtype: [
          {
            required: true,
            message: this.$t("card.tip2"),
            trigger: "blur"
          }
        ],
        remarks:[
          { validator: validateRemark, trigger: "blur" }
        ]
      },
      randomModal: false,
      loginTime: "",
      deptTypes: [],
      isEdit: false, //修改还是新增
      row: {},
      disabled: false,
      timer: null,
      ipAddress: '',
    };
  },
  computed: {},
  watch: {
    // 监听与计算
    dialogVisible(val) {
      if (!val) {
        // 关闭
        this.handleReset();
        this.$emit("getList");
        clearInterval(this.timer);
      } else {
        this.addForm = this.row
        this.getDeptList()
      }
    },
    isEdit(val) {
      if (val) {
        this.disabled = true;
      } else {
        this.disabled = false;
      }
    },
  },
  mounted() {},
  methods: {
    // 重置 (清空)，恢复初始化
    handleReset() {
      this.$refs.addForm.resetFields();
      this.loginTime = "";
      this.addForm = this.$options.data.call(this).addForm;
    },
    // 返回
    closeModal() {
      this.dialogVisible = false;
      this.handleReset();
      clearInterval(this.timer);

    },
    // 按确定校验表单
    handleSubmit() {
      console.log('点击确定按钮',this.addForm)
      let _this = this;
      this.$refs.addForm.validate(valid => {
        if (valid) {
          _this.updatePerson()
        }
      })
    },
    getDeptList() {
      this.$store
        .dispatch("deptManager/getDeptList")
        .then(response => {
          console.log(response)
          this.deptTypes = response.data
        })
        .catch(() => {});
    },
    updatePerson() {
      this.$store
        .dispatch("personManager/editPerson", this.addForm)
        .then(response => {
          console.log(response)
          this.$message({
            type: 'success',
            message: '修改成功'
          })
          this.$emit('getList')
          this.dialogVisible = false
          // this.deptTypes = response.data
        })
        .catch(() => {});
    }
  },
  beforeDestroy() {
    clearInterval(this.timer);
  }
};
</script>
