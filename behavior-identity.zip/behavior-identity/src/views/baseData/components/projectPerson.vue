<style lang="scss" scoped>
// ::v-deep .ivu-form-item-label {
//   width: 180px !important;
// }
.modalContainer {
  width: 100%;
  display: flex;
  justify-content: center;
  padding-right: 0;
}
.main{
  width: 100%;
  display: flex;
  // justify-content: space-between;
  flex-wrap: wrap;
}
::v-deep .ivu-tag{
  // width: 22%;
  margin-bottom: 10px;
}
</style>
<template>
  <div class="editRoleModal page">
    <Modal
      v-model="dialogVisible"
      class="page-modal"
      width="20%"
      title="项目成员"
      :scrollable="false"
      :footer-hide="true"
      class-name="vertical-center-modal"
      :styles="{ top: '-30px' }"
    >
      <div class="modalContainer margin-bottom-100">
        <div class="main">
          <div v-for="(item,index) in row" :key="index" size="large">
            <Tag color="blue">
              {{ item.realUserName?item.realUserName:item.userName }}
            </Tag>
          </div>
        </div>
      </div>
    </Modal>
  </div>
</template>
<script>
export default {
  name: "addModal",
  data() {
    return {
      dialogVisible: false, // 模块
      row: [],
    };
  },
  computed: {},
  watch: {
    // 监听与计算
    dialogVisible(val) {
      if (!val) {
        // 关闭
        this.$emit("getList");
      } else {
        console.log(this.row)
      }
    },
    isEdit(val) {
      if (val) {
        this.disabled = true;
      } else {
        this.disabled = false;
      }
    },
  },
  mounted() {},
  methods: {
    closeModal() {
      this.dialogVisible = false
    }
  },
};
</script>
