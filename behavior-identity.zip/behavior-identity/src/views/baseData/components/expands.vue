<style scoped>
    .expand-row{
        margin-bottom: 16px;
    }
    .project-name{
      font-weight: 600;
    }
    .expand-key{
      cursor: pointer;
      margin: 0 15px;
    }
</style>
<template>
  <div>
    <Row class="expand-row">
      <p class="project-name">项目名称:</p>
      <div v-for="(item,index) in row.projectList" :key="index">
        <p class="expand-key" @click="goToDEtail(item)">{{ item.projectName }}</p>
      </div>

    </Row>
  </div>
</template>
<script>
export default {
  props: {
    row: Object
  },
  data(){
    return {

    }
  },
  mounted() {
    console.log(this.row.projectList)
  },
  computed: {
  },
  methods: {
    goToDEtail(item) {
      console.log('item--------', item.projectId)
      this.$router.push({
        name: 'history',
        params: {
          projectId: item.projectId
        }
      })
    }
  }
};
</script>