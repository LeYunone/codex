<style lang="scss" scoped>
// ::v-deep .ivu-form-item-label {
//   width: 180px !important;
// }
.modalContainer {
  width: 95%;
}
</style>
<template>
  <div class="editRoleModal page">
    <Modal
      v-model="dialogVisible"
      class="page-modal"
      width="35%"
      title="修改"
      :scrollable="false"
      :footer-hide="true"
      class-name="vertical-center-modal"
      :styles="{ top: '-30px' }"
    >
      <!--编辑 loading -->
      <Spin fix v-if="loadingShow">
        <Icon type="ios-loading" size="18" class="demo-spin-icon-load"></Icon>
        <div>Loading</div>
      </Spin>
      <div class="modalContainer margin-bottom-100">
        <Form
          ref="addForm"
          :label-width="130"
          :model="addForm"
          label-colon
          class="form-box"
        >
          <!-- 部门ID  -->
          <FormItem label="部门ID" v-show="isEdit===1">
            <Input
              v-model="addForm.groupId"
              size="large"
              :maxlength="10"
              placeholder="请输入姓名"
              clearable
              disabled
              type="number"
            ></Input>
          </FormItem>
          <!-- 部门名称  -->
          <FormItem label="部门名称">
            <Input
              v-model="addForm.groupName"
              size="large"
              :maxlength="10"
              placeholder="请输入姓名"
              clearable
            ></Input>
          </FormItem>

        </Form>
      </div>
      <div class="detailBackBtn margin-bottom-40">
        <Button size="large" @click="closeModal()">{{
          $t("common.cancel")
        }}</Button>
        <Button type="primary" size="large" @click="handleSubmit()">{{
          $t("common.ensure")
        }}</Button>
      </div>
    </Modal>
  </div>
</template>
<script>
export default {
  name: "addModal",
  data() {
    return {
      loadingShow: false,
      dialogVisible: false, // 模块
      addForm: { groupName: "", groupId: ""},
      loginTime: "",
      isEdit: 0, // 修改还是新增
      row:{}
    };
  },
  computed: {},
  watch: {
    // 监听与计算
    dialogVisible(val) {
      if (!val) {
        // 关闭
        this.handleReset();
        this.$emit("getList");
      } else {
        if (this.isEdit === 1) {
          this.addForm = this.row
        }
      }
    },
    isEdit(val) {
      if (val) {
        this.disabled = true;
      } else {
        this.disabled = false;
      }
    },
  },
  mounted() {},
  methods: {
    // 重置 (清空)，恢复初始化
    handleReset() {
      this.$refs.addForm.resetFields();
      this.addForm = this.$options.data.call(this).addForm;
    },
    // 返回
    closeModal() {
      this.dialogVisible = false;
      this.handleReset();
    },
    // 按确定校验表单
    handleSubmit() {
      console.log('点击确定按钮',this.addForm)
      let _this = this;
      this.$refs.addForm.validate(valid => {
        if (valid) {
          if (this.isEdit) {
            _this.updateCard();
          } else {
            _this.addCard();
          }
        }
      })
    },
    updateCard() {
      this.$store
        .dispatch("deptManager/updateDept", this.addForm)
        .then(response => {
          this.$message({
            type: 'success',
            message: ' 修改成功'
          })
          this.dialogVisible = false
          this.$emit('getList');
          console.log(response)
        })
        .catch(() => {});
    },
    addCard() {
      this.$store
        .dispatch("deptManager/updateDept", this.addForm)
        .then(response => {
          this.$message({
            type: 'success',
            message: '新增成功'
          })
          this.dialogVisible = false
          this.$emit('getList');
          console.log(response)
        })
        .catch(() => {});
    }
  },
};
</script>
