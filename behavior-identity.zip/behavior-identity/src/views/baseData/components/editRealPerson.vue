<style lang="scss" scoped>
// .page .vertical-center-modal{
//   overflow: none!important;
// }
.modalContainer {
  width: 95%;
}
</style>
<template>
  <div class="editRoleModal page">
    <Modal
      v-model="dialogVisible"
      class="page-modal"
      width="35%"
      :title="title"
      :scrollable="false"
      :footer-hide="true"
      class-name="vertical-center-modal"
      :styles="{ top: '-30px' }"
    >
      <!--编辑 loading -->
      <Spin v-if="loadingShow" fix>
        <Icon type="ios-loading" size="18" class="demo-spin-icon-load"></Icon>
        <div>Loading</div>
      </Spin>
      <div class="modalContainer margin-bottom-100">
        <Form
          ref="addForm"
          :label-width="130"
          :model="addForm"
          label-colon
          :rules="ruleValidate"
          class="form-box"
        >
          <!-- 姓名  -->
          <FormItem label="姓名" prop="realUserName">
            <Input
              v-model="addForm.realUserName"
              size="large"
              :maxlength="10"
              placeholder="请输入姓名"
              clearable
            ></Input>
          </FormItem>
          <!-- 邮箱  -->
          <FormItem label="邮箱">
            <Input
              v-model="addForm.realEmail"
              size="large"
              placeholder="请输入邮箱"
              clearable
            ></Input>
          </FormItem>
          <!-- gitlab账号 -->
          <FormItem label="gitlab账号">
            <Select v-model="addForm.userIds" filterable multiple>
              <Option v-for="item in userLists" :key="item.userId" :value="item.userId">{{ item.userName }}</Option>
            </Select>
          </FormItem>
          <!-- 部门 -->
          <FormItem label="部门">
            <Select v-model="addForm.groups" filterable multiple>
              <Option v-for="item in deptTypes" :key="item.groupId" :value="item.groupId">{{ item.groupName }}</Option>
            </Select>
          </FormItem>
        </Form>
      </div>
      <div class="detailBackBtn margin-bottom-40">
        <Button size="large" @click="closeModal()">{{
          $t("common.cancel")
        }}</Button>
        <Button type="primary" size="large" @click="handleSubmit()">{{
          $t("common.ensure")
        }}</Button>
      </div>
    </Modal>
  </div>
</template>
<script>
export default {
  name: 'addModal',
  data() {
    return {
      loadingShow: false,
      cardtype: 0,
      dialogVisible: false, // 模块
      resultType: true, // 提交确认
      addForm: { realUserName: '', userRealName: '', dept: '', userEmail: '' },
      ruleValidate: {
        realUserName: [
          {
            required: true,
            message: '请输入姓名',
            trigger: 'blur'
          }
        ]
      },
      randomModal: false,
      loginTime: '',
      deptTypes: [],
      userLists: [],
      isEdit: false, // 修改还是新增
      row: {},
      disabled: false,
      timer: null,
      ipAddress: '',
      title: '新增'
    }
  },
  computed: {},
  watch: {
    // 监听与计算
    dialogVisible(val) {
      if (!val) {
        // 关闭
        this.handleReset()
        this.$emit('getList')
        clearInterval(this.timer)
      } else {
        this.addForm = this.row
        this.getDeptList()
        this.getUsersList()
      }
    },
    isEdit(val) {
      if (val) {
        this.disabled = true
      } else {
        this.disabled = false
      }
    }
  },
  mounted() {},
  beforeDestroy() {
    clearInterval(this.timer)
  },
  methods: {
    // 重置 (清空)，恢复初始化
    handleReset() {
      this.$refs.addForm.resetFields()
      this.loginTime = ''
      this.addForm = this.$options.data.call(this).addForm
    },
    // 返回
    closeModal() {
      this.dialogVisible = false
      this.handleReset()
      clearInterval(this.timer)
    },
    // 按确定校验表单
    handleSubmit() {
      console.log('点击确定按钮', this.addForm)
      let _this = this
      this.$refs.addForm.validate(valid => {
        if (valid) {
          _this.updatePerson()
        }
      })
    },
    getDeptList() {
      this.$store
        .dispatch('deptManager/getDeptList')
        .then(response => {
          console.log(response)
          this.deptTypes = response.data
        })
        .catch(() => {})
    },
    getUsersList() {
      this.$store
        .dispatch('personManager/getRealUserList')
        .then(response => {
          console.log(response)
          this.userLists = response.data
        })
        .catch(() => {})
    },
    updatePerson() {
      this.$store
        .dispatch('personManager/updatePerson', this.addForm)
        .then(response => {
          console.log(response)
          if (Number(response.code) === 404) {
            this.$message({
              type: 'error',
              message: response.message + '，请重新输入'
            })
            return
          }
          this.$message({
            type: 'success',
            message: '操作成功'
          })
          this.$emit('getList')
          this.dialogVisible = false
        })
        .catch(() => {})
    }
  }
}
</script>
