<style lang="scss" scoped>
::v-deep .ivu-tag{
  word-break: keep-all;
  overflow: inherit;
}
::v-deep .ivu-btn-dashed {
    color: #2db7f5;
    border-color: #2db7f5;
}
</style>
<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>人员管理</h3>
    </div>
    <div class="main-body">
      <div v-if="hasList">
        <div class="page-table margin-bottom-20">
          <Table :columns="columns1" stripe :data="dataList">
          </Table>
        </div>
        <div class="page-footer text-center">
          <Page
            :total="itemTotal"
            :page-size-opts="[10, 20, 40]"
            :current="pageIndex"
            :page-size="pageSize"
            show-elevator
            show-total
            show-sizer
            @on-page-size-change="getPageSize"
            @on-change="getPageList"
          />
        </div>
      </div>
      <div class="main-none" v-else>
        <noListData></noListData>
      </div>
    </div>
    <div class="content_win">
      <editPerson ref="editPerson" @getList="getList"></editPerson>
    </div>
  </div>
</template>

<script>
import editPerson from "./components/editPerson.vue";
export default {
  name: "message",
  components: {
    editPerson
  },
  data() {
    return {
      selectActive: 1,
      columns1: [
        {
          title: '姓名',
          align: "center",
          key: "realUserName"
        },
        {
          title: '邮箱',
          align: "center",
          key: "userEmail"
        },
        {
          title: 'git账号',
          align: "center",
          key: "userName"
        }
      ],
      hasList: false,
      pageSize: 10,
      pageIndex: 1,
      itemTotal: 0,
      validForm: {},
      query: {},
      dataList: [],
    };
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {
     this.getList();
  },
  methods: {
    // 分页
    getPageList(index) {
      this.pageIndex = index;
      this.getList();
    },
    getPageSize(size) {
      this.pageIndex = 1;
      this.pageSize = size;
      this.getList();
    },
    searchComm() {
      this.validForm = {};
      for (let i in this.query) {
        if (this.query[i]) {
          this.validForm[i] = this.query[i];
        }
      }
      this.pageIndex = 1;
      this.getCaList();
    },
    updatePerson(row) {
      this.$refs.editPerson.dialogVisible = true
      let groupArr = []
      row.groupList.map(item => {
        groupArr.push(item.groupId)
      })
      let obj = {
        userName: row.userName,
        userRealName: row.userRealName,
        userEmail: row.userEmail,
        groups: groupArr,
        userId: row.userId
      }
      this.$refs.editPerson.row = obj
    },

    getList() {
      let Info = {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
      };
      this.$store
        .dispatch("personManager/getPersonList", Info)
        .then(response => {
          const res = response.data;
          if (res.records && res.records.length === 0) {
            this.hasList = false
          } else {
            this.hasList = true
            this.dataList = res.records
            this.itemTotal = res.total
          }

          console.log(response)
        })
        .catch(() => {});
    },

  }
};
</script>
