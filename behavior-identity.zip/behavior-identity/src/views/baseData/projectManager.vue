<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>项目列表</h3>
    </div>
    <div class="main-body">
      <div class="main-title margin-bottom-20">
        <Row :gutter="20" type="flex" justify="space-between">
          <i-col :span="16" class="text-left">
            <Row :gutter="20">
              <i-col :span="8" class="text-left">
                <Select v-model="query.realProjectName" size="large" placeholder="请选择项目" filterable clearable>
                  <Option v-for="item in projectName" :key="item.value" :value="item.value">{{ item.label }}</Option>
                </Select>
              </i-col>
              <!-- <i-col :span="6">
                <div class="date-box">
                  <DatePicker type="date" placeholder="请选择起始时间" :options="options2" size="large" @on-change="changeTime"></DatePicker>
                </div>
              </i-col> -->
              <i-col :span="3">
                <Button v-debounce size="large" type="primary" @click="searchList">
                  <span class="fa fa-search"></span>
                </Button>
              </i-col>
            </Row>
          </i-col>
          <i-col :span="2" class="text-left add-btn">
            <Button v-debounce size="large" type="primary" class="add-btn" @click="addGitProject(0)">
              新增
            </Button>
          </i-col>
        </Row>
      </div>
      <div v-if="hasList">
        <div class="page-table margin-bottom-20">
          <Table :columns="columns" :data="dataList" stripe :loading="tableLoading">
            <template slot="projectNames" slot-scope="row">
              <span>{{ getProjectName(row) }}</span>
            </template>
            <template slot="realUserNames" slot-scope="row">
              <span v-if="!row.row.realUserNames" class="no-tip">暂无</span>
              <div v-else>
                <Tag v-for="(item,index) in row.row.realUserNames" :key="index" color="cyan">
                  {{ item }}
                </Tag>
              </div>
            </template>
            <template slot="actions" slot-scope="row">
              <Row type="flex" justify="center" gutter="20">
                <i-col :span="8">
                  <Button
                    class="action-btn"
                    type="dashed"
                    icon="ios-create"
                    @click="addGitProject(1,row)"
                  >修改</Button>
                </i-col>
                <i-col :span="8">
                  <Button
                    class="delete-btn"
                    type="dashed"
                    icon="ios-trash-outline"
                    @click="deleteProject(row.row.realProjectName)"
                  >删除</Button>
                </i-col>
              </Row>
            </template>
          </Table>
        </div>
        <div class="page-footer text-center">
          <Page
            :total="itemTotal"
            :page-size-opts="[10, 20, 40]"
            :current="pageIndex"
            :page-size="pageSize"
            show-elevator
            show-total
            show-sizer
            @on-page-size-change="getPageSize"
            @on-change="getPageList"
          />
        </div>
      </div>
      <div v-else class="main-none">
        <noListData></noListData>
      </div>
    </div>
    <div>
      <projectPerson ref="projectPerson" />
      <addGitProject ref="addGitProject" @getList="getList" />
      <confirmModal ref="confirmModal" @entrueClose="cancelClose">
        <div slot="info">
          <p class="p-text">确定删除该关联项目？</p>
        </div>
      </confirmModal>
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex'
import expandRow from './components/expands.vue'
import projectPerson from './components/projectPerson.vue'
import addGitProject from './components/addGitProject.vue'
import { Row } from 'view-design'
  export default {
    components: { expandRow, projectPerson, addGitProject },
    data () {
      return {
        dataList: [],
        hasList: false,
        pageSize: 10,
        pageIndex: 1,
        itemTotal: 0,
        options2: {
          disabledDate: date => {
            if (this.endMonth) {
              let endDate = this.getDate(this.endMonth)
              return (date && date > endDate) || date > new Date()
            } else {
              return date && date > new Date()
            }
          }
        },
      projectId: '',
      startDate: '',
      endDate: '',
      projectName: [],
      department: [],
      projectList: [],
      query: {
        realProjectName: ''
        },
      tableLoading: false,
      deleteRealProjectNames: ''
    }
  },
  computed: {
    ...mapState('projectManager', [
      'columns'
    ]),
    getProjectName () {
      return (row) => {
      //   if (!!row.row.projectIds) {
      //     let str = ''
      //     this.projectList.forEach(item => {
      //       if (row.row.projectIds.includes(item.projectId)) {
      //         str += item.projectName + ','
      //       }
      //     })
      //     return str.substring(0, str.length - 1)
      //   }
      //   return ''
        // }
        if (row.row.projectNames) {
          return row.row.projectNames.join(',')
        }
        return ''
      }
    }
  },
  mounted () {
    this.getProjectNameList()
    this.getList()
    this.getBugSystemName()
  },
  methods: {
    // 分页
    getPageList (index) {
      this.pageIndex = index
      this.getList()
    },
    getPageSize (size) {
      this.pageIndex = 1
      this.pageSize = size
      this.getList()
    },
    searchList () {
      this.pageIndex = 1
      this.getList()
    },
    getList () {
      this.tableLoading = true
      let Info = {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        realProjectName: this.query.realProjectName
      }
      this.$store
        .dispatch('projectManager/relationList', Info)
        .then(response => {
          const res = response.data
          if (res.records && res.records.length == 0) {
            this.hasList = false
          } else {
            this.hasList = true
            this.dataList = res.records
            this.itemTotal = res.total
          }
          this.tableLoading = false
        })
        .catch(() => {
          this.tableLoading = false
        })
    },
    detail (row) {
      this.$refs.projectPerson.dialogVisible = true
      this.$refs.projectPerson.row = row.row.users
    },
    changeTime (data) {
      this.startDate = data
    },
    addGitProject (type, row) {
      this.$refs.addGitProject.dialogVisible = true
      if (type === 1) {
        let obj = {
          realProjectName: row.row.realProjectName,
          projectIds: row.row.projectIds
        }
        this.$refs.addGitProject.title = '修改'
        this.$refs.addGitProject.row = obj
        this.$refs.addGitProject.isEdit = true
      } else {
        this.$refs.addGitProject.title = '新增'
        this.$refs.addGitProject.isEdit = false
        this.$refs.addGitProject.row = {}
      }
    },
    getBugSystemName () {
      this.$store
        .dispatch('bugDetails/getBugSystemName')
        .then(response => {
          const { data } = response
          data.projectName.forEach(item => {
            this.projectName.push({
              value: item,
              label: item
            })
          })
        })
    },
    getProjectNameList() {
      let params = {
        type: 1
      }
      this.$store
        .dispatch('commit/getProjectNameList', params)
        .then(response => {
          this.projectList = response.data
        })
        .catch(() => {})
    },
    deleteProject (realProjectName) {
      console.log('row', realProjectName)
      this.$refs.confirmModal.dialogVisible = true
      this.$refs.confirmModal.isClose = true
      this.deleteRealProjectNames = realProjectName
    },
    cancelClose () {
      let params = {
        realProjectNames: [this.deleteRealProjectNames],
        projectIds: [],
        type: 1
      }
      this.$store
        .dispatch('projectManager/relationRealProject', params)
        .then(response => {
          this.$Message.success('删除成功')
          this.getList()
        })
        .catch(() => {})
    }
  }
}
</script>
<style lang="scss" scoped>
  ::v-deep .ivu-date-picker{
    width: 100%;
  }
  .no-tip{
    color: #9999;
  }
  ::v-deep .ivu-table-cell{
    padding: 10px 0;
  }
</style>
