<style lang="scss" scoped></style>
<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>人员管理</h3>
    </div>

    <div class="main-body">
      <!-- <div class="main-title margin-bottom-20">
        <Row :gutter="20"
          ><i-col :span="4">
            <i-input
              v-model="query.communityId"
              size="large"
              clearable
              :maxlength="50"
              :placeholder="$t('project.commIdTip')"
            ></i-input>
          </i-col>
          <i-col :span="4">
            <i-input
              v-model="query.communityName"
              size="large"
              clearable
              :maxlength="20"
              :placeholder="$t('project.commNameTip')"
            ></i-input>
          </i-col>
          <i-col :span="3" class="text-left">
            <Button size="large" type="primary">
              <span class="fa fa-search"></span>
            </Button>
          </i-col>
        </Row>
      </div> -->
      <div v-if="hasList">
        <div class="page-table margin-bottom-20">
          <Table :columns="columns1" stripe :data="dataList">
            <template slot="action" slot-scope="{ row }">
              <div class="actionLink">
                <Button
                  class="action-btn"
                  type="primary"
                  @click="updatePerson"
                  >修改</Button
                >
                <!-- <Button
                  class="action-btn"
                  type="primary"
                  >部门配置</Button
                > -->
              </div>
            </template>
          </Table>
        </div>
        <div class="page-footer text-center">
          <Page
            :total="itemTotal"
            show-elevator
            show-total
            show-sizer
            @on-page-size-change="getPageSize"
          />
        </div>
      </div>
      <div class="main-none" v-else>
        <noListData></noListData>
      </div>
    </div>
    <div class="content_win">
      <editPerson ref="editPerson"></editPerson>
    </div>
  </div>
</template>

<script>
import editPerson from "./components/editPerson.vue";
export default {
  name: "message",
  components: {
    editPerson
  },
  data() {
    return {
      selectActive: 1,
      columns1: [
        {
          title: '用户名',
          align: "center",
          key: "userName"
        },
          {
          title: '标题',
          align: "center",
          key: "title"
        },
          {
          title: 'commitId',
          align: "center",
          key: "commitId"
        },

      {
          title: '项目ID',
          align: "center",
          key: "projectId"
        },
        {
          title: 'commitId',
          align: "center",
          key: "commitId"
        },
        {
          title: '删除量',
          align: "center",
          key: "deletions"
        },
        {
          title: '新增量',
          align: "center",
          key: "additions"
        },
        {
          title: '总量',
          align: "center",
          key: "total"
        },
        {
          title: '时间',
          align: "center",
          key: "userName"
        },
      ],
      hasList: true,
      pageSize: 10,
      pageIndex: 1,
      itemTotal: 0,
      validForm: {},
      query: {},
      dataList: [{
        userName: 'leyunone',
        userRealName: 'xx',
        groupNames: '后台',
        userEmail:'365627310@qq.com'
      }],
    };
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {
  },
  methods: {
    // 分页
    getPageList(index) {
      this.pageIndex = index;
      // this.getList();
    },
    getPageSize(size) {
      this.pageIndex = 1;
      this.pageSize = size;
      // this.getList();
    },
    searchComm() {
      this.validForm = {};
      for (let i in this.query) {
        if (this.query[i]) {
          this.validForm[i] = this.query[i];
        }
      }
      this.pageIndex = 1;
      this.getCaList();
    },
    updatePerson() {
      this.$refs.editPerson.dialogVisible = true
    }

    // getList() {
    //   let Info = {
    //     pageIndex: this.pageIndex,
    //     pageSize: this.pageSize,
    //     sortField: this.sortField,
    //     sortMode: this.sortMode
    //   };
    //   Info = Object.assign(this.validForm, Info);
    //   this.$store
    //     .dispatch("video/projectList", Info)
    //     .then(response => {
    //       const res = response.result;

    //       if (res.records.length !== 0) {
    //         this.dataList = res.records;
    //         this.itemTotal = res.total;
    //         this.hasList = true;
    //       } else {
    //         this.hasList = false;
    //       }
    //     })
    //     .catch(() => {});
    // },

  }
};
</script>
