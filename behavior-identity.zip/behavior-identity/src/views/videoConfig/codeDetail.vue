<style lang="scss" scoped>
.page-header{
  display: flex;
  h3{
    margin-left: 10px;
  }
  .icon{
    cursor: pointer;
  }
}
</style>
<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <Icon type="ios-arrow-back" @click="goBack" color="#0F75FF" size="18" class="icon"/>
      <h3>提交记录</h3>
    </div>
    <div class="main-body">
      <div v-if="hasList">
        <div class="page-table margin-bottom-20">
          <Table :columns="columns1" stripe :data="dataList">
          </Table>
        </div>
        <div class="page-footer text-center">
          <Page
            :total="itemTotal"
            show-elevator
            show-total
            show-sizer
            @on-page-size-change="getPageSize"
            @on-change="getPageList"
          />
        </div>
      </div>
      <div class="main-none" v-else>
        <noListData></noListData>
      </div>
    </div>
    <div class="content_win">
    </div>
  </div>
</template>

<script>
export default {
  name: "message",
  components: {
  },
  data() {
    return {
      selectActive: 1,
      columns1: [
        {
          title: '用户名',
          align: "center",
          key: "userName"
        },
          {
          title: '标题',
          align: "center",
          key: "title"
        },
      {
          title: '项目ID',
          align: "center",
          key: "projectId"
        },
        {
          title: 'commitId',
          align: "center",
          key: "commitId"
        },
        {
          title: '删除量',
          align: "center",
          key: "deletions"
        },
        {
          title: '新增量',
          align: "center",
          key: "additions"
        },
        {
          title: '总量',
          align: "center",
          key: "total"
        },
        {
          title: '时间',
          align: "center",
          key: "commitDate"
        },
        {
          title: 'message',
          align: 'center',
          key: 'message',
          render: (h, params) => {
            return h('Tooltip', {
              props: { placement: 'top-start' }
             }, [
              h('div', {
                style: {
                  width: '100px',
                  overflow: 'hidden',
                  whiteSpace: 'nowrap',
                  textOverflow: 'ellipsis'
                }
              }, params.row.message),
              h('span', {
                slot: 'content',
                style: {
                whiteSpace: 'normal',
                wordBreak: 'break-all'
              }
          }, params.row.message)
        ])
      }
        }
      ],
      hasList: true,
      pageSize: 10,
      pageIndex: 1,
      itemTotal: 0,
      validForm: {
        projectId:0,
      },
      query: {},
      dataList: [],
      // projectId:0,
    };
  },
  computed: {
  },
  watch: {},
  created() {},
  mounted() {
    // this.projectId = this.$route.params.item.projectId;
    console.log(this.$route.params)
    this.$set(this.validForm, 'projectId', this.$route.params.projectId)
    console.log(this.validForm)
    this.getList()
  },
  methods: {
    // 分页
    getPageList(index) {
      this.pageIndex = index;
      this.getList();
    },
    getPageSize(size) {
      this.pageIndex = 1;
      this.pageSize = size;
      this.getList();
    },
    updatePerson() {
      this.$refs.editPerson.dialogVisible = true
    },
    getList() {
      let Info = {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
      };
       Info = Object.assign(this.validForm, Info);
      this.$store
        .dispatch("commit/getList", Info)
        .then(response => {
          const res = response.data;
          this.dataList = res.records
          this.itemTotal = res.total
          console.log(response)
        })
        .catch(() => {});
    },
    // 提交信息详情
    messageDetail() {
      console.log('详细信息')
    },
    goBack() {
      this.$router.push('/video')
    }
  }
};
</script>
