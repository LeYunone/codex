<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>项目列表</h3>
    </div>
    <div class="main-body">
      <div class="main-title margin-bottom-20">
        <Row :gutter="20">
          <i-col :span="4" class="text-left">
            <Select v-model="projectId" size="large" placeholder="请选择项目名称" filterable clearable >
              <Option v-for="item in projectList" :value="item.projectId" :key="item.projectId+item.projectName">{{ item.projectName }}</Option>
            </Select>
          </i-col>
          <i-col :span="4">
            <div class="date-box">
              <DatePicker type="date" placeholder="请选择起始时间" :options="options2" size="large" @on-change="changeTime"></DatePicker>
            </div>
          </i-col>
          <i-col :span="3">
            <Button size="large" type="primary" @click="searchList" v-debounce>
              <span class="fa fa-search"></span>
            </Button>
          </i-col>
        </Row>
      </div>
      <div v-if="hasList">
        <div class="page-table margin-bottom-20">
          <Table :columns="columns10" :data="dataList" stripe>
            <template slot="realProjectNames" slot-scope="row">
              <span>{{ getProjectNames(row) }}</span>
            </template>
            <template slot="users" slot-scope="row">
              <span v-if="!row.row.users" class="no-tip">暂无</span>
              <div v-else>
                <Tag color="cyan" v-for="(item,index) in row.row.users" :key="index">
                   {{ item.realUserName?item.realUserName:item.userName }}
                </Tag>
              </div>
            </template>
            <template slot="actions" slot-scope="row">
              <Button
                class="action-btn"
                type="dashed"
                icon="ios-create"
                @click="addTakeProject(1,row)"
              >修改</Button>
            </template>
          </Table>
        </div>
        <div class="page-footer text-center">
          <Page
            :total="itemTotal"
            :page-size-opts="[10, 20, 40]"
            :current="pageIndex"
            :page-size="pageSize"
            show-elevator
            show-total
            show-sizer
            @on-page-size-change="getPageSize"
            @on-change="getPageList"
          />
        </div>
      </div>
      <div class="main-none" v-else>
        <noListData></noListData>
      </div>
    </div>
    <div>
      <projectPerson ref="projectPerson" />
      <addTakeProject ref="addTakeProject" @getList="getList" />
    </div>
  </div>
</template>
<script>
import projectPerson from './components/projectPerson.vue';
import { mapState } from 'vuex';
import addTakeProject from './components/addTakeProject.vue';

  export default {
    components: {projectPerson,addTakeProject },
    data () {
      return {
        columns10: [
          {
            title: '项目ID',
            key: 'projectId',
            align: 'center'
          },
          {
              title: '项目名称',
            key: 'projectName',
            align: 'center'
          },
          {
            title: '对应项目',
            key: 'realProjectNames',
            slot: 'realProjectNames',
            align: 'center'
          },
          {
            title: '创建时间',
            key: 'createStr',
            align: 'center',
            sortable: true
          },
          {
            title: '项目成员',
            slot: 'users',
            align: 'center'
          },
          {
            title: '操作',
            slot: 'actions',
            align: 'center'
          },
        ],
        dataList: [],
        hasList: false,
        pageSize: 10,
        pageIndex: 1,
        itemTotal: 0,
        options2: {
        disabledDate: date => {
          if (this.endMonth) {
            let endDate = this.getDate(this.endMonth)
              return (date && date > endDate) || date > new Date()
            } else {
              return date && date > new Date()
            }
        }
      },
      projectList: [],
      projectId: '',
      startDate: '',
      endDate: ''
      }
  },
    computed: {
      getProjectNames () {
        return (row) => {
          let str = ''
          if (!!row.row.realProjectNames) {
            row.row.realProjectNames.forEach((item, index) => {
              str += item + ','
            })
            return str.substring(0, str.length - 1)
          }
          return ''
        }
      }
    },
    mounted() {
      this.getList()
      this.getProjectNameList()
    },
    methods: {
      // 分页
      getPageList(index) {
        this.pageIndex = index;
        this.getList();
      },
      getPageSize(size) {
        this.pageIndex = 1;
        this.pageSize = pageSize;
        this.getList();
      },
      searchList () {
        this.index = 1
        this.getList()
      },
      getList() {
      let Info = {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        projectId: this.projectId,
        startDate: this.startDate
      };
      this.$store
        .dispatch("projectList/getList", Info)
        .then(response => {
          const res = response.data;
          if (res.records && res.records.length==0) {
            this.hasList = false
          } else {
            this.hasList = true
            this.dataList = res.records
            this.itemTotal = res.total
          }
        })
        .catch(() => {});
      },
      detail(row) {
        this.$refs.projectPerson.dialogVisible = true
        this.$refs.projectPerson.row = row.row.users
      },
      getProjectNameList() {
      let params = {
        userId: this.userId,
        storageId: this.storageId,
        type: 1
      }
      this.$store
        .dispatch("commit/getProjectNameList", params)
        .then(response => {
          this.projectList= response.data;
        })
        .catch(() => {});
      },
      changeTime(data) {
        this.startDate = data
      },
      addTakeProject (type, row) {
        console.log('row', row)
        this.$refs.addTakeProject.dialogVisible = true
        if (type === 1) {
          let obj = {
            realProjectNames: row.row.realProjectNames,
            projectId: row.row.projectId
          }
          this.$refs.addTakeProject.title = '修改'
          this.$refs.addTakeProject.row = obj
         this.$refs.addTakeProject.isEdit = true
        } else {
          this.$refs.addTakeProject.title = '新增'
          this.$refs.addTakeProject.isEdit = false
          this.$refs.addTakeProject.row = {}
        }
      }
    }
  }
</script>
<style lang="scss" scoped>
  ::v-deep .ivu-date-picker{
    width: 100%;
  }
  .no-tip{
    color: #9999;
  }
  ::v-deep .ivu-table-cell{
    padding: 10px 0;
  }
</style>
