<style lang="scss" scoped>
.modalContainer {
  width: 95%;
}
</style>
<template>
  <div class="editRoleModal page">
    <Modal
      v-model="dialogVisible"
      class="page-modal"
      width="40%"
      :title="title"
      :scrollable="false"
      :footer-hide="true"
      class-name="vertical-center-modal"
      :styles="{ top: '-30px' }"
    >
      <!--编辑 loading -->
      <Spin v-if="loadingShow" fix>
        <Icon type="ios-loading" size="18" class="demo-spin-icon-load"></Icon>
        <div>Loading</div>
      </Spin>
      <div class="modalContainer margin-bottom-100">
        <Form
          ref="addForm"
          :label-width="130"
          :model="addForm"
          label-colon
          :rules="ruleValidate"
          class="form-box"
        >
          <FormItem label="Git项目名">
            <Select v-model="addForm.projectId" size="large" placeholder="请选择项目名称" filterable clearable :disabled="isEdit">
              <Option v-for="item in projectList" :value="item.projectId" :key="item.projectId+item.projectName">{{ item.projectName }}</Option>
            </Select>
          </FormItem>
          <FormItem label="项目名" prop="realProjectNames">
            <Select v-model="addForm.realProjectNames" size="large" placeholder="请选择" filterable clearable  multiple>
              <Option v-for="item in projectName" :value="item.value">{{ item.label }}</Option>
            </Select>
          </FormItem>
        </Form>
      </div>
      <div class="detailBackBtn margin-bottom-40">
        <Button size="large" @click="closeModal()">{{
          $t("common.cancel")
        }}</Button>
        <Button type="primary" size="large" @click="handleSubmit()">{{
          $t("common.ensure")
        }}</Button>
      </div>
    </Modal>
  </div>
</template>
<script>
export default {
  name: 'addModal',
  data() {
    return {
      loadingShow: false,
      dialogVisible: false, // 模块
      addForm: { projectId: '', realProjectNames: [] },
      ruleValidate: {
        gitProject: [
          {
            required: true,
            message: '请输入Git项目名',
            trigger: 'blur'
          }
        ]
      },
      userLists: [],
      isEdit: false, // 修改还是新增
      row: {},
      disabled: false,
      title: '新增',
      projectName: [],
      projectList: [],
    }
  },
  watch: {
    // 监听与计算
    dialogVisible(val) {
      if (!val) {
        // 关闭
        this.handleReset()
        this.$emit('getList')
      } else {
        this.addForm = this.row
        console.log('this.addForm', this.addForm)
        this.getBugSystemName()
        this.getProjectNameList()
      }
    },
    isEdit(val) {
      if (val) {
        this.disabled = true
      } else {
        this.disabled = false
      }
    }
  },
  methods: {
    // 重置 (清空)，恢复初始化
    handleReset() {
      this.$refs.addForm.resetFields()
      this.addForm = this.$options.data.call(this).addForm
    },
    // 返回
    closeModal() {
      this.dialogVisible = false
      this.handleReset()
      clearInterval(this.timer)
    },
    // 按确定校验表单
    handleSubmit() {
      let _this = this
      this.$refs.addForm.validate(valid => {
        if (valid) {
          _this.updateProject()
        }
      })
    },
    updateProject () {
      let params = {
        realProjectNames: this.addForm.realProjectNames,
        projectIds: [this.addForm.projectId]
      }
      this.$store
        .dispatch('projectManager/relationRealProject', params)
        .then(response => {
          if (Number(response.code) === 404) {
            this.$message({
              type: 'error',
              message: response.message + '，请重新输入'
            })
            return
          }
          this.$message({
            type: 'success',
            message: '操作成功'
          })
          this.$emit('getList')
          this.dialogVisible = false
        })
        .catch(() => {})
    },
    getBugSystemName () {
      this.$store
        .dispatch('bugDetails/getBugSystemName')
        .then(response => {
          const { data } = response
          data.projectName.forEach(item => {
             this.projectName.push({
               value: item,
               label: item
             })
          })
        })
        .catch(() => {
        })
    },
    getProjectNameList() {
      let params = {
        type: 1
      }
      this.$store
        .dispatch("commit/getProjectNameList", params)
        .then(response => {
          this.projectList= response.data;
        })
        .catch(() => {});
      },
  }
}
</script>
