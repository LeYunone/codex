<style lang="scss" scoped>
.page-header{
  display: flex;
  h3{
    margin-left: 10px;
  }
  .icon{
    cursor: pointer;
  }
}
::v-deep.ivu-date-picker{
  width: 100%!important;
}
</style>
<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>部门代码质量</h3>
    </div>
    <div class="main-body">
      <div class="main-title margin-bottom-20">
        <Row :gutter="20">
          <i-col :span="4">
            <Input v-model="limit" placeholder="请输入提交数量阈值" size="large" type="number" clearable></Input>
          </i-col>
          <i-col :span="4" class="text-left">
            <Select v-model="query.groupId" size="large" placeholder="请选择部门" filterable clearable>
              <Option v-for="item in deptList" :value="item.groupId" :key="item.groupId+item.groupName">{{ item.groupName }}</Option>
            </Select>
          </i-col>
          <i-col :span="4" class="text-left">
            <Select v-model="query.status" size="large" placeholder="请选择BUG状态" filterable clearable>
              <Option v-for="item in statusList" :key="item.value" :value="item.value">{{ item.name }}</Option>
            </Select>
          </i-col>
          <i-col :span="5">
            <div class="date-box">
              <DatePicker type="daterange" :options="options2" placement="bottom-end" placeholder="请选择日期" style="width: 200px" size="large" @on-change="changeTime" :value="selectTimeValue"></DatePicker>
            </div>
          </i-col>
          <i-col :span="3">
            <Button v-debounce size="large" type="primary" @click="searchList">
              <span class="fa fa-search"></span>
            </Button>
          </i-col>
        </Row>
      </div>
      <div v-if="hasList">
        <div class="page-table margin-bottom-20 min-height-table">
          <Table :loading="tableLoading" :columns="newPersonColumns" stripe :data="dataList">
            <template slot="bugNumber" slot-scope="{ row }">
              <Tooltip :content="getTooltipContent(row)">
                <div class="link-text" @click="gotoBugDetail(row,0)">{{ row.bugNumber }}<i class="el-icon-info" color="#ccc" style="margin-left: 10px;" /></div>
              </Tooltip>
            </template>
            <template slot="reopenRate" slot-scope="{ row }">
              <span :class="isGreaterThan5Percent(row)?'hight-rate':''" class="link-text" @click="gotoBugDetail(row,1)"> {{ getReopenRate(row) }}</span>
            </template>
            <template slot="CMMINumber" slot-scope="{ row }">
              <span> {{ getCIMM(row) }}</span>
            </template>
            <template slot="level" slot-scope="{ row }">
              <span :class="getLevel(row)<4?'hight-rate':''"> {{ getLevel(row) }}{{ getLevel(row)!=='-'?'级':'' }}</span>
            </template>
            <template slot="deletions" slot-scope="{ row }">
              <div class="actionLink">
                <span class="delete-txt">{{ row.deletions||0 }}</span>
              </div>
            </template>
            <template slot="additions" slot-scope="{ row }">
              <div class="actionLink">
                <span class="add-txt">{{ row.additions||0 }}</span>
              </div>
            </template>
          </Table>
        </div>
        <div class="page-footer text-center">
          <Page
            :total="itemTotal"
            :current="pageIndex"
            :page-size="pageSize"
            show-elevator
            show-total
            show-sizer
            @on-page-size-change="getPageSize"
            @on-change="getPageList"
          />
        </div>
      </div>
      <div v-else class="main-none">
        <noListData></noListData>
      </div>
    </div>
    <div class="content_win">
    </div>
  </div>
</template>

<script>
import myMixins from '@/utils/myMixins'
import { getYearDays } from '@/utils/commFunction'
import { formatDateTime } from '@/utils/commFunction'
import { mapState } from 'vuex'
export default {
  name: 'message',
  components: {
  },
  mixins: [myMixins],
  data() {
    return {
      selectActive: 1,
      hasList: false,
      pageSize: 10,
      pageIndex: 1,
      itemTotal: 0,
      sortMode: 1, // 1 总数  2reopen率
      sortField: 1, // 1 升序 2 降序
      validForm: {
      },
      query: {
        groupId: '',
        status: '',
        startDate: '',
        endDate: ''
      },
      deptList: [],
      dataList: [],
      personList: [],
      selectTime: [],
      tableLoading: false,
      limit: '1000',
      selectTimeValue: []
    }
  },
  computed: {
    ...mapState('bugDetails', ['tableColumns', 'statusList']),
    ...mapState('codeQuality', ['columns', 'deptColumns', 'noSortColumns']),
    newPersonColumns () {
      // return this.deptColumns.concat(this.columns)
      return this.deptColumns.concat(this.noSortColumns).concat(this.columns)
    },
    getCIMM () {
      return (row) => {
        if (row.bugNumber == 0 || row.codeTotal == 0) return 0
        return (Number(row.bugNumber) / Number(row.codeTotal) * 1000).toFixed(2)
      }
    },
    getLevel () {
      return (row) => {
        let cimm = this.getCIMM(row)
        switch (true) {
          case cimm > 5.52:
            return 1
          case cimm > 2.39 && cimm <= 5.52:
            return 2
          case cimm > 0.92 && cimm <= 2.39:
            return 3
          case cimm > 0.32 && cimm <= 0.92 :
            return 4
          case cimm >= 0 && cimm <= 0.32:
            return 5
          default:
            return '-'
        }
      }
    },
    getReopenRate () {
      return (row) => {
        if (row.reopenNumber == 0 || row.bugNumber == 0) return 0
        let result = (Number(row.reopenNumber) / Number(row.bugNumber))
        return (result * 100).toFixed(2)
      }
    },
    isGreaterThan5Percent () {
      return (row) => {
        let percentage = this.getReopenRate(row)
        // 将百分比转换为小数
        let decimal = parseFloat(percentage) / 100
        return decimal > 0.05
      }
    }
  },
  watch: {
  },
  created () {
    const end = new Date()
    const start = new Date()
    start.setTime(start.getTime() - 3600 * 1000 * 24 * getYearDays());
    this.query.startDate = formatDateTime(start, 'yyyy-MM-dd')
    this.query.endDate = formatDateTime(end, 'yyyy-MM-dd')
    this.selectTimeValue[0] = this.query.startDate
    this.selectTimeValue[1] = this.query.endDate
  },
  mounted () {
    if (this.$route.params.projectId !== undefined) {
      this.$set(this.validForm, 'projectId', this.$route.params.projectId)
    }
    this.getList()
    this.getDeptList()
  },
  methods: {
    // 分页
    getPageList(index) {
      this.pageIndex = index
      this.getList()
    },
    getPageSize(size) {
      this.pageIndex = 1
      this.pageSize = size
      this.getList()
    },
    searchList() {
      this.pageIndex = 1
      this.getList()
    },
    updatePerson() {
      this.$refs.editPerson.dialogVisible = true
    },
    getList() {
      this.tableLoading = true
      let Info = {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        queryType: 1,
        limit: this.limit,
        sortMode: this.sortMode,
        sortField: this.sortField
      }
      Info = Object.assign(this.query, Info)
      this.$store
        .dispatch('codeQuality/statistics', Info)
        .then(response => {
          this.tableLoading = false
          const res = response.data
          if (res.records && res.records.length === 0) {
            this.hasList = false
          } else {
            this.hasList = true
            this.dataList = res.records

            this.itemTotal = res.total
          }
        })
        .catch(() => {
          this.tableLoading = false
        })
    },
    getDeptList() {
      this.$store
        .dispatch("deptManager/getDeptList")
        .then(response => {
          this.deptList = response.data
        })
        .catch(() => {})
    },
    changeTime(data) {
      console.log(data)
      this.selectTime = data
      this.query.startDate = data[0]
      this.query.endDate = data[1]
    },
    getTooltipContent (row) {
      return `
        未修复数(个)：${row.doingNumber}
        已修复数(个)：${row.fixNumber}
        Reopen数(个)：${row.reopenNumber}
      `
    },
    sortBugNumber (e) {
      let { column, order } = e
      this.sortMode = order === 'desc' ? 2 : 1
      this.sortField = column.slot === 'bugNumber' ? 1 : 2
      this.getList()
    },
    gotoBugDetail (row, type) {
      this.$router.push({
        path: '/bugModule/bugDetails',
        query: {
          groupId: row.groupId,
          startDate: this.query.startDate,
          endDate: this.query.endDate,
          type: type
        }
      })
    }
  }
}
</script>
