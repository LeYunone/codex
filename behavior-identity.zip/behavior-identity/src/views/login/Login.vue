<style scoped></style>
<template>
  <div class="login">
    <div class="login-header">
      <span class="primary-color login-title">软件平台BI系统</span>
      <Dropdown trigger="click" @on-click="changeLanguage" class="drop-style">
        <a href="javascript:void(0)">
          {{ languageName }}
          <Icon type="ios-arrow-down"></Icon>
        </a>
        <DropdownMenu slot="list">
          <DropdownItem
            v-for="(item, index) in LanguageList"
            :key="index"
            :name="index"
            >{{ item.name }}</DropdownItem
          >
        </DropdownMenu>
      </Dropdown>
    </div>
    <div class="login-body">
      <div class="login-main">
        <div class="login-form">
          <Row class="box-head">
            <i-col :span="24">
              <h1 class="text-center">{{ $t("login.title") }}</h1>
            </i-col>
          </Row>
          <Form ref="loginForm" :model="login" :rules="loginFormValidate" >
            <FormItem prop="account" class="item-class">
              <i-input
                v-model="login.account"
                :placeholder="$t('login.accountTip')"
                size="large"
              >
                <Icon slot="prefix" type="md-person" color="#0B66F8" />
              </i-input>
            </FormItem>
            <FormItem prop="password" class="item-class">
              <i-input
                v-model.trim="login.password"
                :type="passwordType ? 'password' : 'text'"
                :placeholder="$t('login.pwdTip')"
                size="large"
                :maxlength="20"
                @keyup.enter="loginSystem"
              >
                <Icon
                  slot="suffix"
                  type="ios-eye-outline"
                  color="#0B66F8"
                  @click="visible"
                />
                <Icon slot="prefix" type="md-lock" color="#0B66F8" />
              </i-input>
            </FormItem>
            <Row class="box-btn" type="flex" justify="space-between">
              <i-col :span="24" class="text-right">
                <Button
                  size="large"
                  style="background: #0b66f8; color: #fff"
                  @click="loginSystem"
                >
                  {{ $t("login.login") }}</Button
                >
              </i-col>
            </Row>
          </Form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import qs from "qs";

import { checkUserName } from "@/utils/validate";
import { setPassword } from "@/utils/password";
import request from "@/utils/request";
import { getLanguage, setLanguage, setToken, setUserId } from "@/utils/auth";
export default {
  name: "login",
  components: {},
  data() {
    return {
      login: {
        account: "admin",
        password: "admin"
      },
      loginFormValidate: {
        account: [
          {
            required: true,
            message: this.$t("login.mustAccount"),
            trigger: "blur"
          }
        ]
      },
      passwordType: true,
      LanguageList: [
        { name: "简体中文", type: "zh" },
        { name: "繁体中文", type: "tr" },
        { name: "English", type: "en" },
        { name: "Deutsch", type: "de" },
        { name: "Español", type: "es" },
        { name: "Français", type: "fr" },
        { name: "Italiano", type: "it" },
        { name: "עברית", type: "ug" },
      ],
      languageName: "",
      languageItem: ""
    };
  },
  computed: {},
  watch: {},
  created() {
    var _this = this;
    document.onkeydown = function(e) {
      var key = window.event.keyCode;
      if (key === 13) {
        _this.loginSystem();
      }
    };
  },
  mounted() {
    localStorage.clear();
    debugger;
  },
  destroyed() {
    document.onkeydown = function(e) {
      var key = window.event.keyCode;
      if (key === 13) {
        console.log("2342341212312:123123");
      }
    };
  },
  methods: {
    visible() {
      this.passwordType = !this.passwordType;
    },
    loginSystem() {
      setUserId(true)
      this.$router.push("/chart");
    },
    changeLanguage(index) {
      console.log(index);
      this.languageItem = this.LanguageList[index];
      this.languageName = this.LanguageList[index].name;
      if (Number(index) === 0) {
        setLanguage("zh");
      } else if (Number(index) === 1) {
        setLanguage("tr");
      }else if (Number(index) === 2) {
        setLanguage("en");
      }else if (Number(index) === 3) {
        setLanguage("de");
      }else if (Number(index) === 4) {
        setLanguage("es");
      }else if (Number(index) === 5) {
        setLanguage("fr");
      }else if (Number(index) === 6) {
        setLanguage("it");
      }else if (Number(index) === 7) {
        setLanguage("ug");
      }
      setTimeout(() => {
        window.location.reload();
      }, 200);
    },
    test() {
      let obj = {
        pageIndex: 1,
        pageSize: 10,
        sortField: 0,
        sortMode: 0
      };
      this.$store.dispatch("user/login", obj).then(response => {
        console.log(response);
      });
    }
  }
};
</script>
