<style lang="scss" scoped>
.page-header{
  display: flex;
  h3{
    margin-left: 10px;
  }
  .icon{
    cursor: pointer;
  }
}
::v-deep.ivu-date-picker{
  width: 100%!important;
}
 ::v-deep .ivu-table-header th{
  height: 25px!important;
  text-align: center;
}
::v-deep .ivu-table-cell{
  white-space: pre-line;
  }
</style>
<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <Icon v-if="validForm.projectId!==undefined" type="ios-arrow-back" color="#0F75FF" size="18" class="icon" @click="goBack" />
      <h3>提交记录</h3>
    </div>
    <div class="main-body">
      <div class="main-title margin-bottom-20">
        <Row :gutter="20">
          <i-col :span="4">
            <Input v-model="commitId" placeholder="请输入commitId" size="large" clearable></Input>
          </i-col>
          <i-col :span="4" class="text-left">
            <Select v-model="projectId" size="large" placeholder="请选择项目名称" filterable clearable>
              <Option v-for="item in projectList" :key="item.projectId+item.projectName" :value="item.projectId">{{ item.projectName }}</Option>
            </Select>
          </i-col>
          <i-col :span="4" class="text-left">
            <Select v-model="realUserId" size="large" placeholder="请选择人员" filterable clearable>
              <Option v-for="item in personList" :key="item.realUserId+item.realUserName" :value="item.realUserId">{{ item.realUserName }}</Option>
            </Select>
          </i-col>
          <i-col :span="4" class="text-left">
            <Select v-model="storageId" size="large" placeholder="请选择仓库" filterable clearable>
              <Option v-for="(item,index) in storageList" :key="index" :value="item.storageId">{{ item.storageName }}</Option>
            </Select>
          </i-col>
          <i-col :span="5">
            <div class="date-box">
              <DatePicker type="daterange" :options="options2" placement="bottom-end" placeholder="请选择日期" style="width: 200px" size="large" :value="selectTimeValue" @on-change="changeTime"></DatePicker>
            </div>
          </i-col>
          <i-col :span="3">
            <Button v-debounce size="large" type="primary" @click="searchList">
              <span class="fa fa-search"></span>
            </Button>
          </i-col>
        </Row>
      </div>
      <div v-if="hasList">
        <div class="page-table margin-bottom-20">
          <Table :loading="tableLoading" :columns="columns1" stripe :data="dataList">
            <template slot="deletions" slot-scope="{ row }">
              <div class="actionLink">
                <span class="delete-txt">{{ row.deletions }}</span>
              </div>
            </template>
            <template slot="additions" slot-scope="{ row }">
              <div class="actionLink">
                <span class="add-txt">{{ row.additions }}</span>
              </div>
            </template>
          </Table>
        </div>
        <div class="page-footer text-center">
          <Page
            :total="itemTotal"
            :current="pageIndex"
            :page-size="pageSize"
            show-elevator
            show-total
            show-sizer
            @on-page-size-change="getPageSize"
            @on-change="getPageList"
          />
        </div>
      </div>
      <div v-else class="main-none">
        <noListData></noListData>
      </div>
    </div>
    <div class="content_win">
    </div>
  </div>
</template>

<script>
import myMixins from '@/utils/myMixins'
import { formatDateTime } from '@/utils/commFunction'
import { mapState } from 'vuex'
export default {
  name: 'message',
  components: {
  },
  mixins: [myMixins],
  data() {
    return {
      selectActive: 1,
      hasList: false,
      pageSize: 10,
      pageIndex: 1,
      itemTotal: 0,
      validForm: {
      },
      query: {},
      dataList: [],
      projectList: [],
      personList: [],
      storageList: [],
      realUserId: '',
      storageId: '',
      projectId: '',
      startDate: '',
      commitId: '',
      endDate: '',
      selectTime: [],
      tableLoading: false,
      selectTimeValue: []
    }
  },
  computed: {
    ...mapState('commit', ['columns1'])
  },
  watch: {
    'realUserId'(newVal, oldVal) {
      this.getProjectNameList()
      this.getStoragesList()
    },
    'storageId'(newVal, oldVal) {
      this.getProjectNameList()
      this.getPersonList()
    },
    'projectId'(newVal, oldVal) {
      this.getStoragesList()
      this.getPersonList()
    }
  },
  created () {
    const end = new Date()
    const start = new Date()
    start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
    this.startDate = formatDateTime(start, 'yyyy-MM-dd')
    this.endDate = formatDateTime(end, 'yyyy-MM-dd')
    this.selectTimeValue[0] = this.startDate
    this.selectTimeValue[1] = this.endDate
  },
  mounted () {
    if (this.$route.params.projectId !== undefined) {
      this.$set(this.validForm, 'projectId', this.$route.params.projectId)
    }
    this.getList()
    this.getPersonList()
  },
  methods: {
    // 分页
    getPageList(index) {
      this.pageIndex = index
      this.getList()
    },
    getPageSize(size) {
      this.pageIndex = 1
      this.pageSize = size
      this.getList()
    },
    searchList() {
      this.pageIndex = 1
      this.getList()
    },
    updatePerson() {
      this.$refs.editPerson.dialogVisible = true
    },
    getList() {
      this.tableLoading = true
      let Info = {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize
      }
      let validForm = {
        startDate: this.startDate,
        endDate: this.endDate,
        storageId: this.storageId,
        projectId: this.projectId,
        realUserId: this.realUserId,
        commitId: this.commitId
      }
      console.log('validForm', validForm)
      Info = Object.assign(validForm, Info)
      this.$store
        .dispatch('commit/getList', Info)
        .then(response => {
          this.tableLoading = false
          const res = response.data
          if (res.records && res.records.length === 0) {
            this.hasList = false
          } else {
            this.hasList = true
            this.dataList = res.records
            this.itemTotal = res.total
          }
        })
        .catch(() => {
          this.tableLoading = false
        })
    },
    goBack() {
      this.$router.push('/video')
    },
    getProjectNameList() {
      let params = {
        realUserId: this.realUserId,
        storageId: this.storageId,
        type: 1
      }
      this.$store
        .dispatch('commit/getProjectNameList', params)
        .then(response => {
          this.projectList = response.data
        })
        .catch(() => {})
    },
    getPersonList() {
      let params = {
        projectId: this.projectId,
        storageId: this.storageId,
        type: 0
      }
      this.$store
        .dispatch('commit/getPersonList', params)
        .then(response => {
          this.personList = response.data
        })
        .catch(() => {})
    },
    getStoragesList() {
      let params = {
        projectId: this.projectId,
        realUserId: this.realUserId,
        type: 0
      }
      this.$store
        .dispatch('commit/getStoragesList', params)
        .then(response => {
          this.storageList = response.data
        })
        .catch(() => {})
    },
    changeTime(data) {
      console.log(data)
      this.selectTime = data
      this.startDate = data[0]
      this.endDate = data[1]
    }
  }
}
</script>
