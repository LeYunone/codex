<template>
  <div>
    <Modal v-model="dialogVisible"
           width="50%"
           class-name="vertical-center-modal"
           class="page-modal"
           footer-hide
           title="检测指标推送内容"
           :closable="true"
    >
      <div class="container">
        <mavon-editor ref="editor" v-model="content" :toolbars="toolbars">

          <template slot="left-toolbar-after">
            <button
              type="button"
              class="op-icon fa fa-user"
              aria-hidden="true"
              title="插入用户占位符"
              @click="insertCustomText(formItem,index)"
            ></button>
          </template>
        </mavon-editor>
        <div class="btn-box">
          <Button
            size="large"
            class="footer-btn"
            @click="cancelClose"
          >
            {{ $t('common.cancel') }}
          </Button>
          <Button type="primary" size="large" class="footer-btn" @click="confirm">{{ $t('common.ensure') }}</Button>
        </div>
      </div>
    </Modal>
  </div>
</template>

<script>
import { mavonEditor } from 'mavon-editor'
import 'mavon-editor/dist/css/index.css'
import { mapState } from 'vuex'
export default {
  name: 'confirmModal',
  components: {
    mavonEditor
  },
  data () {
    return {
      dialogVisible: false,
      item: {},
      formData: [],
      content: '',
      id: '',
      index: null
    }
  },
  watch: {
    dialogVisible(newVal) {
      if (newVal) {
        console.log(this.content)
      } else {
        this.cancelClose()
      }
    }
  },
  computed: {
    ...mapState('bugDetails', ['toolbars'])
  },
  mounted () {
  },
  methods: {
    confirm () {
      console.log(this.content)
      this.dialogVisible = false
      this.$emit('getConditionContent', {
        content: this.content,
        index: this.index,
        id: this.id
      })
    },
    cancelClose() {
      this.dialogVisible = false
    },
    insertCustomText (formItem, index) {
      // 在这里定义你想要插入的自定义文本
      this.$nextTick(() => {
        const editor = this.$refs.editor
        editor.insertText(editor.getTextareaDom(), {
          prefix: `#{user}`,
          subfix: '',
          str: ''
        })
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 30px 0 15px;
  button {
    width: 60px;
    height: 30px;
    margin: 0 20px;
  }
}
.form{
  width: 100%;
  margin-bottom: 15px;
  padding:15px;
  background: #eee;
}
.ivu-form-item{
  display: flex;
  align-items: center;
}
::v-deep .ivu-form-item-content{
  flex: 1;
  margin-left: 0!important;
  display:flex;
  align-items:center;
}
::v-deep .ivu-modal-body {
  max-height: 700px !important;
  overflow-y: scroll;
}
.bot-box{
  display:flex;
  align-items:center;
}
::v-deep .ivu-dropdown{
  width:100%;
}
.baud-down-icon{
  position: absolute;
  right:10px;
}
.form-btn{
  display: flex;
  justify-content: end;
  width:100%;
  .ivu-btn{
    width:90%;
    height:37px;
  }
}
.ivu-icon{
  cursor: pointer;
}
.btn-box{
  margin-top: 20px;
}

</style>
