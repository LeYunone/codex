<template>
  <div>
    <el-dialog
      :title="title"
      :visible.sync="dialogVisible"
      width="50%"
      :closable="true"
      top="40px"
    >
      <div class="container">
        <el-form ref="ruleForm" :model="formData" label-width="200px" class="form-box">
          <!-- <div v-for="(formItem,index) in formData" :key="index" class="add-box"> -->
          <el-form-item label="状态：" class="status-box">
            <el-switch
              v-model="formData.status"
              active-color="#409eff"
              inactive-color="#e6e6e6"
            >
            </el-switch>
          </el-form-item>
          <el-form-item key="formItem.id" label="监测对象：">
            <div class="monitor-box">
              <div class="radio-box">
                <el-radio v-model="formData.alarmAll" label="0">局部</el-radio>
                <el-radio v-model="formData.alarmAll" label="1">全部</el-radio>
              </div>
              <div v-if="formData.alarmAll=='0'">
                <Row type="flex" :gutter="20">
                  <i-col span="6">
                    <el-select v-model="formData.selectIndex" placeholder="请选择监测对象类型" filterable @change="changeAlarmSelect(formData.id,$event)">
                      <el-option
                        v-for="item in alarmAllList"
                        :key="item.value"
                        :label="item.title"
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </i-col>
                  <i-col v-show="formData.selectIndex==1" span="12">
                    <el-select v-model="formData.alarmObject.realProjectNames" placeholder="请选择项目" filterable multiple>
                      <el-option
                        v-for="(item,index) in projectName"
                        :key="item.value+index"
                        :label="item.value"
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </i-col>
                  <i-col v-show="formData.selectIndex==2" span="6">
                    <el-select v-model="formData.alarmObject.groupIds" placeholder="请选择部门" filterable multiple>
                      <el-option
                        v-for="item in deptList"
                        :key="item.groupId"
                        :label="item.groupName"
                        :value="item.groupId"
                      >
                      </el-option>
                    </el-select>
                  </i-col>
                  <i-col v-show="formData.selectIndex==3" span="6">
                    <el-select v-model="formData.alarmObject.users" placeholder="请选择工程师" filterable multiple>
                      <el-option
                        v-for="item in personList"
                        :key="item.realUserId"
                        :label="item.realUserName"
                        :value="item.realUserId"
                      >
                      </el-option>
                    </el-select>
                  </i-col>
                </Row>
              </div>
            </div>
          </el-form-item>
          <el-form-item label="监测指标：" class="require-item">
            <Row :gutter="20">
              <i-col>
                <el-radio v-model="formData.triggerType" label="1">全部满足时执行</el-radio>
              </i-col>
              <i-col>
                <el-radio v-model="formData.triggerType" label="2">满足任一条执行</el-radio>
              </i-col>
            </Row>
            <div v-for="(alarmItem,alarmIndex) in formData.alarmConditions" :key="alarmItem.key">
              <Row type="flex" :gutter="20" class="alarm-condition-box">
                <i-col span="7">
                  <el-select v-model="alarmItem.key" placeholder="请选择监测指标类型" filterable clearable @change="handleChangeConditions(formData.id,alarmIndex)">
                    <el-option
                      v-for="item in targetList"
                      :key="item.value"
                      :label="item.title"
                      :value="item.value"
                      :disabled="isDisabled(formData.id,alarmIndex,item.value)"
                    >
                    </el-option>
                  </el-select>
                </i-col>
                <i-col span="4">
                  <el-select v-model="alarmItem.conType" placeholder="运算" filterable clearable>
                    <el-option
                      v-for="item in mathList"
                      :key="item.value"
                      :label="item.title"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </i-col>
                <i-col span="5">
                  <el-input v-model="alarmItem.condition" placeholder="请输入监测数值" class="inp" clearable>
                  </el-input>
                </i-col>
                <i-col span="5">
                  <el-input v-model="alarmItem.day" placeholder="监测周期(天)" class="inp" clearable>
                  </el-input>
                </i-col>
                <i-col span="1">
                  <el-tooltip class="item" effect="dark" content="点击删除该监测条件" placement="bottom" :transfer="true">
                    <i class="el-icon-delete icon-delete" @click="deleteCondition(formData.id,alarmIndex)"></i>
                  </el-tooltip>
                </i-col>
              </Row>
            </div>
            <div v-if="formData.alarmConditions.length<5" class="icon-box" @click="addAlarmCondition(formData.id)">
              <i class="el-icon-plus icon-item"></i>
            </div>
          </el-form-item>
          <el-form-item label="执行周期：" class="require-item">
            <el-popover title="执行周期" trigger="click" placement="top-start" style="z-index:2500!important">
              <myCron v-model="formData.cron" />
              <el-input slot="reference" v-model="formData.cron" placeholder="请设置执行周期(点击右侧图标进行设置)" class="inp" clearable :readonly="true">
                <i slot="suffix" class="el-icon-edit"></i>
              </el-input>
            </el-popover>
          </el-form-item>
          <el-form-item label="推送类型：" class="require-item">
            <div class="url-box">
              <div class="radio-box">
                <el-radio v-model="formData.alarmType" label="1">企微机器人</el-radio>
                <el-radio v-model="formData.alarmType" label="0">邮箱</el-radio>
              </div>
            </div>
            <template v-if="formData.alarmType=='1'">
              <el-input v-model="formData.botUrl1" placeholder="请输入企微机器人地址" clearable @input="change($event)" />
            </template>
            <template v-else>
              <el-input v-model="formData.emailUrl" placeholder="请输入邮箱地址" clearable @input="change($event)"/>
            </template>
          </el-form-item>
          <el-form-item label="报警内容：">
            <mavon-editor ref="editor" v-model="formData.content" :toolbars="toolbars">
              <template slot="left-toolbar-after">
                <button
                  type="button"
                  class="op-icon fa fa-user"
                  aria-hidden="true"
                  title="插入用户占位符"
                  @click="insetCommonText(formData,'user')"
                ></button>
                <button
                  type="button"
                  class="op-icon fa fa-user-plus"
                  aria-hidden="true"
                  title="插入部门占位符"
                  @click="insetCommonText(formData,'groups')"
                ></button>
                <button
                  type="button"
                  class="op-icon fa fa-sitemap"
                  aria-hidden="true"
                  title="插入项目占位符"
                  @click="insetCommonText(formData,'projects')"
                ></button>
                <button
                  type="button"
                  class="op-icon fa fa-solid fa-database"
                  aria-hidden="true"
                  title="插入监测数据占位符"
                  @click="insetCommonText(formData,'alarmDatas')"
                ></button>
              </template>
            </mavon-editor>
          </el-form-item>
          <!-- </div> -->
        </el-form>
        <span slot="footer" class="dialog-footer">
          <Button
            size="large"
            class="footer-btn" @click="cancelClose"
          >{{ $t('common.cancel') }}</Button>
          <Button type="primary" size="large" class="footer-btn" @click="saveWarm">{{ $t('common.ensure') }}</Button>
        </span>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import myCron from '@/components/Cron/index.vue'
import { mavonEditor } from 'mavon-editor'
import 'mavon-editor/dist/css/index.css'
import { mapState } from 'vuex'
export default {
  name: 'confirmModal',
  components: {
    mavonEditor,
    myCron
  },
  data () {
    return {
      dialogVisible: false,
      item: {},
      formData: {
        alarmAll: '0',
        alarmConditions: [],
        triggerType: '1',
        cron: '',
        botUrl: '',
        emailUrl: '',
        botUrl1: '',
        alarmType: '1', // 1:企微机器人 0:邮箱
        content: '',
        alarmObject: {
          groupIds: [],
          realProjectNames: [],
          users: []
        }
      },
      personList: [],
      deptList: [],
      projectName: [],
      selectIndex: 1,
      isEdit: false,
      title: '新增'
    }
  },
  watch: {
    dialogVisible(newVal) {
      if (newVal) {
        this.getPersonList()
        this.getDeptList()
        this.getBugSystemName()
        this.formatAlarm()
      } else {
        this.cancelClose()
      }
    }
  },
  computed: {
    ...mapState('warming', ['targetList', 'mathList', 'alarmAllList', 'toolbars']),
    disabledOptions() {
      return (id, item) => {
        let keyArr = []
        // 取出alarmConditions中所有的key
        keyArr = this.formData.alarmConditions.map(item => {
          return item.key
        })
        console.log('keyArr', keyArr)
        if (keyArr.includes(item.key)) {
          return true
        } else {
          return false
        }
      }
    }
  },
  mounted () {
  },
  methods: {
    change (e) {
      this.$forceUpdate()
    },
    formatAlarm (formData) {
      if (!this.isEdit) {
        this.$set(this.formData, 'cron', '* * * ? * * *')
      }
      this.formData.alarmAll = this.formData.alarmAll == null ? '0' : this.formData.alarmAll.toString()
      this.formData.triggerType = this.formData.triggerType == null ? '0' : this.formData.triggerType.toString()
      this.formData.alarmType = this.formData.alarmType == null ? '1' : this.formData.alarmType.toString()
      console.log('this.formData---', this.formData)
      if (this.formData.alarmType == '1') {
        this.$set(this.formData, 'botUrl1', this.formData.botUrl)
      } else {
        this.$set(this.formData, 'emailUrl', this.formData.botUrl)
      }
      // 判断alarmObject哪一项有值，将selectIndex赋值
      if (this.formData.alarmObject.groupIds.length > 0) {
        this.$set(this.formData, 'selectIndex', 2)
      } else if (this.formData.alarmObject.realProjectNames.length > 0) {
        this.$set(this.formData, 'selectIndex', 1)
      } else if (this.formData.alarmObject.users.length > 0) {
        this.$set(this.formData, 'selectIndex', 3)
      }
    },
    cancelClose () {
      this.dialogVisible = false
      this.$refs['ruleForm'].resetFields()
      // 清空表单
      this.formData = {
        alarmAll: '0',
        alarmConditions: [],
        triggerType: '1',
        cron: '* * * ? * * *',
        botUrl: '',
        emailUrl: '',
        botUrl1: '',
        alarmType: '1', // 1:企微机器人 0:邮箱
        content: '',
        alarmObject: {
          groupIds: [],
          realProjectNames: [],
          users: []
        }
      }
    },
    getPersonList() {
      let params = {
        type: 0
      }
      this.$store
        .dispatch('commit/getPersonList', params)
        .then(response => {
          this.personList = response.data
        })
        .catch(() => {})
    },
    getDeptList() {
      this.$store
        .dispatch('deptManager/getDeptList')
        .then(response => {
          this.deptList = response.data
        })
        .catch(() => {})
    },
    getBugSystemName () {
      this.$store
        .dispatch('bugDetails/getBugSystemName')
        .then(response => {
          const { data } = response
          data.projectName.forEach(item => {
            this.projectName.push({
              value: item,
              label: item
            })
          })
        })
        .catch(() => {
        })
    },
    addAlarmCondition (id) {
      this.formData.alarmConditions.push({
        condition: '',
        conType: '',
        key: null,
        day: ''
      })
    },
    deleteCondition (id, index) {
      this.formData.alarmConditions.splice(index, 1)
    },
    saveWarm () {
      // 遍历formData，同时判断botUrl和day和cron是否为空，一处为空则终止流程
      let flag = true
      if (!this.formData.cron) {
        flag = false
        this.$Message.error(`执行周期不能为空`)
        return false
      }
      if (this.formData.alarmAll == '0') {
        // 局部
        if (this.formData.alarmObject.realProjectNames.length == 0 && this.formData.alarmObject.groupIds == 0 && this.formData.alarmObject.users.length == 0) {
          flag = false
          this.$message({
            message: '监测对象不能为空',
            type: 'warning'
          })
          return false
        }
      }
      // 监测指标不能为空
      if (this.formData.alarmConditions.length == 0) {
        flag = false
        this.$message({
          message: '监测指标不能为空',
          type: 'warning'
        })
        return false
      }
      if (this.formData.alarmType == '0') {
        if (this.formData.emailUrl == '') {
          flag = false
          this.$message({
            message: '邮箱不能为空',
            type: 'warning'
          })
          return false
        }
        if (this.formData.emailUrl !== '') {
          let reg = /^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\.([A-Za-z]{2,4})$/
          if (!reg.test(this.formData.emailUrl)) {
            flag = false
            this.$message({
              message: '邮箱格式不正确',
              type: 'warning'
            })
            return false
          }
        }
      }
      if (this.formData.alarmType == '1') {
        if (this.formData.botUrl1 == '') {
          flag = false
          this.$message({
              message: '企微机器人地址不能为空',
              type: 'warning'
            })
          return false
        }
      }

      if (!flag) return
      // 当alarmAll和status转为字符串
      this.formData.alarmAll = this.formData.alarmAll == null ? '0' : this.formData.alarmAll.toString()
      if (this.formData.alarmAll == '1') {
        this.formData.alarmObject = {
          groupIds: [],
          realProjectNames: [],
          users: []
        }
      }
      if (this.formData.alarmType == '1') {
        this.formData.botUrl = this.formData.botUrl1
      } else {
        this.formData.botUrl = this.formData.emailUrl
      }
      // 将triggerType转成数字
      this.formData.triggerType = parseInt(this.formData.triggerType)
      this.$store.dispatch('warming/saveBot', this.formData).then(res => {
        this.$message.success('操作成功')
        this.dialogVisible = false
        this.$emit('refreshList')
      })
    },
    handleChangeConditions(formId, cIndex) {
      const selectedKey = this.formData.alarmConditions[cIndex].key
      this.formData.alarmConditions[cIndex].key = selectedKey
    },
    isDisabled(formId, cIndex, value) {
      const selectedKey = this.formData.alarmConditions[cIndex].key
      return this.formData.alarmConditions.some((condition) => {
        return condition.key === value && condition.key !== selectedKey
      })
    },
    changeAlarmSelect (id, e) {
      this.formData.alarmObject = {
        groupIds: [],
        realProjectNames: [],
        users: []
      }
    },
    // 占位符
    insetCommonText (formItem, text) {
      this.$nextTick(() => {
        const editor = this.$refs.editor
        editor.insertText(editor.getTextareaDom(), {
          prefix: `#{${text}}`,
          subfix: '',
          str: ''
        })
      })
    }
  }

}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0px 0 15px;
  .status-box{
    display: flex;
    ::v-deep .el-form-item__content{
      margin-left: 0!important;
    }
  }
  button {
    width: 80px;
    height: 30px;
    margin: 0 20px;
  }
}
.form{
  width: 100%;
  margin-bottom: 15px;
  padding:15px;
  background: #eee;
}
.ivu-form-item{
  display: flex;
  align-items: center;
}
::v-deep .ivu-form-item-content{
  flex: 1;
  margin-left: 0!important;
  display:flex;
  align-items:center;
}
::v-deep .ivu-modal-body {
  max-height: 700px !important;
  overflow-y: scroll;
}
::v-deep .ivu-dropdown{
  width:100%;
}
.ivu-icon{
  cursor: pointer;
}
::v-deep .el-select {
  .el-input{
    width: 100%;
  }
}
.monitor-box{
  border:1px dashed #e6e6e6;
  padding: 5px 10px 10px;
  .radio-box{
    display: flex;
    justify-content: start;
    margin: 10px 0;
  }
}
.url-box{
  padding: 5px 10px 10px;
  .radio-box{
    display: flex;
    justify-content: start;
    margin: 10px 0;
  }

}
.alarm-condition-box{
  margin-bottom: 10px;
}
.icon-box{
  border: 1px solid #e6e6e6;
  width:80px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
  cursor: pointer;
  .icon-item{
    font-size: 20px;
    cursor: pointer;
    color: #999;
  }
}
.icon-box:hover{
  border: 1px solid #409EFF;
  .icon-item{
    color: #409EFF;
  }
}
.icon-delete{
  font-size: 20px;
  cursor: pointer;
  color: #F56C6C;
}
.icon-info{
  font-size: 20px;
  cursor: pointer;
  color: #409EFF;
}
.add-box{
  border: 1px solid #e6e6e6;
  margin-bottom: 15px;
  padding: 20px;
  position: relative;
  .icon-close{
    position: absolute;
    right: -12px;
    top:-12px;
    font-size: 26px;
    cursor: pointer;
    color: #c0c4cc;
  }
}
.add-condition-box{
  width: 65%;
  display: flex;
  justify-content: end;
  margin-bottom: 20px;
}
.add-center{
  justify-content: center;
  margin-top: -80px;
}
.require-item{
  ::v-deep .el-form-item__label::before{
    content:'*';
    color: #F56C6C;
    font-size: 16px;
    margin-right: 5px;
  }
}
::v-deep .el-select{
  width: 100%;
}
::v-deep .el-cascader{
  width: 100%;
}
.v-note-wrapper{
  z-index: 99;
}
// .el-popover-add{
//   z-index:2000!important;
// }
::v-deep .el-dialog__header {
    padding: 1.25rem 1.25rem 0.625rem;
    background: #2d8cf0;
}
::v-deep .el-dialog__title{
  color: #fff;
}
::v-deep .el-dialog__body{
  padding: 5px 30px;
  max-height: 750px !important;
  overflow-y:auto;
}
::v-deep .el-dialog__headerbtn .el-dialog__close{
  color: #fff;
}
</style>
