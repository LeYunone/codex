<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>监测预警列表</h3>
    </div>
    <div class="main-body">
      <div class="main-title margin-bottom-20">
        <Row :gutter="20" type="flex" justify="space-between">
          <i-col :span="16" class="text-left">
          </i-col>
          <i-col :span="2" class="text-left add-btn">
            <Button v-debounce size="large" type="primary" class="add-btn" @click="addWarn(0)">
              新增
            </Button>
          </i-col>
        </Row>
      </div>
      <div v-if="hasList">
        <div class="page-table margin-bottom-20">
          <Table :columns="column" :data="dataList" stripe :loading="tableLoading">
            <template slot="status" slot-scope="{ row }">
              <i-switch v-model="row.status" @on-change="changeStatus($event,row.id)"></i-switch>
            </template>
            <template slot="alarmType" slot-scope="{ row }">
              <span>{{ row.alarmType==1?'企微机器人':'邮箱' }}</span>
            </template>
            <template slot="alarmObject" slot-scope="{ row }">
              <Tooltip v-if="getWarnType(row)!=='全部'" :content="getTooltipContent(row)">
                <span style="cursor: pointer;">{{ getWarnType(row) }}</span>
                <i class="el-icon-info" color="#ccc" style="margin-left: 5px;" />
              </Tooltip>
              <span v-else>{{ getWarnType(row) }}</span>
            </template>
            <template slot="actions" slot-scope="{ row }">
              <Row type="flex" justify="center" :gutter="20">
                <i-col :span="8">
                  <Button
                    class="delete-btn"
                    type="dashed"
                    icon="ios-trash-outline"
                    @click="deleteWarn(row.id)"
                  >删除</Button>
                </i-col>
                <i-col :span="8">
                  <Button
                    class="action-btn"
                    type="dashed"
                    icon="ios-create"
                    @click="addWarn(1,row)"
                  >修改</Button>
                </i-col>

              </Row>
            </template>
          </Table>
        </div>
        <div class="page-footer text-center">
          <Page
            :total="itemTotal"
            :page-size-opts="[10, 20, 40]"
            :current="pageIndex"
            :page-size="pageSize"
            show-elevator
            show-total
            show-sizer
            @on-page-size-change="getPageSize"
            @on-change="getPageList"
          />
        </div>
      </div>
      <div v-else class="main-none">
        <noListData></noListData>
      </div>
    </div>
    <div>
      <confirmModal ref="confirmModal" @entrueClose="cancelClose">
        <div slot="info">
          <p class="p-text">确定删除该机器人？</p>
        </div>
      </confirmModal>
      <warnModel ref="warnModel" @refreshList="getList" />
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex'
import warnModel from './conponents/warnModel'
  export default {
    components: { warnModel },
    data () {
      return {
        dataList: [],
        hasList: true,
        pageSize: 10,
        pageIndex: 1,
        itemTotal: 0,
        projectId: '',
        department: [],
        query: {
          realProjectName: ''
        },
        tableLoading: false,
        deleteRealProjectNames: '',
        deleteId: '',
        personList: [],
        deptList: [],
        projectName: []
      }
    },
  computed: {
    ...mapState('warming', [
      'column'
    ]),
    getWarnType () {
      return (row) => {
        let str = ''
        if (row.alarmObject.groupIds.length === 0 && row.alarmObject.realProjectNames.length === 0 && row.alarmObject.users.length === 0) {
          str = '全部'
        } else if (row.alarmObject.groupIds.length !== 0) {
          str = '部门'
        } else if (row.alarmObject.realProjectNames.length !== 0) {
          str = '项目'
        } else if (row.alarmObject.users.length !== 0) {
          str = '成员'
        }
        return str
      }
    }
  },
  mounted () {
    this.getPersonList()
    this.getDeptList()
    this.getBugSystemName()
    this.getList()
  },
  methods: {
    // 分页
    getPageList (index) {
      this.pageIndex = index
      this.getList()
    },
    getPageSize (size) {
      this.pageIndex = 1
      this.pageSize = size
      this.getList()
    },
    searchList () {
      this.pageIndex = 1
      this.getList()
    },
    getList () {
      this.tableLoading = true
      let Info = {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize
      }
      this.$store
        .dispatch('warming/getAlarm', Info)
        .then(response => {
          const res = response.data
          if (res.records && res.records.length == 0) {
            this.hasList = false
          } else {
            this.hasList = true
            this.itemTotal = res.total
            this.dataList = res.records
          }
          this.tableLoading = false
        })
        .catch(() => {
          this.tableLoading = false
        })
    },
    detail (row) {
      this.$refs.projectPerson.dialogVisible = true
      this.$refs.projectPerson.row = row.row.users
    },
    changeTime (data) {
      this.startDate = data
    },
    addGitProject (type, row) {
      this.$refs.addGitProject.dialogVisible = true
      if (type === 1) {
        let obj = {
          realProjectName: row.row.realProjectName,
          projectIds: row.row.projectIds
        }
        this.$refs.addGitProject.title = '修改'
        this.$refs.addGitProject.row = obj
        this.$refs.addGitProject.isEdit = true
      } else {
        this.$refs.addGitProject.title = '新增'
        this.$refs.addGitProject.isEdit = false
        this.$refs.addGitProject.row = {}
      }
    },
    deleteWarn (id) {
      this.deleteId = id
      this.$refs.confirmModal.dialogVisible = true
      this.$refs.confirmModal.isClose = true
    },
    cancelClose () {
      let params = {
        id: this.deleteId
      }
      this.$store
        .dispatch('warming/deleteWarn', params)
        .then(response => {
          this.$Message.success('删除成功')
          this.getList()
        })
        .catch(() => {})
    },
    changeStatus (e, id) {
      let params = {
        id: id,
        status: e
      }
      this.$store
        .dispatch('warming/chanceStatus', params)
        .then(response => {
          this.$Message.success('操作成功')
          this.getList()
        })
        .catch(() => {})
    },
    addWarn (type, row) {
      this.$refs.warnModel.dialogVisible = true
      if (type === 1) {
        this.$refs.warnModel.title = '修改'
        this.$refs.warnModel.isEdit = true
        // 深拷贝
        this.$refs.warnModel.formData = JSON.parse(JSON.stringify(row))
      } else {
        this.$refs.warnModel.title = '新增'
        this.$refs.warnModel.isEdit = false
      }
    },
    getPersonList() {
      let params = {
        type: 0
      }
      this.$store
        .dispatch('commit/getPersonList', params)
        .then(response => {
          this.personList = response.data
        })
        .catch(() => {})
    },
    getDeptList() {
      this.$store
        .dispatch('deptManager/getDeptList')
        .then(response => {
          this.deptList = response.data
        })
        .catch(() => {})
    },
    getBugSystemName () {
      this.$store
        .dispatch('bugDetails/getBugSystemName')
        .then(response => {
          const { data } = response
          data.projectName.forEach(item => {
            this.projectName.push({
              value: item,
              label: item
            })
          })
        })
        .catch(() => {
        })
    },
    getTooltipContent (row) {
      let type = this.getWarnType(row)
      let content = ''
      if (type !== '全部') {
        if (type === '项目') {
          content = row.alarmObject.realProjectNames.join('、')
        } else if (type === '部门') {
          this.deptList.forEach(item => {
            if (row.alarmObject.groupIds.includes(item.groupId)) {
              content += item.groupName + '、'
            }
          })
        } else if (type == '成员') {
          this.personList.forEach(item => {
            if (row.alarmObject.users.includes(item.realUserId)) {
              content += item.realUserName + '、'
            }
          })
        }
      }
      content = content.substring(0, content.length - 1)
      return content
    }
  }
}
</script>
<style lang="scss" scoped>
  ::v-deep .ivu-date-picker{
    width: 100%;
  }
  .no-tip{
    color: #9999;
  }
  ::v-deep .ivu-table-cell{
    padding: 10px 0;
  }
  .page-table{
    ::v-deep .ivu-tooltip-inner {
      padding: 10px;
    }
  }
</style>
