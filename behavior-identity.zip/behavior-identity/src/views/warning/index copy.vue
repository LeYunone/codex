<template>
  <div class="page">
    <div class="page-header margin-bottom-20">
      <h3>检测预警管理</h3>
    </div>
    <div class="main-body">
      <template v-if="formData.length!==0 || isOne">
        <el-form ref="ruleForm" :model="formData" label-width="200px" class="form-box">
          <div v-for="(formItem,index) in formData" :key="index" class="add-box">
            <el-form-item label="推送机器URL：" class="require-item">
              <el-input v-model="formItem.botUrl" placeholder="请输入推送的机器URL">
              </el-input>
              <!-- <span class="require-txt">*</span> -->
            </el-form-item>
            <el-form-item key="formItem.id" label="监测对象：">
              <div class="monitor-box">
                <el-radio v-model="formItem.alarmAll" label="0">局部</el-radio>
                <el-radio v-model="formItem.alarmAll" label="1">全部</el-radio>
                <div v-if="formItem.alarmAll=='0'">
                  <Row type="flex" :gutter="20">
                    <i-col span="12">
                      <el-select v-model="formItem.alarmObject.realProjectNames" placeholder="请选择项目" filterable multiple>
                        <el-option
                          v-for="item in projectName"
                          :key="item.value"
                          :label="item.value"
                          :value="item.value"
                        >
                        </el-option>
                        <!-- <el-option
                          v-for="item in projectList"
                          :key="item.projectId"
                          :label="item.projectName"
                          :value="item.projectId"
                        >
                        </el-option> -->
                      </el-select>
                    </i-col>
                    <i-col span="6">
                      <el-select v-model="formItem.alarmObject.groupIds" placeholder="请选择部门" filterable multiple>
                        <el-option
                          v-for="item in deptList"
                          :key="item.groupId"
                          :label="item.groupName"
                          :value="item.groupId"
                        >
                        </el-option>
                      </el-select>
                    </i-col>
                    <i-col span="6">
                      <el-select v-model="formItem.alarmObject.users" placeholder="请选择工程师" filterable multiple>
                        <el-option
                          v-for="item in personList"
                          :key="item.realUserId"
                          :label="item.realUserName"
                          :value="item.realUserId"
                        >
                        </el-option>
                      </el-select>
                    </i-col>
                  </Row>
                </div>
              </div>
            </el-form-item>
            <el-form-item label="监测指标：" class="require-item">
              <div v-for="(alarmItem,alarmIndex) in formItem.alarmConditions" :key="alarmItem.key">
                <Row type="flex" :gutter="20" class="alarm-condition-box">
                  <i-col span="7">
                    <el-select v-model="alarmItem.key" placeholder="请选择监测指标类型" filterable clearable @change="handleChangeConditions(formItem.id,alarmIndex)">
                      <el-option
                        v-for="item in targetList"
                        :key="item.value"
                        :label="item.title"
                        :value="item.value"
                        :disabled="isDisabled(formItem.id,alarmIndex,item.value)"
                      >
                      </el-option>
                    </el-select>
                  </i-col>
                  <i-col span="4">
                    <el-select v-model="alarmItem.conType" placeholder="运算" filterable clearable>
                      <el-option
                        v-for="item in mathList"
                        :key="item.value"
                        :label="item.title"
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </i-col>
                  <i-col span="7">
                    <el-input v-model="alarmItem.condition" placeholder="请输入监测数值" class="inp" clearable>
                    </el-input>
                  </i-col>
                  <i-col span="1">
                    <el-tooltip class="item" effect="dark" content="点击自定义监测指标内容" placement="bottom">
                      <i class="el-icon-info icon-info" @click="setConditionContent(formItem.id,alarmIndex)"></i>
                    </el-tooltip>
                  </i-col>
                  <i-col span="1">
                    <el-tooltip class="item" effect="dark" content="点击删除该监测条件" placement="bottom">
                      <i class="el-icon-delete icon-delete" @click="deleteCondition(formItem.id,alarmIndex)"></i>
                    </el-tooltip>
                  </i-col>
                </Row>
              </div>
              <div v-if="formItem.alarmConditions.length<5" class="icon-box" @click="addAlarmCondition(formItem.id)">
                <i class="el-icon-plus icon-item"></i>
              </div>
            </el-form-item>
            <el-form-item label="监测周期(天)：" class="require-item">
              <el-input v-model="formItem.day" placeholder="请输入监测周期" class="inp" clearable>
              </el-input>
            </el-form-item>
            <el-form-item label="执行周期：" class="require-item">
              <el-input v-model="formItem.cron" placeholder="请设置执行周期(点击右侧图标进行设置)" class="inp" clearable :readonly="true">
                <i slot="suffix" class="el-icon-edit" @click="showDialog(formItem.id)"></i>
              </el-input>
            </el-form-item>
            <el-form-item label="机器人状态：">
              <!-- <el-radio v-model="formItem.status" label="1">运行</el-radio>
              <el-radio v-model="formItem.status" label="0">停止</el-radio> -->
              <el-switch
                v-model="formItem.status"
                active-color="#409eff"
                inactive-color="#e6e6e6">
              </el-switch>
            </el-form-item>
            <!-- 删除机器 -->
            <i class="el-icon-error icon-close" @click="deleteWarm(formItem.id)"></i>
          </div>
        </el-form>
      </template>
      <div v-else>
        <noListData :no-data-txt="noDataTxt"></noListData>
      </div>
      <div class="add-condition-box" :class="formData.length==0?'add-center':''">
        <el-button type="primary" icon="el-icon-video-camera-solid" plain @click="addMonitor">增加机器人</el-button>
      </div>
      <div v-if="formData.length!==0 || isOne" class="form-footer">
        <el-button type="" @click="cancelSave">取消</el-button>
        <el-button type="primary" @click="saveWarm">保存</el-button>
      </div>
    </div>
    <div>
      <el-dialog title="执行周期" :visible.sync="showCron">
        <vcrontab :expression="expression" @hide="showCron=false" @fill="crontabFill"></vcrontab>
      </el-dialog>
      <warmContent ref="warmContent" @getConditionContent="getConditionContent"></warmContent>
      <confirmModal ref="confirmModal" @entrueClose="cancelClose">
        <div slot="info">
          <p class="p-text">点击确定后将取消本次的所有修改</p>
        </div>
      </confirmModal>
      <confirmModal ref="deleteConfirmModal" @entrueClose="confirmDeleteWarm">
        <div slot="info">
          <p class="p-text">当前已经是最后一个机器人，是否确定删除</p>
        </div>
      </confirmModal>
    </div>
  </div>
</template>

<script >
import vcrontab from 'vcrontab'
import { mapState } from 'vuex'
import warmContent from './conponents/warmContent.vue'
import { uuid } from '@/utils/commFunction'
export default {
  components: { vcrontab, warmContent },
  data () {
    return {
      formData: [],
      id: null,
      input: '',
      expression: '',
      showCron: false,
      personList: [],
      deptList: [],
      projectList: [],
      projectName: [],
      noDataTxt: '请点击下方按钮添加机器人~',
      selectIdsArr: [],
      isOne: false,
      deleteWarmInfo: {
        index: null
      },

    }
  },
  computed: {
    ...mapState('warming', ['targetList', 'mathList']),
    disabledOptions() {
      return (id, item) => {
        let keyArr = []
        this.formData.forEach((item1, index1) => {
          if (item1.id == id) {
            // 取出alarmConditions中所有的key
            keyArr = item1.alarmConditions.map(item2 => {
              return item2.key
            })
          }
        })
        console.log('keyArr', keyArr)
        if (keyArr.includes(item.key)) {
          return true
        } else {
          return false
        }
      }
    }
  },
  mounted() {
    this.getPersonList()
    this.getDeptList()
    this.getBugSystemName()
    // this.getProjectNameList()
    this.getAlarm()
  },
  methods: {
    getAlarm() {
      this.$store.dispatch('codeQuality/getAlarm').then(res => {
        if (res.data) {
          this.formData = res.data
          // alarmAll和status转成字符串
          this.formData.forEach(item => {
            item.alarmAll = item.alarmAll == null ? '0' : item.alarmAll.toString()
            // item.status = item.status == null ? '0' : item.status.toString()
          })
        }
      })
    },
    crontabFill(value) {
      // 确定后回传的值
      this.formData.forEach(item => {
        if (item.id == this.id) {
          this.$set(item, 'cron', value)
        }
      })
      console.log('this.formData', this.formData)
    },
    showDialog (id) {
      this.id = id
      this.formData.forEach(item => {
        if (item.id == id) {
          this.expression = item.cron
        }
      })
      // this.expression = this.input;// 传入的 cron 表达式，可以反解析到 UI 上
      this.showCron = true
    },
    getPersonList() {
      let params = {
        type: 0
      }
      this.$store
        .dispatch('commit/getPersonList', params)
        .then(response => {
          this.personList = response.data
        })
        .catch(() => {})
    },
    getDeptList() {
      this.$store
        .dispatch('deptManager/getDeptList')
        .then(response => {
          this.deptList = response.data
        })
        .catch(() => {})
    },
    getProjectNameList() {
      let params = {
        type: 1
      }
      this.$store
        .dispatch('commit/getProjectNameList', params)
        .then(response => {
          this.projectList = response.data
        })
        .catch(() => {})
    },
    getBugSystemName () {
      this.$store
        .dispatch('bugDetails/getBugSystemName')
        .then(response => {
          const { data } = response
          data.projectName.forEach(item => {
             this.projectName.push({
               value: item,
               label: item
             })
          })
        })
        .catch(() => {
        })
    },
    addAlarmCondition (id) {
      this.formData.forEach(item => {
        if (item.id == id) {
          item.alarmConditions.push({
            condition: '',
            conType: '',
            key: null,
            content: ''
          })
        }
      })
    },
    deleteCondition (id, index) {
      this.formData.forEach(item => {
        if (item.id == id) {
          item.alarmConditions.splice(index, 1)
        }
      })
    },
    setConditionContent (id, index) {
      this.$refs.warmContent.id = id
      this.$refs.warmContent.index = index
      this.formData.forEach((item, index1) => {
        if (item.id == id) {
          this.$refs.warmContent.content = item.alarmConditions[index].content
        }
      })
      this.$refs.warmContent.dialogVisible = true
    },
    addMonitor () {
      this.formData.push({
        botUrl: '',
        cron: '',
        id: uuid(8, 16),
        day: '',
        isAdd: 1,
        alarmObject: {
          groupIds: [],
          realProjectNames: [],
          users: []
        },
        alarmAll: '0',
        alarmConditions: [
        ],
        status: false,
      })
    },
    deleteWarm (id) {
      this.formData.forEach((item, index) => {
        if (item.id == id) {
          console.log('this.formData', item.id, id, this.formData.length)
          // 当是最后一个的时候，弹框提示
          if (this.formData.length == 1) {
            this.$refs.deleteConfirmModal.dialogVisible = true
            this.$refs.deleteConfirmModal.isClose = true
            this.deleteWarmInfo = {
              id,
              index
            }
          } else {
            this.formData.splice(index, 1)
          }
        }
      })
    },
    confirmDeleteWarm () {
      console.log('this.deleteWarmInfo', this.deleteWarmInfo)
      this.formData.splice(this.deleteWarmInfo.index, 1)
      this.saveWarm()
    },
    saveWarm () {
      // 将isAdd是1的项中的id删除
      console.log('this.formData', this.formData)
      // 遍历formData，同时判断botUrl和day和cron是否为空，一处为空则终止流程
      let flag = true
      for (let i = 0; i < this.formData.length; i++) {
        if (!this.formData[i].botUrl) {
          flag = false
          this.$Message.error(`第${i + 1}个机器人的botUrl不能为空`)
          break
        }
        if (!this.formData[i].day) {
          flag = false
          this.$Message.error(`第${i + 1}个机器人的监测周期不能为空`)
          break
        }
        if (!this.formData[i].cron) {
          flag = false
          this.$Message.error(`第${i + 1}个机器人的执行周期不能为空`)
          break
        }
        // 监测指标不能为空
        if (this.formData[i].alarmConditions.length == 0) {
          flag = false
          this.$Message.error(`第${i + 1}个机器人的监测指标不能为空`)
          break
        }
        // 当alarmAll为1时，将alarmObject中的值清空
        if (this.formData[i].alarmAll == '1') {
          this.formData[i].alarmObject = {
            groupIds: [],
            realProjectNames: [],
            users: []
          }
        }
        // 当isAdd为1时，将id删除
        if (this.formData[i].isAdd == 1) {
          delete this.formData[i].id
        }
        // 当alarmAll和status转为字符串
        this.formData[i].alarmAll = this.formData[i].alarmAll == null ? '0' : this.formData[i].alarmAll.toString()
      }
      if (!flag) return

      this.$store.dispatch('codeQuality/alarmInfo', this.formData).then(res => {
        this.$Message.success('操作成功')
        this.getAlarm()
        this.dialogVisible = false
      })
    },
    cancelSave() {
      this.$refs.confirmModal.dialogVisible = true
      this.$refs.confirmModal.isClose = true
    },
    cancelClose() {
      this.getAlarm()
    },
    getConditionContent(data) {
      console.log('data', data)
      const { content, index, id } = data
      this.formData.forEach(item => {
        if (item.id == id) {
          item.alarmConditions[index].content = content
        }
      })
    },
    // handleChangeConditions(formId, cIndex) {
    //   const selectedKey = this.formData.find(form => form.id === formId).alarmConditions[cIndex].key;
    //   // Disable other options with the same key in the same form
    //   this.formData.find(form => form.id === formId).alarmConditions.forEach((condition) => {
    //     if (condition.key === selectedKey) {
    //       condition.key = null;
    //     }
    //   });
    // },
    // isDisabled(formId, cIndex, value) {
    //   const selectedKey = this.formData.find(form => form.id === formId).alarmConditions[cIndex].key;
    //   // Check if the option should be disabled based on the selected key in the same form
    //   return this.formData.find(form => form.id === formId).alarmConditions.some((condition) => {
    //     return condition.key === value && condition.key !== selectedKey;
    //   });
    // },
    handleChangeConditions(formId, cIndex) {
      const selectedKey = this.formData.find(form => form.id === formId).alarmConditions[cIndex].key
      // Update the selected key for the condition
      this.formData.find(form => form.id === formId).alarmConditions[cIndex].key = selectedKey
    },
    isDisabled(formId, cIndex, value) {
      const selectedKey = this.formData.find(form => form.id === formId).alarmConditions[cIndex].key
      // Check if the option should be disabled based on the selected key in the same form
      return this.formData.find(form => form.id === formId).alarmConditions.some((condition) => {
        return condition.key === value && condition.key !== selectedKey
      })
    }
  }
}

</script>
<style lang="scss" scoped>
.main-body{
  background: #fff;
  min-height: 700px;
  border-radius: 10px;
  padding: 20px;
  display: flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
  // max-height: 800px;
  // overflow-y: scroll;
  .form-box{
    width: 65%;
  }
}
::v-deep .el-select {
  .el-input{
    width: 100%;
  }
}
.monitor-box{
  border:1px dashed #e6e6e6;
  padding: 5px 10px 10px;
}
.alarm-condition-box{
  margin-bottom: 10px;
}
.icon-box{
  border: 1px solid #e6e6e6;
  width:80px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
  cursor: pointer;
  .icon-item{
    font-size: 20px;
    cursor: pointer;
    color: #999;
  }
}
.icon-box:hover{
  border: 1px solid #409EFF;
  .icon-item{
    color: #409EFF;
  }
}
.icon-delete{
  font-size: 20px;
  cursor: pointer;
  color: #F56C6C;
}
.icon-info{
  font-size: 20px;
  cursor: pointer;
  color: #409EFF;
}
.add-box{
  border: 1px solid #e6e6e6;
  margin-bottom: 15px;
  padding: 20px;
  position: relative;
  .icon-close{
    position: absolute;
    right: -12px;
    top:-12px;
    font-size: 26px;
    cursor: pointer;
    color: #c0c4cc;
  }
}
.add-condition-box{
  width: 65%;
  display: flex;
  justify-content: end;
  margin-bottom: 20px;
}
.add-center{
  justify-content: center;
  margin-top: -80px;
}
.require-item{
  ::v-deep .el-form-item__label::before{
    content:'*';
    color: #F56C6C;
    font-size: 16px;
    margin-right: 5px;
  }
}
::v-deep .el-select{
  width: 100%;
}
</style>
