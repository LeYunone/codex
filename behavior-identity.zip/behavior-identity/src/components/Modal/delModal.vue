<template>
  <div>
    <Modal v-model="isPropertyModal"
           width="25%"
           class-name="vertical-center-modal"
           footer-hide
           :mask-closable="false"
           :closable="closable">
      <div class="container page-modal">
        <!-- 是否删除此账号？ 删除后账号将不可用 -->
        <slot name="info"></slot>
        <div>
          <Button class="modal-btn"
                  size="large"
                  @click="cancel">{{ $t('common.cancel') }}</Button>
          <Button class="modal-btn btn-success-color"
                  type="primary"
                  @click="ok">{{ $t('common.ensure') }}</Button>
        </div>
      </div>
    </Modal>
    <Modal v-model="dialogVisible"
           width="25%"
           class-name="vertical-center-modal"
           footer-hide
           :mask-closable="false"
           :closable="closable">
      <div class="container">
        <Icon class="icon"
              type="ios-checkmark-circle"
              size="74"
              color="#0F75FF" />
        <p class="p-text"><slot name="back"></slot></p>
      </div>
    </Modal>
  </div>
</template>

<script>
export default {
  name: 'delModal',
  props: {
  },
  data () {
    return {
      isPropertyModal: false,
      closable: false,
      dialogVisible: false
    }
  },
  methods: {
    ok () {
      this.$emit('beforeDele')
    },
    cancel () {
      this.isPropertyModal = false
    }
  }
}
</script>

<style lang="scss" >
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 70px 0 50px;
  text-align: center;
  h3,
  .modal-detail {
    margin-bottom: 65px;
  }
}
.modal-btn {
  width: 120px;
  height: 40px;
  font-size: 16px;
  box-shadow: 0px 1px 1px 0px rgba(0, 0, 0, 0.05);
  border-radius: 5px;
  border: 1px solid #0f75ff;
  color: #0f75ff;
  margin: 0 20px;
}
.btn-success-color {
  background: #0f75ff;
  color: #ffffff;
}
.icon {
  margin-bottom: 50px;
}
.p-text {
  font-size: 20px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #606266;
  line-height: 50px;
}
</style>
