<template>
  <div>
    <Modal v-model="waitModal"
           :closable="false"
           width="25%"
           class-name="vertical-center-modal"
           footer-hide
           :mask-closable="false">
      <div class="container">
        <slot name='waitTip'></slot>
      </div>
    </Modal>
  </div>
</template>

<script>
export default {
  name: 'waitModal',
  data () {
    return {
      waitModal: false
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 80px 0;
}
</style>
