<template>
  <div>
    <Modal v-model="dialogVisible"
           width="50%"
           class-name="vertical-center-modal"
           class="page-modal"
           footer-hide
           title="报警推送设置"
           :closable="true"
    >
      <div class="container">
        <Form ref="addForm" class="form" label-position="right" :label-width="150">
          <div v-for="(formItem,index) in formData" :key="index" class="add-box">
            <FormItem prop="botUrl" label="推送机器URL：">
              <Input
                v-model="formItem.botUrl"
                size="large"
                maxlength="500"
                placeholder="请输入推送机器URL"
                clearable
              >
              </Input>
              <div class="action-box">
                <Icon
                  type="ios-trash-outline"
                  size="20"
                  class="deleteIcon"
                  @click="formData.splice(index, 1)"
                />
              </div>
            </FormItem>
            <FormItem prop="status" label="BUG状态：">
              <Select v-model="formItem.status" size="large" placeholder="请选择BUG状态" filterable clearable>
                <Option v-for="item in botList" :key="item.value" :value="item.value">{{ item.name }}</Option>
              </Select>
            </FormItem>
            <FormItem prop="bug" label="BUG数：">
              <Input
                v-model="formItem.bug"
                type="number"
                size="large"
                maxlength="50"
                placeholder="请输入BUG数"
                clearable
              >
              </Input>
            </FormItem>
            <FormItem prop="reopen" label="退回BUG数：">
              <Input
                v-model="formItem.reopen"
                size="large"
                type="number"
                maxlength="50"
                placeholder="请输入退回BUG数"
                clearable
              >
              </Input>
            </FormItem>
            <FormItem prop="code" label="代码行数：">
              <Input
                v-model="formItem.code"
                size="large"
                type="number"
                maxlength="50"
                placeholder="请输入代码行数"
                clearable
              >
              </Input>
            </FormItem>
            <FormItem prop="day" label="时间限制(天)：">
              <Input
                v-model="formItem.day"
                size="large"
                type="number"
                maxlength="50"
                placeholder="请输入时间限制"
                clearable
              >
              </Input>
            </FormItem>
            <FormItem prop="day" label="报警内容：">
              <mavon-editor v-model="formItem.content" :editable="!check" :toolbars="toolbars" ref="editor">
                <template slot="left-toolbar-after">
                  <button
                    type="button"
                    @click="insertCustomText(formItem,index)"
                    class="op-icon fa fa-user"
                    aria-hidden="true"
                    title="插入用户占位符"
                  ></button>
                </template>
              </mavon-editor>
            </FormItem>
            <!-- <FormItem label="测试：">
              <Button v-debounce type="info" size="large" class="test-bot">
                测试机器人
              </Button>
            </FormItem> -->
          </div>
        </Form>
        <div class="margin-bottom-40 form-btn">
          <Button v-debounce type="dashed" size="large" @click="addBotItem">
            添加报警推送关联关系
          </Button>
        </div>
        <div class="btn-box">
          <Button
            @click="cancelClose"
            size="large" class="footer-btn">{{ $t('common.cancel') }}</Button>
          <Button type="primary" @click="confirm" size="large" class="footer-btn">{{ $t('common.ensure') }}</Button>
        </div>
      </div>
    </Modal>
  </div>
</template>

<script>
import { mavonEditor } from 'mavon-editor'
import 'mavon-editor/dist/css/index.css'
import { mapState } from 'vuex'
export default {
  name: 'confirmModal',
  components: {
    mavonEditor
  },
  data () {
    return {
      dialogVisible: false,
      storageList: [],
      storageId: '',
      addForm: {
        botUrl: '',
        reopen: '',
        bug: '',
        code: '',
        day: '',
        id: null
      },
      validate: {
        botUrl: [
          {
            required: true,
            message: '请输入推送机器的URL',
            trigger: 'blur'
          }
        ]
      },
      item: {},
      formData: [],
    }
  },
  watch: {
    dialogVisible(newVal) {
      if (newVal) {
        // this.getAlarm()
      } else {
        this.cancelClose()
      }
    }
  },
  computed: {
    ...mapState('bugDetails', [
      'tableColumns', 'statusList', 'botUrlList', 'toolbars'
    ]),
    botList () {
      return [...this.statusList, ...this.botUrlList]
    }
  },
  mounted () {
    // this.getAlarm()
  },
  methods: {
    confirm () {
      console.log('提交', this.addForm)
      this.$refs.addForm.validate((valid) => {
        if (valid) {
          this.syncStorage()
        }
      })
    },
    syncStorage () {
      // 遍历formData，若有botUrl为空，则弹框提示
      for (let i = 0; i < this.formData.length; i++) {
        if (!this.formData[i].botUrl) {
          this.$Message.error(`请输入第${i + 1}个推送机器的URL`)
          return
        }
      }
      let params = {
        alarmBot: this.formData
      }
      this.$store.dispatch('codeQuality/alarmInfo', params).then(res => {
        this.$Message.success('设置成功')
        this.dialogVisible = false
      })
    },
    cancelClose() {
      this.dialogVisible = false
      // this.resetForm()
    },
    resetForm() {
      this.$refs['addForm'].resetFields()
    },
    getAlarm() {
      this.$store.dispatch('codeQuality/getAlarm').then(res => {
        if (res.data) {
          this.formData = res.data
          console.log('this.addForm', this.addForm)
        }
      })
    },
    addBotItem() {
      this.formData.push({
        botUrl: '',
        reopen: '',
        bug: '',
        code: '',
        day: '',
        id: '',
        content: '',
        status: '',
      })
    },
    insertCustomText (formItem, index) {
      // 在这里定义你想要插入的自定义文本
      this.$nextTick(() => {
        const editor = this.$refs.editor;
        editor.forEach((editorItem, editorIndex) => {
          if (editorIndex === index) {
            editorItem.insertText(editorItem.getTextareaDom(), {
            prefix: `#{user}`,
            subfix: '',
            str: ''
          });
          }
        })
      })
    },
  }
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 30px 0 15px;
  button {
    width: 60px;
    height: 30px;
    margin: 0 20px;
  }
}
.form{
  width: 100%;
  margin-bottom: 15px;
  padding:15px;
  background: #eee;
}
.ivu-form-item{
  display: flex;
  align-items: center;
}
::v-deep .ivu-form-item-content{
  flex: 1;
  margin-left: 0!important;
  display:flex;
  align-items:center;
}
::v-deep .ivu-modal-body {
  max-height: 700px !important;
  overflow-y: scroll;
}
.bot-box{
  display:flex;
  align-items:center;
}
::v-deep .ivu-dropdown{
  width:100%;
}
.baud-down-icon{
  position: absolute;
  right:10px;
}
.form-btn{
  display: flex;
  justify-content: end;
  width:100%;
  .ivu-btn{
    width:90%;
    height:37px;
  }
}
.add-box{
  padding:15px 10px 10px;
  margin-bottom: 15px;
  background: #fff;
}

.v-note-wrapper.shadow{
  border: 1px solid #e8e8e8;
  box-shadow: none!important;
}
.ivu-icon{
  cursor: pointer;
}
.test-bot{
  width: 20%!important;
}
</style>
