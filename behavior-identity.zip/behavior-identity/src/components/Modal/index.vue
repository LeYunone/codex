<template>
  <div>
    <Modal v-model="dialogVisible"
           width="25%"
           class-name="vertical-center-modal"
           footer-hide
           :mask-closable="false"
           :closable="closable">
      <div class="container">
        <Icon v-if="type"
              class="icon"
              type="ios-checkmark-circle"
              size="74"
              color="#0F75FF" />
        <Icon v-else
              class="icon"
              type="md-close-circle"
              size="74"
              color="#FF6639" />
        <p v-if="type"
           class="p-text">
            恭喜您，提交成功!
            <slot name="info"></slot>
        </p>
        <p v-else
           class="p-text">糟糕，提交失败!
           <slot name="error"></slot></p>
        <Button class="modal-btn"
                :class="{'btn-success-color':type}"
                @click="ok">{{ $t('common.ensure') }}</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
export default {
  name: 'ModalBox',
  props: {
    isShow: {
      type: Boolean,
      default: false
    },
    type: {
      type: Boolean,
      default: true
    }
  },
  data () {
    return {
      dialogVisible: this.isShow,
      closable: false
    }
  },
  watch: {
    isShow () {
      this.dialogVisible = this.isShow
    }
  },
  methods: {
    ok () {
      this.dialogVisible = false
      this.$emit('afterComfirm')
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 80px 0;
}
.icon {
  margin-bottom: 50px;
}
.p-text {
  font-size: 20px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #606266;
  line-height: 50px;
  margin-bottom: 60px;
}
.p-detail {
  font-size: 16px;
}
.modal-btn {
  width: 120px;
  height: 40px;
  color: #ffffff;
  background: #ff6639;
  border-color: #ff6639;
  font-size: 16px;
  box-shadow: 0px 1px 1px 0px rgba(0, 0, 0, 0.05);
  border-radius: 5px;
}
.btn-success-color {
  background: #0f75ff;
  border-color: #0f75ff;
}
</style>
