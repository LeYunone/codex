<template>
  <div>
    <Modal v-model="dialogVisible"
           width="25%"
           class-name="vertical-center-modal"
           class="page-modal"
           footer-hide
           :mask-closable="false"
           title="同步仓库"
           :closable="false">
      <div class="container">
        <Form ref="form" :model="form" :rules="validate" class="form" label-position="right" :label-width="80">
          <FormItem prop="storageId" label="仓库">
            <Select v-model="form.storageId" size="large" placeholder="请选择要同步的仓库" filterable clearable>
              <Option v-for="item in storageList" :value="item.storageId" :key="item.storageId+item.storageUrl" @click.native="selectItem(item)">{{ item.storageUrl }}</Option>
            </Select>
          </FormItem>
        </Form>
        <div class="btn-box">
          <Button
            @click="cancelClose"  class="footer-btn">{{ $t('common.cancel') }}</Button>
          <Button type="primary" @click="confirm"  class="footer-btn">{{ $t('common.ensure') }}</Button>
        </div>
      </div>
    </Modal>
  </div>
</template>

<script>
export default {
  name: 'confirmModal',
  props: {

  },
  data () {
    return {
      dialogVisible: false,
      storageList: [],
      storageId: '',
      form: {},
      validate: {
        storageId: [
          {
            required: true,
            message: '请选择要同步的仓库',
            trigger: "blur",
            type: 'number'
          }
        ]
      },
      item: {}
    }
  },
  mounted() {
    this.getList()
  },
  watch: {
    dialogVisible(newVal) {
      if (newVal) {
        this.getList()
      } else {
        this.cancelClose()
      }
    }
  },
  methods: {
    selectItem(item) {
      this.item = item
    },
    confirm () {
      this.$refs['form'].validate((valid) => {
        if (valid) {
          this.syncStorage()
        }
      })
    },
    syncStorage() {
      const params = {
        token: this.item.token,
        url: this.item.storageUrl
      }
      this.$store.dispatch('commit/syncStorage', params).then(res => {
        if (Number(res.code) === 200 || Number(res.code) === 404) {
          console.log(res)
          this.$Message.success('已通知后台进行同步，预计在10分钟后同步完成')
          this.dialogVisible = false
          // window.location.reload()
        }
      })
    },
    cancelClose() {
      this.dialogVisible = false
      this.resetForm()
    },
    resetForm() {
      this.$refs['form'].resetFields()
      this.form.storageId = ''
      this.item = {}
    },
    getList() {
      this.$store.dispatch('commit/storageList').then(res => {
        console.log(res)
        this.storageList = res.data
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 30px 0 15px;
  button {
    width: 60px;
    height: 30px;
    margin: 0 20px;
  }
}
.form{
  width: 100%;
  margin-bottom: 15px;
}
.ivu-form-item{
  display: flex;
  align-items: center;
}
::v-deep .ivu-form-item-content{
  flex: 1;
  margin-left: 0!important;
}
::v-deep .ivu-form-item-label{
  width: 80px!important;
}
</style>
