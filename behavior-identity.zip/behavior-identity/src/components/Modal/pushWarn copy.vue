<template>
  <div>
    <Modal v-model="dialogVisible"
           width="30%"
           class-name="vertical-center-modal"
           footer-hide
           :mask-closable="false"
           title="报警推送设置"
           :closable="false"
    >
      <div class="container">
        <Form ref="addForm" :model="addForm" :rules="validate" class="form" label-position="right" :label-width="150">
          <FormItem prop="botUrl" label="推送机器URL：">
            <Input
              v-model="addForm.botUrl"
              size="large"
              maxlength="500"
              placeholder="请输入推送机器URL"
              clearable
            >
            </Input>
          </FormItem>
          <FormItem prop="bug" label="BUG数：">
            <Input
              v-model="addForm.bug"
              type="number"
              size="large"
              maxlength="50"
              placeholder="请输入BUG数"
              clearable
            >
            </Input>
          </FormItem>
          <FormItem prop="reopen" label="退回BUG数：">
            <Input
              v-model="addForm.reopen"
              size="large"
              type="number"
              maxlength="50"
              placeholder="请输入退回BUG数"
              clearable
            >
            </Input>
          </FormItem>
          <FormItem prop="code" label="代码行数：">
            <Input
              v-model="addForm.code"
              size="large"
              type="number"
              maxlength="50"
              placeholder="请输入代码行数"
              clearable
            >
            </Input>
          </FormItem>
          <FormItem prop="day" label="时间限制(天)">
            <Input
              v-model="addForm.day"
              size="large"
              type="number"
              maxlength="50"
              placeholder="请输入时间限制"
              clearable
            >
            </Input>
          </FormItem>
        </Form>
        <div>
          <Button
            @click="cancelClose"
          >{{ $t('common.cancel') }}</Button>
          <Button type="primary" @click="confirm">{{ $t('common.ensure') }}</Button>
        </div>
      </div>
    </Modal>
  </div>
</template>

<script>
export default {
  name: 'confirmModal',
  props: {

  },
  data () {
    return {
      dialogVisible: false,
      storageList: [],
      storageId: '',
      addForm: {
        botUrl: '',
        reopen: '',
        bug: '',
        code: '',
        day: '',
        id: null
      },
      validate: {
        botUrl: [
          {
            required: true,
            message: '请输入推送机器的URL',
            trigger: 'blur'
          }
        ]
      },
      item: {}
    }
  },
  watch: {
    dialogVisible(newVal) {
      if (newVal) {
        this.getAlarm()
      } else {
        this.cancelClose()
      }
    }
  },
  mounted() {
    this.getAlarm()
  },
  methods: {
    confirm () {
      console.log('提交', this.addForm)
      this.$refs.addForm.validate((valid) => {
        if (valid) {
          this.syncStorage()
        }
      })
    },
    syncStorage () {
      this.$store.dispatch('codeQuality/alarmInfo', this.addForm).then(res => {
        this.$Message.success('设置成功')
        this.dialogVisible = false
      })
    },
    cancelClose() {
      this.dialogVisible = false
      // this.resetForm()
    },
    resetForm() {
      this.$refs['addForm'].resetFields()
    },
    getAlarm() {
      this.$store.dispatch('codeQuality/getAlarm').then(res => {
        if (res.data) {
          // for (let key in res.data) {
          //   if (key !== 'botUrl') {
          //     res.data[key] = Number(res.data[key])
          //   }
          // }
          this.addForm = res.data
          console.log('this.addForm', this.addForm)
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 30px 0 15px;
  button {
    width: 60px;
    height: 30px;
    margin: 0 20px;
  }
}
.form{
  width: 100%;
  margin-bottom: 15px;
}
.ivu-form-item{
  display: flex;
  align-items: center;
}
::v-deep .ivu-form-item-content{
  flex: 1;
  margin-left: 0!important;
}
// ::v-deep .ivu-form-item-label{
//   width: 150px!important;
// }
</style>
