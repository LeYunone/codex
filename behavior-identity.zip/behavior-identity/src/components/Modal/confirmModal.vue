<template>
  <div>
    <Modal v-model="dialogVisible"
           width="25%"
           class-name="vertical-center-modal"
           footer-hide
           :mask-closable="false"
           :closable="false">
      <div class="container">
        <Icon class="icon"
              type="ios-alert"
              color="#FF6639"
              size="74" />
        <p class="p-text">
            <slot name="info"></slot>
        </p>
        <div  v-if="isClose">
            <Button 
                  size="large"
                  type="error"
                  ghost
                  @click="cancelClose">{{ $t('common.cancel') }}</Button>
            <Button size="large"
                    type="error"
                    @click="okClose">{{ $t('common.ensure') }}</Button>
        </div>
        <div v-else>
          <Button 
                  size="large"
                  type="error"
                  ghost
                  @click="cancelDel">{{ $t('common.cancel') }}</Button>
          <Button type="error"
                  
                  size="large"
                  @click="okDel">{{ $t('common.delete')}}</Button>
        </div>
      </div>
    </Modal>
    <Modal v-model="isPropertyModal"
           width="25%"
           class-name="vertical-center-modal"
           footer-hide
           :mask-closable="false"
           :closable="false">
      <div class="container">
        <Icon class="icon"
              type="ios-checkmark-circle"
              size="74"
              color="#FF4330" />
        <p class="p-text">{{ $t('common.delSuccess') }}</p>
      </div>
    </Modal>
  </div>
</template>

<script>
export default {
  name: 'confirmModal',
  props: {
    isShow: {
      type: Boolean,
      default: false
    },
    type: {
      type: Boolean,
      default: true
    }
  },
  data () {
    return {
      dialogVisible: false,
      isPropertyModal: false,
      isClose: false
    }
  },
  methods: {
    okDel () {
      this.dialogVisible = false
      this.$emit('afterComfirm')
    },
    okClose () {
      this.dialogVisible = false
      this.$emit('entrueClose')
    },
    cancelDel () {
      this.dialogVisible = false
    },
    cancelClose() {
      this.dialogVisible = false
      this.$emit('cancelClose')
    }
  }
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 0;
  button {
    width: 120px;
    height: 40px;
    margin: 0 20px;
  }
}
.icon {
  margin-bottom: 20px;
}
.p-text {
  font-size: 20px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: rgba(51, 51, 51, 1);
  line-height: 50px;
  margin-bottom: 40px;
}
</style>
