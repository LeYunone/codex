<template>
  <div class="nav-header">
    <Row>
      <i-col :span="4">
        <span class="title-nav">{{ $t("home.title") }}</span>
      </i-col>
      <i-col :span="16">
        <Menu
          mode="horizontal"
          :active-name="currentName"
          @on-select="menuChange"
        >
        </Menu>
      </i-col>
      <i-col :span="4">
        <div class="drop-menu">
          <Dropdown>
            <div>
              <Avatar style="background-color: #87d068" icon="ios-person" />
              <a class="user-name" href="javascript:void(0)">
                admin
                <Icon type="ios-arrow-down"></Icon>
              </a>
            </div>
            <DropdownMenu slot="list">
              <DropdownItem @click.native="toLayout">{{
                $t("common.layout")
              }}</DropdownItem>
            </DropdownMenu>
          </Dropdown>
        </div>
      </i-col>
    </Row>
  </div>
</template>

<script>
export default {
  name: "homeNav",
  data() {
    return {
      image: "https://i.loli.net/2017/08/21/599a521472424.jpg",
    };
  },
  props: {
    currentName: {
      type: String,
      default: "1",
    },
  },
  methods: {
    menuChange(name) {
      // let currentPage = window.location.hash;
      // currentPage = currentPage.replace("#/", "");
      // if (name == 1 && currentPage != "homePage") {
      //   this.$router.push("/homePage");
      // } else if (name == 2 && currentPage != "checkPage") {
      //   this.$router.push("/checkPage");
      // }
    },
    toLayout() {},
  },
};
</script>

<style lang="scss" scoped>
.nav-header {
  position: absolute;
    top: 0;
  width: 100%;
  height: 60px;
  background-color: #ffffff;
  box-shadow: 0px 2px 10px 0px rgba(0, 0, 0, 0.09);
  .title-nav {
    font-size: 20px;
    padding: 0 60px;
    line-height: 60px;
  }
  .drop-menu {
    position: absolute;
    top: 0;
    right: 60px;
    .user-name {
      line-height: 60px;
      margin-left: 15px;
    }
  }
}
</style>
