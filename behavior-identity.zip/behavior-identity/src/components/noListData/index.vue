<style lang='scss' scoped>
.noListData {
  display: flex;
  justify-content: center;
  padding: 150px;
  .no-img {
    width: 374px;
    height: 412px;
    background: url("../../assets/image/noDataPic.png") center center no-repeat;
  }
  .no-text {
    margin-top: -20px;
    text-align: center;
    font-size: 20px;
  }
}
</style>
<template>
  <div class="noListData"
       :class="listDataStyle">
    <div>
      <div class="no-img">
      </div>
      <div class="no-text">
        {{ noDataTxt || $t('common.noListData') }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'noListData',
  components: {
  },
  props: {
    listDataStyle: {
      type: String,
      default: ''
    },
    noDataTxt: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
    }
  },
  computed: {
  },
  watch: {
  },
  created () {
  },
  mounted () {
  },
  methods: {
  }
}
</script>
