<style lang='less' scoped>
</style>
<template>
  <div class="lineChart">
    <div :id="chartId"></div>
  </div>
</template>

<script>
import HighchartsNoData from 'highcharts-no-data-to-display'
export default {
  name: 'lineChart',
  components: {
  },
  props: ['chartId', 'title', 'color'],
  data () {
    return {
    }
  },
  computed: {
  },
  watch: {
  },
  created () {
  },
  mounted () {
    this.getChart()
  },
  methods: {
    getChart (id) {
      var Highcharts = require('highcharts')
      HighchartsNoData(Highcharts)
      var chart = Highcharts.chart(id, {
        chart: {
        },
        title: {
          text: '美元兑欧元汇率走势图',
          align: 'left'
        },
        subtitle: {
          text: null
        },
        xAxis: {
          gridLineWidth: 1,
          tickWidth: 0
        },
        exporting: {
          enabled: false
        },
        credits: {
          enabled: false
        },
        tooltip: {
        },
        yAxis: {
          title: {
            text: null
          }
        },
        legend: {
          enabled: false
        },
        plotOptions: {
          area: {
            fillColor: {
              linearGradient: {
                x1: 0,
                y1: 0,
                x2: 0,
                y2: 1
              },
              stops: [
                [0, '#f00'],
                [1, '#fff']
              ]
            },
            marker: {
              radius: 2
            },
            lineWidth: 1,
            states: {
              hover: {
                lineWidth: 1
              }
            },
            threshold: null
          }
        },
        series: [{
          type: 'area',
          color: '#f00',
          name: '',
          data: [1, 2, 3, 6, 7, 8, 9, 0, 8, 6, 54, 3]
        }]
      })
      // 响应式
      setTimeout(() => {
        chart.reflow()
      }, 10)
    }
  }
}
</script>
