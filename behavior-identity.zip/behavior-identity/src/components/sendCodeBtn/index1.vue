<style lang='scss' scoped>
.btn-box {
  width: 110px;
  text-align: center;
}
</style>
<template>
  <div class="sendCodeBtn">
    <Button
      type="primary"
      class="btn-box"
      size="large"
      :disabled="disabledBtn"
      ghost
      @click="handleSend"
      >{{ codeText }}</Button
    >
  </div>
</template>

<script>
export default {
  name: "sendCodeBtn",
  components: {},
  props: {
    disableBtn: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      codeTimer: {},
      downNum: 60,
      disabledBtn: false,
      codeText: this.$t("login.sendCode"),
    };
  },
  computed: {},
  watch: {
    downNum(val) {
      if (val === 0) {
        // 清除定时
        window.clearInterval(this.codeTimer);
        this.disabledBtn = false;
        this.codeText = this.$t("login.sendCode");
        this.downNum = 60;
      }
    },
    disableBtn: {
      handler() {
        debugger;
        if (this.disableBtn === false) {
          this.disabledBtn = false;
        } else {
          this.disabledBtn = true;
        }
      },
    },
  },
  created() {},
  mounted() {
    debugger;
    if (this.disableBtn === true) {
      this.disabledBtn = true;
    }
  },
  methods: {
    handleSend() {
      this.$emit("handleSend");
    },
    sendCode() {
      this.downNum--;
      this.disabledBtn = true;
      this.codeText = this.downNum + "s";
       
        this.doFunction();
       
    },
    doFunction() {
      this.codeTimer = setInterval(() => {
        if (this.downNum !== 0) {
          this.downNum--;
          this.disabledBtn = true;
          this.codeText = this.downNum + "s";
        }
      }, 1000);
    },
    closeCode() {
      this.downNum = 0;
    },
  },
};
</script>
