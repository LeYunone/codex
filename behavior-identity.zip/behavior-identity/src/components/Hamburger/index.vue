<template>
  <div style="padding: 0 15px;"
       @click="toggleClick">
    <b :class="{'is-active':isActive}"
       class="hamburger"></b>
  </div>
</template>

<script>
export default {
  name: 'Hamburger',
  props: {
    isActive: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    toggleClick () {
      this.$emit('toggleClick')
    }
  }
}
</script>

<style scoped>
.hamburger {
  display: inline-block;
  vertical-align: middle;
  width: 20px;
  height: 20px;
  color: #ffffff;
  background: url("../../assets/image/menu-fold .png") no-repeat center center;
  background-size: 100% 100%;
}

.hamburger.is-active {
  transform: rotate(180deg);
}
</style>
