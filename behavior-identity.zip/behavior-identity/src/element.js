/**
 * 按需引入elementUI
**/

import {
  Menu,
  Submenu,
  MenuItem,
  MenuItemGroup,
  Table,
  TableColumn,
  Form
} from 'element-ui'

export default Vue => {
  Vue.use(Menu)
  Vue.use(Submenu)
  Vue.use(MenuItem)
  Vue.use(MenuItemGroup)
  Vue.use(Table)
  Vue.use(TableColumn)
  Vue.use(Form)
}
