import "@babel/polyfill";

import Vue from "vue";

import "normalize.css/normalize.css"; // A modern alternative to CSS resets


import ElementUI from "element-ui";
import "element-ui/lib/theme-chalk/index.css";

// import element from './element'
import ViewUI from "view-design";
import "view-design/dist/styles/iview.css";
import i18n from "./language/index"; // Internationalization

import "@/styles/index.scss"; // global css
import "font-awesome/css/font-awesome.min.css";

import App from "./App";
import store from "./store";
import router from "./router";
import qs from "qs"; // 全局引用qs，转换数据格式
import Axios from "axios";
import Highcharts from 'highcharts/highstock';
// 加载导出模块
// import * as Exporting from 'highcharts/modules/exporting';
// 初始化导出模块
// Exporting(Highcharts);
import exportingInit from 'highcharts/modules/exporting'
import exportDataInit from 'highcharts/modules/export-data'
exportingInit(Highcharts)
exportDataInit(Highcharts)
Highcharts.setOptions({
    lang: {
      printChart: '打印图表',
      downloadJPEG: '下载JPEG 图片',
      downloadPDF: '下载PDF文档',
      downloadPNG: '下载PNG 图片',
      downloadSVG: '下载SVG 矢量图',
      exportButtonTitle: '导出图片',
      downloadCSV: '导出CSV表格',
      downloadXLS: '导出XLS表格',
      viewFullscreen: '全屏查看',
      exitFullscreen: '退出全屏',
      viewData: '显示表格数据'
    }
});
Vue.prototype.$hCharts = Highcharts;
import "@/icons"; // icon
import "@/permission"; // permission control
import $mAssetsPath from "./commonConfig/assetsConfig"; // 资源路径
import "@/utils/rem"; // 适配
import { MessageBox, Message } from "element-ui";

// 全局注册组件
import modal from "@/components/Modal/index";
import delModal from "@/components/Modal/delModal";
import confirmModal from "@/components/Modal/confirmModal";
import noListData from "@/components/noListData/index";

import homeNav from "@/components/homeNav/index";
import * as echarts from "echarts";

Vue.prototype.$echarts = echarts;
Vue.component("modal", modal);
Vue.component("delModal", delModal);
Vue.component("confirmModal", confirmModal);
Vue.component("noListData", noListData);

Vue.component("homeNav", homeNav);

// // 本地mock测试打包
// if (process.env.NODE_ENV === 'production') {
//   const { mockXHR } = require('../mock')
//   mockXHR()
// }
// 引入mock
import mockIndex from "../mock/index";
import "@/utils/directive"; // 自定义权限指令

Vue.use(ElementUI);
Vue.use(ViewUI);

Vue.config.productionTip = true;
Vue.prototype.$mAssetsPath = $mAssetsPath;
Vue.prototype.$qs = qs;
Vue.prototype.$axios = Axios;
Vue.prototype.$Message = Message;
Vue.prototype.$MessageBox = MessageBox;

new Vue({
  el: "#app",
  i18n,
  router,
  store,
  render: h => h(App)
});
