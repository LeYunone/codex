var email = /[\w!#$%&'*+/=?^_`{|}~-]+(?:\.[\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[\w](?:[\w-]*[\w])?/
var tel = /0?(13|14|15|18)[0-9]{9}/
var account = /[\u4E00-\u9FA5]/
var mac = /^[A-F0-9]{2}(-[A-F0-9]{2}){5}$|^[A-F0-9]{2}(:[A-F0-9]{2}){5}$/

var FormValidate = (function () {
  // eslint-disable-next-line
  function FormValidate() {}
  // From表单验证规则  可用于公用的校验部分
  FormValidate.Form = function () {
    return {
      // // 姓名的验证规则
      account: function (rule, value, callback) {
        if (account.test(value)) {
          callback(new Error('请输入正确的手机号/邮箱!'))
        } else {
          callback()
        }
      },
      phone: function (rule, value, callback) {
        if (!tel.test(value) || value.length !== 11) {
          callback(new Error('请输入正确的手机号'))
        } else if (value.length !== 11) {
          callback(new Error('请输入正确的手机号'))
        } else {
          callback()
        }
      },
      data: (rule, value, callback) => {
        if (!tel.test(value)) {
          callback(new Error('格式错误，请正确填写数据！'))
        } else if (value.length < 1 || value.length > 20) {
          callback(new Error('长度范围：1~20，请正确输入!'))
        } else {
          callback()
        }
      },
      mac: (rule, value, callback) => {
        if (!mac.test(value)) {
          callback(new Error('格式错误，请正确填写数据！'))
        } else {
          callback()
        }
      },
    }
  }

  // FromOne表单验证规则  用于FromOne个性化的校验
  FormValidate.FormOne = function () {
    return {
      // 姓名的验证规则
      Name: function (rule, value, callback) {
        if (!value) {
          return callback(new Error('姓名不能为空'))
        }
        if (!isNaN(value)) {
          callback(new Error('请输入正确姓名!'))
        } else if (value.length < 2 || value.length > 6) {
          callback(new Error('请输入2到6个字符!'))
        } else {
          callback()
        }
      }
    }
  }

  // FromTwo表单验证规则  用于FromTwo表单个性化的校验
  FormValidate.FormTwo = function () {
    return {
      // 传真的校验规则
      Fax: (rule, value, callback) => {
        if (!value) {
          return callback(new Error('传真不能为空'))
        }
        if (!fax.test(value)) {
          callback(new Error('请正确填写传真'))
        } else {
          callback()
        }
      }
    }
  }
  return FormValidate
}())
exports.FormValidate = FormValidate