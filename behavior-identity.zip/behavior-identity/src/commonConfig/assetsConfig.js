/*
 * 图片静态资源表，所有图片资源路径在这统一管理，不应该写死在页面中，该数据挂载到Vue原型中。
 * 页面使用：this.$mAssetsPath.grid_1
 * CSS背景：应尽量使用:style="" 行内样式设置背景图
 * PATH说明：本地路径或者服务器路径
 *
 * 举例：<img :src="grid_1">  需要在data中映射 grid_1: this.$mAssetsPath.grid_1
 *
 * 特别注意：经测试小程序中不支持 <img :src="$mAssetsPath.grid_1"> 该用法
 */

const PATH = '/static/img'

export default {
  // 首页grid的图标
  login: {
    wallPic: PATH + '/wall-pics.e1fbab72.png'
  }
}
