import { sha256 } from 'js-sha256';
export function setPassword(str) {


    // let secret = str;
    let secret = sha256(str);
    let lowSecret = secret.toLowerCase()



    return lowSecret
}