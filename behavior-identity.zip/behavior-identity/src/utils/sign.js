import hmacsha1 from 'hmacsha1'
import { Base64 } from 'js-base64';

export function getSign(params) {

    let result = []
    let name = []

    // 获取键名
    for (let key in params) {
        if (key != undefined && key != 'sign') {
            name.push(key)
        }
    }
    // 键名排序
    name.sort()

    for (let i = 0; i < name.length; i++) {
        let key = name[i]
        let value = params[key]
        if (value != undefined || value != null) {
            result.push(key + '=' + value)
        }
    }

    let strResult = result.join('&')
    let secret = 'DTY7QdEJ9dsY9Axqwq6dXc5AQTN38FN5'



    let seRes = strResult
  
    let baseResult = Base64.encode(seRes);

    let shaResult = hmacsha1(secret, baseResult);


    params.sign = shaResult.toLowerCase()

    return params
}