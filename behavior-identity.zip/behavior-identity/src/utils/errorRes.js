import i18n from '../language/index'
export function getErrorRes(code, mess) {
  let params = ''
  if (code === -1001000002) {
    params = i18n.t('errorRes.res110')
  } else if (code === 400) {
    params = i18n.t('errorRes.res78')
  } else if (code === 403) {
    params = i18n.t('errorRes.res79')
  } else if (code === 413) {
    params = i18n.t('errorRes.res80')
  } else if (code === 429) {
    params = i18n.t('errorRes.res81')
  } else if (code === 503) {
    params = i18n.t('errorRes.res83')
  } else if (code === 1001002035) {
    params = i18n.t('errorRes.res15')
  } else if (code === 1001002036) {
    params = i18n.t('errorRes.res101')
  } else if (code === 1010001002) {
    params = i18n.t('errorRes.res104')
  } else if (code === 1010001001) {
    params = i18n.t('errorRes.res105')
  }
  return params
}
