import Vue from "vue";
//防止用户在短时间内多次点击
Vue.directive('debounce', {
  inserted(button, bind) {
    button.addEventListener('click', () => {
      if (!button.disabled) {
        button.disabled = true
        setTimeout(() => {
          button.disabled = false
        }, 2000)
      }
    })
  }
})
