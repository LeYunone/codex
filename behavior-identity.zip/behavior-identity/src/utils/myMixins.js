import { getYearDays } from './commFunction'

export default {
  data () {
    return {
      options2: {
        shortcuts: [
          {
            text: '近一周',
            value () {
                const end = new Date()
                const start = new Date()
                start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
                return [start, end]
            }
          },
          {
            text: '近一个月',
            value () {
                const end = new Date()
                const start = new Date()
                start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
                return [start, end]
            }
          },
          {
            text: '近一年',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * getYearDays())
              return [start, end]
            }
          }
        ],
        disabledDate: date => {
          if (this.endMonth) {
            let endDate = this.getDate(this.endMonth)
              return (date && date > endDate) || date > new Date()
            } else {
              return date && date > new Date()
            }
        }
      }
    }
  }
}

