
const TokenKey = 'Authorization'
const SessionId = 'sessionId'
const RoleId = 'roleId'
const FirstLogin = 'isFirst'
const UserId = 'userId'

const UserName = 'username'
const UserEmail = 'email'
const UserPhone = 'phone'
const Img = 'image'
const Account = 'account'
const UserAreaCode = "areaCode";

const Language = 'language'
const PhoneToken = 'phoneToken'
const EmailToken = 'emailToken'

export function setLanguage(language) {
  return localStorage.setItem(Language, language);
}
export function getLanguage() {
  return localStorage.getItem(Language);
}
export function removeLanguage() {
  return localStorage.remove(Language);
}
export function getToken () {
  return localStorage.getItem(TokenKey)
}

export function setToken (token) {
  return localStorage.setItem(TokenKey, token)
}

export function removeToken () {
  return localStorage.removeItem(TokenKey)
}
export function getSessionId () {
  return localStorage.getItem(SessionId)
}

export function setSessionId (sessionId) {
  return localStorage.setItem(SessionId, sessionId)
}

export function removeSessionId () {
  return localStorage.removeItem(SessionId)
}
export function getFirstLogin () {
  return JSON.parse(localStorage.getItem(FirstLogin))
}

export function setFirstLogin (token) {
  return localStorage.setItem(FirstLogin, token)
}

export function removeFirstLogin () {
  return localStorage.remove(FirstLogin)
}

export function setRoleId (roleId) {
  return localStorage.setItem(RoleId, roleId)
}
export function getRoleId () {
  return localStorage.getItem(RoleId)
}
export function removeRoleId () {
  return localStorage.remove(RoleId)
}
export function setUserId (userId) {
  return localStorage.setItem(UserId, userId)
}
export function getUserId () {
  return localStorage.getItem(UserId)
}
export function removeUserId () {
  return localStorage.remove(UserId)
}

export function setUserName (userName) {
  return localStorage.setItem(UserName, userName)
}
export function getUserName () {
  return localStorage.getItem(UserName)
}

export function setUserEmail (userEmail) {
  return localStorage.setItem(UserEmail, userEmail)
}
export function getUserEmail () {
  return localStorage.getItem(UserEmail)
}

export function setUserPhone (userPhone) {
  return localStorage.setItem(UserPhone, userPhone)
}
export function getUserPhone () {
  return localStorage.getItem(UserPhone)
}

export function setHeadImg (img) {
  return localStorage.setItem(Img, img)
}
export function getHeadImg () {
  return localStorage.getItem(Img)
}

export function setAccount (account) {
  return localStorage.setItem(Account, account)
}
export function getAccount () {
  return localStorage.getItem(Account)
}

export function setUserAreaCode(areaCode) {
  return localStorage.setItem(UserAreaCode, areaCode);
}
export function getUserAreaCode() {
  return localStorage.getItem(UserAreaCode);
}
// 验证码token保存
export function setPhoneToken(phoneToken) {
  return localStorage.setItem(PhoneToken, phoneToken);
}
export function getPhoneToken() {
  return localStorage.getItem(PhoneToken);
}

export function setEmailToken(emailToken) {
  return localStorage.setItem(EmailToken, emailToken);
}
export function getEmailToken() {
  return localStorage.getItem(EmailToken);
}