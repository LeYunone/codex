import axios from 'axios'
import { MessageBox, Message } from 'element-ui'
import store from '@/store'
import router from '@/router/index'
import { getErrorRes } from '@/utils/errorRes'
import i18n from '../language/index'

let quitFlag = 0
// create an axios instance
const service = axios.create({
  baseURL: 'http://127.0.0.1:7878',
  timeout: 120000 // request timeout
})

service.interceptors.request.use(
  config => {
    let jsonUrlList = [
      '/codex/group/save',
      '/codex/user/save',
      '/codex/realuser/save',
      '/codex/realuser/delete',
      '/codex/bug/detailList',
      '/codex/bug/statistics',
      '/codex/system/alarmInfo',
      '/codex/project/relationRealProject',
      '/codex/statistics/bugTop',
      '/codex/statistics/bugAnalysis',
      '/codex/bot/chanceStatus',
      '/codex/bot/delete',
      '/codex/bot/saveBot',
      '/codex/statistics/bugVersionAnalysis',
      '/codex/statistics/bugHistogram'
    ]
    if (jsonUrlList.includes(config.url)) {
      config.headers['Content-Type'] = 'application/json'
    } else {
      config.headers['Content-Type'] = 'application/x-www-form-urlencoded'
    }
    // console.log(config)
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// 响应拦截
service.interceptors.response.use(
  response => {
    const res = response.data
    if (Number(res.statusCode) !== 200 && res.status === false) {
      Message({
        message: res.message,
        type: 'error'
      })
      return Promise.reject(new Error(res.message || 'Error'))
    } else if (response.headers['content-type'] === 'application/vnd.ms-excel;charset=UTF-8') {
      return response
    } else {
      return res
    }
  },
  error => {
    console.log(error)
    let errMessage = ''
      errMessage = getErrorRes(error.response.status)
      Message({
        message: errMessage,
        type: 'error',
        duration: 2 * 1000
      })
    return Promise.reject(error)
  }
)

export default service
