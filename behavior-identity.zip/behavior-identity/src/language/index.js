import Vue from 'vue'
import VueI18n from 'vue-i18n'
import zhLocale from 'view-design/dist/locale/zh-CN'
import enLocale from 'view-design/dist/locale/en-US'
import trLocale from 'view-design/dist/locale/zh-TW'
import zhCn from './local/zh-CN'

Vue.use(VueI18n)
Vue.locale = () => { }
const messages = {
  zh: Object.assign(zhCn, zhLocale),
}
const i18n = new VueI18n({
  locale: localStorage.getItem('language') || 'zh', // set locale
  messages // set locale messages
})

export default i18n
