import request from '@/utils/request'
export function getList(params) {
  return request({
    url: '/codex/commit/commitBy',
    method: 'get',
    params: params
  })
}

export function getProjectNameList(params) {
  return request({
    url: '/codex/user/selectuserproject',
    method: 'get',
    params: params
  })
}

export function getPersonList(params) {
  return request({
    url: '/codex/user/selectuserproject',
    method: 'get',
    params: params
  })
}

export function getStoragesList(params) {
  return request({
    url: '/codex/config/storages',
    method: 'get',
    params: params
  })
}

// 同步仓库
export function storageList(params) {
  return request({
    url: '/codex/config/storages',
    method: 'get',
    params: params
  })
}
export function syncStorage(params) {
  return request({
    url: '/codex/system/sync',
    method: 'get',
    params: params
  })
}
