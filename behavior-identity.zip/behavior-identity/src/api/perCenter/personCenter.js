import request from '@/utils/request'
export function loginOut (params) {
  return request({
    url: '/usercenter/api/uc/logout',
    method: 'get',
    params: params
  })
}
