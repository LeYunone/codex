import request from '@/utils/request'
// bug详情
export function detailList(data) {
  return request({
    url: '/codex/bug/detailList',
    method: 'post',
    data
  })
}

export function getBugSystemName(params) {
  return request({
    url: '/codex/system/getBugSystemName',
    method: 'get',
    params
  })
}

//
export function bugTop(data) {
  return request({
    url: '/codex/statistics/bugTop',
    method: 'post',
    data
  })
}

// 饼图
export function bugAnalysis(data) {
  return request({
    url: '/codex/statistics/bugAnalysis',
    method: 'post',
    data
  })
}

// 折线图
export function bugVersionAnalysis(data) {
  return request({
    url: '/codex/statistics/bugVersionAnalysis',
    method: 'post',
    data
  })
}

//
export function bugHistogram(data) {
  return request({
    url: '/codex/statistics/bugHistogram',
    method: 'post',
    data
  })
}
