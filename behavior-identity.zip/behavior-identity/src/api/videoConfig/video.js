import request from "@/utils/request";

export function addVideo(data) {
  return request({
    url: "/communities/platform/availale/area/add",
    method: "post",
    data
  });
}
export function videoList(data) {
  return request({
    url: "/communities/platform/availale/area/list",
    method: "post",
    data
  });
}

export function projectList(data) {
  return request({
    url: "/communities/platform/community/project/list",
    method: "post",
    data
  });
}

export function getVideoDetail(data) {
  return request({
    url: "/communities/platform/availale/area/detail",
    method: "post",
    data
  });
}
export function delVideo(data) {
  return request({
    url: "/communities/platform/availale/area/delete",
    method: "post",
    data
  });
}

export function getProConfig(data) {
  return request({
    url: "/communities/platform/community/detail/project",
    method: "post",
    data
  });
}

export function setConfig(data) {
  return request({
    url: "/communities/platform/community/update/configuration",
    method: "post",
    data
  });
}
export function setDisabled(data) {
  return request({
    url: "/communities/platform/availale/area/disable",
    method: "post",
    data
  });
}
export function setEnabled(data) {
  return request({
    url: "/communities/platform/availale/area/enable",
    method: "post",
    data
  });
}

export function editVideo(data) {
  return request({
    url: "/communities/platform/availale/area/detail/update",
    method: "post",
    data
  });
}
