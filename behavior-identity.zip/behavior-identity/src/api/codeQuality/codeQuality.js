import request from '@/utils/request'
// bug详情
export function statistics(data) {
  return request({
    url: '/codex/bug/statistics',
    method: 'post',
    data
  })
}

export function getAlarm(data) {
  return request({
    url: '/codex/system/getAlarm',
    method: 'get',
    data
  })
}

export function alarmInfo(data) {
  return request({
    url: '/codex/system/alarmInfo',
    method: 'post',
    data
  })
}
