import request from '@/utils/request'

export function getAlarm(params) {
  return request({
    url: '/codex/bot/getAlarm',
    method: 'get',
    params
  })
}

export function saveBot(data) {
  return request({
    url: '/codex/bot/saveBot',
    method: 'post',
    data
  })
}

export function chanceStatus(data) {
  return request({
    url: '/codex/bot/chanceStatus',
    method: 'post',
    data
  })
}
export function deleteWarn(data) {
  return request({
    url: '/codex/bot/delete',
    method: 'post',
    data
  })
}
