import request from "@/utils/request";
export function getDeptList() {
  return request({
    url: "/codex/config/groups",
    method: "get",
  });
}

export function updateDept(data) {
  return request({
    url: "/codex/group/save",
    method: "post",
    data
  });
}
