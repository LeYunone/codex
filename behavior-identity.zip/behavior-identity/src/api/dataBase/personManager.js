import request from '@/utils/request'
export function getPersonList(params) {
  return request({
    url: '/codex/user/alluser',
    method: 'get',
    params: params
  })
}

export function editPerson(data) {
  return request({
    url: '/codex/user/save',
    method: 'post',
    data
  })
}

export function getList(params) {
  return request({
    url: '/codex/realuser/query',
    method: 'get',
    params: params
  })
}

export function getRealUserList(params) {
  return request({
    url: '/codex/user/users',
    method: 'get',
    params: params
  })
}

export function updatePerson(data) {
  return request({
    url: '/codex/realuser/save',
    method: 'post',
    data
  })
}

export function deletePerson(data) {
  return request({
    url: '/codex/realuser/delete',
    method: 'post',
    data
  })
}
