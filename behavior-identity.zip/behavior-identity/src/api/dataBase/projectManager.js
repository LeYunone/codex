import request from '@/utils/request'
export function relationList(params) {
  return request({
    url: '/codex/project/relationList',
    method: 'get',
    params
  })
}

export function relationRealProject(data) {
  return request({
    url: '/codex/project/relationRealProject',
    method: 'post',
    data
  })
}
