import request from "@/utils/request";
export function getList(params) {
  return request({
    url: "/codex/project/projectcon",
    method: "get",
    params: params
  });
}
