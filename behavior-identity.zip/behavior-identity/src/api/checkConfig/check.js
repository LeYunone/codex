import request from "@/utils/request";

export function getCaList(params) {
  return request({
    url: "/communities/platform/enterprise/ca/list",
    method: "get",
    params: params
  });
}

export function getCaDetail(params) {
  return request({
    url: "/communities/platform/enterprise/ca/detail",
    method: "get",
    params: params
  });
}

export function passCa(data) {
  return request({
    url: "/communities/platform/enterprise/ca/update/pass",
    method: "post",
    data
  });
}

export function rejectCa(data) {
  return request({
    url: "/communities/platform/enterprise/ca/update/reject",
    method: "post",
    data
  });
}

export function disableCa(data) {
  return request({
    url: "/communities/platform/enterprise/ca/update/disable",
    method: "delete",
    data
  });
}
