import request from '@/utils/request'
// 指定月下指定人的总代码量
export function userProjectTimeCode(params) {
  return request({
    url: '/codex/statistics/userProjectTimeCode',
    method: 'get',
    params: params
  })
}

// / statistics/userbasecode
// 指定部门下的人员代码量
export function userbasecode(params) {
  return request({
    url: '/codex/statistics/userbasecode',
    method: 'get',
    params: params
  })
}
// 指定部门代码量
export function projectTimeCode(params) {
  return request({
    url: '/codex/statistics/projectTimeCode',
    method: 'get',
    params: params
  })
}

// 所有项目的代码总量
export function projectbasecode(params) {
  return request({
    url: '/codex/statistics/projectbasecode',
    method: 'get',
    params: params
  })
}

// 人员分析
export function userinfo(params) {
  return request({
    url: '/codex/statistics/userinfo',
    method: 'get',
    params: params
  })
}

// 分析总数
export function getCodeTotal(params) {
  return request({
    url: '/codex/statistics/getCodeTotal',
    method: 'get',
    params: params
  })
}

export function exportUserCode(params) {
  return request({
    url: '/codex/export/userCode',
    method: 'get',
    params: params,
    responseType: 'blob'
  })
}
export const download = (res, type, filename) => {
  // 创建blob对象，解析流数据
  const blob = new Blob([res.data], {
    // type: 'application/pdf;charset=UTF-8' 表示下载文档为pdf，如果是word则设置为msword，excel为excel
    type: type
  })
  // const filename = res.headers['content-disposition'].split(';')[1].split('filename=')[1] // 获取文件名
  // 创建a标签，用于模拟点击事件
  const downloadElement = document.createElement('a')
  // 兼容webkix浏览器，处理webkit浏览器中href自动添加blob前缀，默认在浏览器打开而不是下载
  const URL = window.URL.createObjectURL(blob)
  // 根据解析后的blob对象创建URL 对象
  const href = URL.createObjectURL(blob)
  // 下载链接
  downloadElement.href = href
  // 下载文件名,如果后端没有返回，可以自己写a.download = '文件.pdf'
  downloadElement.download = decodeURIComponent(filename) // decodeURIComponent防止中文乱码
  document.body.appendChild(downloadElement)
  // 点击a标签，进行下载
  downloadElement.click()
  // 收尾工作，在内存中移除URL 对象
  document.body.removeChild(downloadElement)
  window.URL.revokeObjectURL(href)
}
